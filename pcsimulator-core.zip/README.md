# PC Simulator (core foundation)

Requirements: **JDK 21**. Gradle wrapper (9.2.1) and ModDevGradle (`net.neoforged.moddev` 2.0.148) are taken from the official 1.21.1 MDK; NeoForge `21.1.265`.

```
./gradlew build            # jar in build/libs/
./gradlew runClient        # dev client
./gradlew runServer        # dev server (--nogui)
./gradlew runData          # data generation -> src/generated/resources
./gradlew runGameTestServer
```
Windows: `gradlew.bat`. First run downloads Minecraft/NeoForge/Parchment (needs maven.neoforged.net, maven.parchmentmc.org).

Manual test checklist
1. Create World → *World Type* → **PC Simulator**.
2. `/pcsim info` shows version and `PC world type: true`.
3. First join: `/pcsim balance` = `$1000.00` (config `startingBalanceCents`).
4. `/pcsim economy give @s 2500` → balance updates; server log shows no errors.
5. Mods screen → PC Simulator → Config opens.

See `docs/ARCHITECTURE.md`.
