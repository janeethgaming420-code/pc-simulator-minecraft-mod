package com.pcsimulator;

import com.mojang.logging.LogUtils;
import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.core.CoreEvents;
import com.pcsimulator.core.command.PCCommands;
import com.pcsimulator.core.config.PCConfig;
import com.pcsimulator.core.economy.EconomyServiceImpl;
import com.pcsimulator.core.module.ModuleLoader;
import com.pcsimulator.core.network.PCNetwork;
import com.pcsimulator.core.registry.CoreCreativeTab;
import com.pcsimulator.core.registry.CoreDataComponents;
import com.pcsimulator.core.registry.CoreRegistries;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

/**
 * Mod entry point (both sides). Initialisation order matters:
 * config -> API bindings -> shared registers -> core registry content -> modules -> events.
 */
@Mod(PCSimulatorAPI.MOD_ID)
public final class PCSimulator {
    public static final String MOD_ID = PCSimulatorAPI.MOD_ID;
    public static final Logger LOGGER = LogUtils.getLogger();

    public PCSimulator(IEventBus modBus, ModContainer container) {
        PCConfig.register(container);
        PCSimulatorAPI.bindEconomy(EconomyServiceImpl::current);

        CoreRegistries.registerAll(modBus);
        CoreDataComponents.init();
        CoreCreativeTab.init();

        ModuleLoader.registerAll(modBus, container, FMLEnvironment.dist);

        modBus.addListener(PCNetwork::onRegisterPayloads);
        modBus.addListener((RegisterCapabilitiesEvent e) -> ModuleLoader.modules().forEach(m -> m.registerCapabilities(e)));

        NeoForge.EVENT_BUS.addListener(CoreEvents::onServerStarting);
        NeoForge.EVENT_BUS.addListener(CoreEvents::onServerStarted);
        NeoForge.EVENT_BUS.addListener(CoreEvents::onServerStopped);
        NeoForge.EVENT_BUS.addListener(CoreEvents::onPlayerLoggedIn);
        NeoForge.EVENT_BUS.addListener(PCCommands::onRegisterCommands);

        LOGGER.info("PC Simulator core initialised ({} modules)", ModuleLoader.modules().size());
    }
}
