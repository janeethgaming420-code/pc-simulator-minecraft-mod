package com.pcsimulator.api.economy;

public enum TransactionResult {
    SUCCESS, INVALID_AMOUNT, INSUFFICIENT_FUNDS, BALANCE_LIMIT, SAME_ACCOUNT;

    public boolean isSuccess() {
        return this == SUCCESS;
    }
}
