package com.pcsimulator.api.economy;

import net.minecraft.resources.ResourceLocation;

import java.util.UUID;

/**
 * Account storage + atomic balance operations. The core owns balances; the economy module owns prices, shops
 * and income and uses this service to move money. Server thread only.
 *
 * <p>Amounts are in <b>cents</b> (long, never negative). {@code reason} identifies the caller
 * (e.g. {@code pcsimulator:shop_purchase}) and is forwarded to {@code BalanceChangedEvent}.
 */
public interface IEconomyService {
    boolean hasAccount(UUID account);

    /** 0 for unknown accounts. */
    long getBalance(UUID account);

    default boolean canAfford(UUID account, long cents) {
        return getBalance(account) >= cents;
    }

    TransactionResult deposit(UUID account, long cents, ResourceLocation reason);

    TransactionResult withdraw(UUID account, long cents, ResourceLocation reason);

    TransactionResult transfer(UUID from, UUID to, long cents, ResourceLocation reason);

    /** Administrative overwrite, clamped to the configured limits. */
    void setBalance(UUID account, long cents, ResourceLocation reason);

    /** Formats with the configured currency symbol, e.g. {@code $12.50}. */
    String format(long cents);
}
