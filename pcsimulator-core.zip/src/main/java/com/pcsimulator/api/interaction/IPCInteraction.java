package com.pcsimulator.api.interaction;

import net.minecraft.world.InteractionResult;

/**
 * A discrete thing a player can do with a PC. Registered in {@code PCRegistries.INTERACTIONS}.
 * {@link #perform} runs on the logical server only.
 */
public interface IPCInteraction {
    boolean canPerform(InteractionContext context);

    InteractionResult perform(InteractionContext context);
}
