package com.pcsimulator.api.interaction;

import com.pcsimulator.api.PCRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionResult;

public final class PCInteractions {
    private PCInteractions() {}

    /** Runs an interaction; PASS if unknown or not currently possible. */
    public static InteractionResult perform(ResourceLocation id, InteractionContext context) {
        IPCInteraction interaction = PCRegistries.INTERACTIONS.get(id);
        if (interaction == null || !interaction.canPerform(context)) return InteractionResult.PASS;
        return interaction.perform(context);
    }
}
