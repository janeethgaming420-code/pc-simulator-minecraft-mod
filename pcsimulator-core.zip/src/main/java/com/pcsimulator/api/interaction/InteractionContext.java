package com.pcsimulator.api.interaction;

import com.pcsimulator.api.build.IPCBuild;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/** Everything an interaction needs. {@code build} is null if the target is not a PC host. */
public record InteractionContext(Player player, Level level, BlockPos pos, InteractionHand hand,
                                 ItemStack heldItem, @Nullable IPCBuild build) {
}
