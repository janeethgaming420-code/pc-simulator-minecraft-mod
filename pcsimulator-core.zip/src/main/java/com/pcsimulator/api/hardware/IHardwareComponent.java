package com.pcsimulator.api.hardware;

import net.minecraft.resources.ResourceLocation;

import java.util.Optional;
import java.util.Set;

/**
 * Immutable definition of one hardware model (e.g. "a mid-range 6-core CPU").
 *
 * <p>Registered in {@code PCRegistries.HARDWARE_COMPONENTS} by the hardware module. An ItemStack refers to a
 * definition through {@link IHardwareItem}. Definitions are stateless: runtime state (wear, firmware...) lives
 * in the build / item stack.
 *
 * <p>Units: prices in cents, power in watts.
 */
public interface IHardwareComponent {
    ComponentType type();

    ComponentTier tier();

    /** Reference shop price in cents. Actual prices are decided by the economy module. */
    long basePriceCents();

    /** Power consumed while running. PSUs return 0 and report capacity via {@link #powerOutputWatts()}. */
    int powerDrawWatts();

    /** Power delivered (PSUs only). */
    default int powerOutputWatts() {
        return 0;
    }

    /** Abstract performance score; the hardware module defines and documents the scale. */
    int performanceScore();

    /** The standard this component plugs into (CPU socket, RAM generation...). Empty = no constraint. */
    default Optional<ResourceLocation> connector() {
        return Optional.empty();
    }

    /** Connectors this component accepts from others (motherboards, cases). */
    default Set<ResourceLocation> acceptedConnectors() {
        return Set.of();
    }
}
