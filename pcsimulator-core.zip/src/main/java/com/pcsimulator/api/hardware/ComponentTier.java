package com.pcsimulator.api.hardware;

import com.mojang.serialization.Codec;
import net.minecraft.util.StringRepresentable;

import java.util.Locale;

public enum ComponentTier implements StringRepresentable {
    ENTRY, MID, HIGH, ENTHUSIAST;

    public static final Codec<ComponentTier> CODEC = StringRepresentable.fromEnum(ComponentTier::values);

    @Override
    public String getSerializedName() {
        return name().toLowerCase(Locale.ROOT);
    }
}
