package com.pcsimulator.api.hardware;

import com.mojang.serialization.Codec;
import net.minecraft.util.StringRepresentable;

import java.util.Locale;

/** Category of a hardware component. Each category maps to one kind of slot in a PC build. */
public enum ComponentType implements StringRepresentable {
    CASE, MOTHERBOARD, CPU, COOLER, RAM, GPU, STORAGE, PSU, NETWORK_CARD, PERIPHERAL;

    public static final Codec<ComponentType> CODEC = StringRepresentable.fromEnum(ComponentType::values);

    @Override
    public String getSerializedName() {
        return name().toLowerCase(Locale.ROOT);
    }
}
