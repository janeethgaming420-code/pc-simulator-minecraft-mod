package com.pcsimulator.api.hardware;

import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

/** Implemented by Items that represent hardware components. */
public interface IHardwareItem {
    /** The definition for this stack, or null if the stack carries none. */
    @Nullable
    IHardwareComponent getComponent(ItemStack stack);

    static Optional<IHardwareComponent> componentOf(ItemStack stack) {
        if (stack.getItem() instanceof IHardwareItem item) {
            return Optional.ofNullable(item.getComponent(stack));
        }
        return Optional.empty();
    }
}
