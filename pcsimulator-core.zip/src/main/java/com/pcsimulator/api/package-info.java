/**
 * PC Simulator public API.
 *
 * <p><b>Rules:</b> this package tree depends only on Minecraft/NeoForge. It must never import
 * {@code com.pcsimulator.core}, {@code com.pcsimulator.client} or any module package. Every other subsystem
 * may import it. Changes to signatures here are contract changes and must be agreed with Claude 7.
 */
package com.pcsimulator.api;
