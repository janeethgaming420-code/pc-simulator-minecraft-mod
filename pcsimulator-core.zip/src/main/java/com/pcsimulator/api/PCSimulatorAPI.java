package com.pcsimulator.api;

import com.pcsimulator.api.economy.IEconomyService;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.Supplier;

/** Entry point of the public API. */
public final class PCSimulatorAPI {
    public static final String MOD_ID = "pcsimulator";

    private static Supplier<IEconomyService> economyProvider;

    private PCSimulatorAPI() {}

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    /** Economy service of the running server. Server thread only. Throws if no server is running. */
    public static IEconomyService economy() {
        if (economyProvider == null) throw new IllegalStateException("PC Simulator API is not initialised yet");
        return economyProvider.get();
    }

    /** True if the world was created with the PC Simulator world type (detected via its dimension type). */
    public static boolean isPCWorld(MinecraftServer server) {
        return isPCWorld(server.overworld());
    }

    public static boolean isPCWorld(Level level) {
        return level.dimensionTypeRegistration().is(PCDimensionTypes.PC_OVERWORLD);
    }

    /** Called once by the core. Not for other subsystems. */
    @ApiStatus.Internal
    public static void bindEconomy(Supplier<IEconomyService> provider) {
        if (economyProvider != null) throw new IllegalStateException("Economy provider already bound");
        economyProvider = provider;
    }
}
