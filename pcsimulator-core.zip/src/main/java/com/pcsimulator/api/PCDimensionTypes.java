package com.pcsimulator.api;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.dimension.DimensionType;

public final class PCDimensionTypes {
    private PCDimensionTypes() {}

    /** data/pcsimulator/dimension_type/pc_overworld.json - marks overworlds of the PC Simulator world type. */
    public static final ResourceKey<DimensionType> PC_OVERWORLD =
            ResourceKey.create(Registries.DIMENSION_TYPE, PCSimulatorAPI.id("pc_overworld"));
}
