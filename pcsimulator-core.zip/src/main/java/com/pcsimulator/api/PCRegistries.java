package com.pcsimulator.api;

import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.api.interaction.IPCInteraction;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.RegistryBuilder;

/**
 * Keys and instances of the custom registries owned by the core.
 *
 * <p>The {@link Registry} objects are created here but only become active when the core registers them in
 * {@code NewRegistryEvent}. Entries are added through the shared {@code DeferredRegister}s in
 * {@code CoreRegistries} - never create a second DeferredRegister for these keys.
 */
public final class PCRegistries {
    private PCRegistries() {}

    public static final ResourceKey<Registry<IHardwareComponent>> HARDWARE_COMPONENT_KEY =
            ResourceKey.createRegistryKey(PCSimulatorAPI.id("hardware_component"));
    public static final ResourceKey<Registry<IPCInteraction>> INTERACTION_KEY =
            ResourceKey.createRegistryKey(PCSimulatorAPI.id("interaction"));

    /** Hardware definitions (CPU models, GPU models...). Entry owner: hardware module. */
    public static final Registry<IHardwareComponent> HARDWARE_COMPONENTS =
            new RegistryBuilder<>(HARDWARE_COMPONENT_KEY).sync(true).create();

    /** PC interactions (power on, open BIOS, install part...). Entry owner: pcbuild module. */
    public static final Registry<IPCInteraction> INTERACTIONS =
            new RegistryBuilder<>(INTERACTION_KEY).sync(true).create();

    public static ResourceLocation hardwareId(IHardwareComponent component) {
        ResourceLocation key = HARDWARE_COMPONENTS.getKey(component);
        if (key == null) throw new IllegalArgumentException("Hardware component is not registered: " + component);
        return key;
    }
}
