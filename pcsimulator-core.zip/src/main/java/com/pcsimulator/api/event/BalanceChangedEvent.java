package com.pcsimulator.api.event;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.Event;

import java.util.UUID;

/** Posted on {@code NeoForge.EVENT_BUS} after a balance changed (server side). Not cancellable. */
public class BalanceChangedEvent extends Event {
    private final UUID account;
    private final long oldBalance;
    private final long newBalance;
    private final ResourceLocation reason;

    public BalanceChangedEvent(UUID account, long oldBalance, long newBalance, ResourceLocation reason) {
        this.account = account;
        this.oldBalance = oldBalance;
        this.newBalance = newBalance;
        this.reason = reason;
    }

    public UUID getAccount() { return account; }
    public long getOldBalance() { return oldBalance; }
    public long getNewBalance() { return newBalance; }
    public ResourceLocation getReason() { return reason; }
}
