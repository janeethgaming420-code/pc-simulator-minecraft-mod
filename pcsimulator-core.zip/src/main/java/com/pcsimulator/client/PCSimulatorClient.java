package com.pcsimulator.client;

import com.pcsimulator.PCSimulator;
import com.pcsimulator.core.module.ModuleLoader;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;

/** Client-only entry point. Only core client wiring lives here; screens/renderers belong to the modules. */
@Mod(value = PCSimulator.MOD_ID, dist = Dist.CLIENT)
public final class PCSimulatorClient {
    public PCSimulatorClient(IEventBus modBus, ModContainer container) {
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
        ModuleLoader.registerClientAll(modBus, container);
    }
}
