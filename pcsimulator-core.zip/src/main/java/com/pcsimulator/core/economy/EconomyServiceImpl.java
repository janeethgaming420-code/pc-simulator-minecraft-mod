package com.pcsimulator.core.economy;

import com.pcsimulator.api.economy.IEconomyService;
import com.pcsimulator.api.economy.TransactionResult;
import com.pcsimulator.api.event.BalanceChangedEvent;
import com.pcsimulator.core.config.PCConfig;
import com.pcsimulator.core.data.PCWorldData;
import com.pcsimulator.core.network.PCNetwork;
import com.pcsimulator.core.network.SyncBalancePayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.NeoForge;

import java.util.UUID;

/** Core implementation of {@link IEconomyService}, bound to one running server. */
public final class EconomyServiceImpl implements IEconomyService {
    private static volatile EconomyServiceImpl current;

    private final MinecraftServer server;
    private final EconomySavedData data;

    private EconomyServiceImpl(MinecraftServer server) {
        this.server = server;
        this.data = PCWorldData.get(server, "core", "economy", EconomySavedData.factory());
    }

    public static void bind(MinecraftServer server) {
        current = new EconomyServiceImpl(server);
    }

    public static void unbind() {
        current = null;
    }

    public static EconomyServiceImpl current() {
        EconomyServiceImpl c = current;
        if (c == null) throw new IllegalStateException("No PC Simulator server is running");
        return c;
    }

    /** Creates the account with the configured starting balance if it does not exist yet. */
    public void ensureAccount(ServerPlayer player, ResourceLocation reason) {
        UUID id = player.getUUID();
        if (!data.has(id)) {
            apply(id, PCConfig.SERVER.startingBalanceCents.get(), reason);
        } else {
            sync(id, data.get(id));
        }
    }

    @Override
    public boolean hasAccount(UUID account) {
        return data.has(account);
    }

    @Override
    public long getBalance(UUID account) {
        return data.get(account);
    }

    @Override
    public TransactionResult deposit(UUID account, long cents, ResourceLocation reason) {
        if (cents <= 0) return TransactionResult.INVALID_AMOUNT;
        long old = data.get(account);
        if (old > max() - cents) return TransactionResult.BALANCE_LIMIT;
        apply(account, old + cents, reason);
        return TransactionResult.SUCCESS;
    }

    @Override
    public TransactionResult withdraw(UUID account, long cents, ResourceLocation reason) {
        if (cents <= 0) return TransactionResult.INVALID_AMOUNT;
        long old = data.get(account);
        if (old < cents) return TransactionResult.INSUFFICIENT_FUNDS;
        apply(account, old - cents, reason);
        return TransactionResult.SUCCESS;
    }

    @Override
    public TransactionResult transfer(UUID from, UUID to, long cents, ResourceLocation reason) {
        if (cents <= 0) return TransactionResult.INVALID_AMOUNT;
        if (from.equals(to)) return TransactionResult.SAME_ACCOUNT;
        if (data.get(from) < cents) return TransactionResult.INSUFFICIENT_FUNDS;
        if (data.get(to) > max() - cents) return TransactionResult.BALANCE_LIMIT;
        // both checks passed on the server thread: the two steps below cannot fail
        withdraw(from, cents, reason);
        deposit(to, cents, reason);
        return TransactionResult.SUCCESS;
    }

    @Override
    public void setBalance(UUID account, long cents, ResourceLocation reason) {
        apply(account, Math.max(0L, Math.min(cents, max())), reason);
    }

    @Override
    public String format(long cents) {
        return MoneyFormat.format(cents);
    }

    private long max() {
        return PCConfig.SERVER.maxBalanceCents.get();
    }

    private void apply(UUID account, long newBalance, ResourceLocation reason) {
        long old = data.get(account);
        data.put(account, newBalance);
        NeoForge.EVENT_BUS.post(new BalanceChangedEvent(account, old, newBalance, reason));
        sync(account, newBalance);
    }

    private void sync(UUID account, long balance) {
        ServerPlayer player = server.getPlayerList().getPlayer(account);
        if (player != null) PCNetwork.sendToPlayer(player, new SyncBalancePayload(balance));
    }
}
