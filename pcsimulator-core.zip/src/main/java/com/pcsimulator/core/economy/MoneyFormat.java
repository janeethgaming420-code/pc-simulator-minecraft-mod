package com.pcsimulator.core.economy;

import com.pcsimulator.core.config.PCConfig;

public final class MoneyFormat {
    private MoneyFormat() {}

    public static String format(long cents) {
        long abs = Math.abs(cents);
        String sign = cents < 0 ? "-" : "";
        return String.format("%s%s%d.%02d", sign, PCConfig.COMMON.currencySymbol.get(), abs / 100, abs % 100);
    }
}
