package com.pcsimulator.core.economy;

/** Client-side mirror of the local player's balance. Plain class (no client-only imports). */
public final class ClientBalanceCache {
    private ClientBalanceCache() {}

    private static volatile long balanceCents;

    public static long get() {
        return balanceCents;
    }

    public static void set(long cents) {
        balanceCents = cents;
    }
}
