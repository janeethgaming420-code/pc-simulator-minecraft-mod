package com.pcsimulator.core.economy;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Persistent account balances (cents), stored in the overworld data storage. */
public final class EconomySavedData extends SavedData {
    private static final int VERSION = 1;

    private final Map<UUID, Long> balances = new HashMap<>();

    public static SavedData.Factory<EconomySavedData> factory() {
        return new SavedData.Factory<>(EconomySavedData::new, EconomySavedData::load);
    }

    private static EconomySavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        EconomySavedData data = new EconomySavedData();
        ListTag list = tag.getList("accounts", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            data.balances.put(entry.getUUID("id"), entry.getLong("balance"));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putInt("version", VERSION);
        ListTag list = new ListTag();
        balances.forEach((id, balance) -> {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("id", id);
            entry.putLong("balance", balance);
            list.add(entry);
        });
        tag.put("accounts", list);
        return tag;
    }

    boolean has(java.util.UUID id) {
        return balances.containsKey(id);
    }

    long get(UUID id) {
        return balances.getOrDefault(id, 0L);
    }

    void put(UUID id, long cents) {
        balances.put(id, cents);
        setDirty();
    }
}
