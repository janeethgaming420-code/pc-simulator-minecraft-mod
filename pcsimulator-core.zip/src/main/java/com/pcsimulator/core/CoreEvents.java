package com.pcsimulator.core;

import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.core.data.PCWorldData;
import com.pcsimulator.core.data.WorldMetaSavedData;
import com.pcsimulator.core.economy.EconomyServiceImpl;
import com.pcsimulator.core.module.ModuleLoader;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;

/** Game-bus lifecycle handlers owned by the core. Modules get their hooks through {@code PCModule}. */
public final class CoreEvents {
    private CoreEvents() {}

    public static void onServerStarting(ServerStartingEvent event) {
        var server = event.getServer();
        WorldMetaSavedData meta = PCWorldData.get(server, "core", "meta", WorldMetaSavedData.factory());
        if (!meta.isInitialised()) {
            meta.initialise(PCSimulatorAPI.isPCWorld(server));
        }
        EconomyServiceImpl.bind(server);
    }

    public static void onServerStarted(ServerStartedEvent event) {
        ModuleLoader.modules().forEach(m -> m.onServerStarted(event.getServer()));
    }

    public static void onServerStopped(ServerStoppedEvent event) {
        ModuleLoader.modules().forEach(m -> m.onServerStopped(event.getServer()));
        EconomyServiceImpl.unbind();
    }

    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            EconomyServiceImpl.current().ensureAccount(player, PCSimulatorAPI.id("first_join"));
        }
    }
}
