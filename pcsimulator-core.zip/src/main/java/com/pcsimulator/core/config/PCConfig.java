package com.pcsimulator.core.config;

import net.neoforged.fml.ModContainer;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * Core configuration. Three files:
 * <ul>
 *   <li>COMMON  - config/pcsimulator-common.toml (both sides, loaded at startup)</li>
 *   <li>SERVER  - world/serverconfig/pcsimulator-server.toml (per world, synced; only readable once a world is loading)</li>
 *   <li>CLIENT  - config/pcsimulator-client.toml (client only)</li>
 * </ul>
 * Modules register their OWN specs with {@link #registerModuleConfig}; they do not add values here.
 */
public final class PCConfig {
    private PCConfig() {}

    public static final class Common {
        public final ModConfigSpec spec;
        public final ModConfigSpec.BooleanValue debugLogging;
        public final ModConfigSpec.ConfigValue<String> currencySymbol;

        private Common(ModConfigSpec.Builder b) {
            b.push("general");
            debugLogging = b.comment("Verbose logging for development.")
                    .translation("pcsimulator.configuration.debugLogging").define("debugLogging", false);
            b.pop();
            b.push("economy");
            currencySymbol = b.comment("Symbol shown in front of money amounts.")
                    .translation("pcsimulator.configuration.currencySymbol").define("currencySymbol", "$");
            b.pop();
            spec = b.build();
        }
    }

    public static final class Server {
        public final ModConfigSpec spec;
        public final ModConfigSpec.LongValue startingBalanceCents;
        public final ModConfigSpec.LongValue maxBalanceCents;

        private Server(ModConfigSpec.Builder b) {
            b.push("economy");
            startingBalanceCents = b.comment("Balance (in cents) a player receives the first time they join a world.")
                    .translation("pcsimulator.configuration.startingBalanceCents")
                    .defineInRange("startingBalanceCents", 100_000L, 0L, MAX_BALANCE_LIMIT);
            maxBalanceCents = b.comment("Hard cap for any balance (in cents).")
                    .translation("pcsimulator.configuration.maxBalanceCents")
                    .defineInRange("maxBalanceCents", 1_000_000_000_000L, 1L, MAX_BALANCE_LIMIT);
            b.pop();
            spec = b.build();
        }
    }

    public static final class Client {
        public final ModConfigSpec spec;
        public final ModConfigSpec.BooleanValue showBalanceHud;

        private Client(ModConfigSpec.Builder b) {
            b.push("ui");
            showBalanceHud = b.comment("Show the money balance on the HUD (consumed by the UI module).")
                    .translation("pcsimulator.configuration.showBalanceHud").define("showBalanceHud", true);
            b.pop();
            spec = b.build();
        }
    }

    /** Keeps long arithmetic in the economy safe from overflow (Long.MAX_VALUE / 4). */
    public static final long MAX_BALANCE_LIMIT = Long.MAX_VALUE / 4;

    public static final Common COMMON = new Common(new ModConfigSpec.Builder());
    public static final Server SERVER = new Server(new ModConfigSpec.Builder());
    public static final Client CLIENT = new Client(new ModConfigSpec.Builder());

    public static void register(ModContainer container) {
        container.registerConfig(ModConfig.Type.COMMON, COMMON.spec);
        container.registerConfig(ModConfig.Type.SERVER, SERVER.spec);
        container.registerConfig(ModConfig.Type.CLIENT, CLIENT.spec);
    }

    /**
     * Registers a module-owned spec as {@code pcsimulator/<moduleId>-<type>.toml}.
     * Call from {@code PCModule#register}.
     */
    public static void registerModuleConfig(ModContainer container, String moduleId, ModConfig.Type type, ModConfigSpec spec) {
        String file = "pcsimulator/" + moduleId + "-" + type.name().toLowerCase(java.util.Locale.ROOT) + ".toml";
        container.registerConfig(type, spec, file);
    }
}
