package com.pcsimulator.core.registry;

import net.minecraft.core.UUIDUtil;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredHolder;

import java.util.UUID;

/** Shared item data components used across modules. Owner: core. */
public final class CoreDataComponents {
    private CoreDataComponents() {}

    /** Identity of the PC build an item/stack belongs to. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<UUID>> BUILD_ID =
            CoreRegistries.DATA_COMPONENTS.<UUID>registerComponentType("build_id",
                    b -> b.persistent(UUIDUtil.CODEC).networkSynchronized(UUIDUtil.STREAM_CODEC));

    /** Id of the IHardwareComponent definition an item stack represents. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<ResourceLocation>> HARDWARE_ID =
            CoreRegistries.DATA_COMPONENTS.<ResourceLocation>registerComponentType("hardware_id",
                    b -> b.persistent(ResourceLocation.CODEC).networkSynchronized(ResourceLocation.STREAM_CODEC));

    /** Force class-loading so the entries are added before RegisterEvent fires. */
    public static void init() {}
}
