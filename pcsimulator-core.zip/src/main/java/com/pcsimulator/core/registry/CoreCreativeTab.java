package com.pcsimulator.core.registry;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.neoforged.neoforge.registries.DeferredHolder;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** The single creative tab. Modules add items with {@link #add}; nobody else creates a tab. */
public final class CoreCreativeTab {
    private CoreCreativeTab() {}

    private static final List<Supplier<? extends ItemLike>> ENTRIES = new ArrayList<>();

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN =
            CoreRegistries.CREATIVE_TABS.register("main", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.pcsimulator"))
                    .icon(() -> new ItemStack(Items.COMPARATOR)) // placeholder until a real item exists
                    .displayItems((params, output) -> ENTRIES.forEach(s -> output.accept(s.get())))
                    .build());

    /** Call during module registration (mod constructor). Display order = call order. */
    public static void add(Supplier<? extends ItemLike> item) {
        ENTRIES.add(item);
    }

    public static void init() {}
}
