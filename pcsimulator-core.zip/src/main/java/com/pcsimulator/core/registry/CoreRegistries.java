package com.pcsimulator.core.registry;

import com.pcsimulator.api.PCRegistries;
import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.api.interaction.IPCInteraction;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.NewRegistryEvent;

/**
 * THE shared DeferredRegisters of the mod. Registry ownership rule: the core owns every DeferredRegister
 * instance; modules only ADD ENTRIES to them (from their own static holder classes). No module creates its own
 * DeferredRegister for these registries.
 */
public final class CoreRegistries {
    private CoreRegistries() {}

    private static final String ID = PCSimulatorAPI.MOD_ID;

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, ID);
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(Registries.ENTITY_TYPE, ID);
    public static final DeferredRegister<MenuType<?>> MENU_TYPES = DeferredRegister.create(Registries.MENU, ID);
    public static final DeferredRegister.DataComponents DATA_COMPONENTS = DeferredRegister.createDataComponents(ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS = DeferredRegister.create(Registries.SOUND_EVENT, ID);
    public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES = DeferredRegister.create(Registries.RECIPE_TYPE, ID);
    public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS = DeferredRegister.create(Registries.RECIPE_SERIALIZER, ID);
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES = DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, ID);

    // custom registries (see com.pcsimulator.api.PCRegistries)
    public static final DeferredRegister<IHardwareComponent> HARDWARE_COMPONENTS = DeferredRegister.create(PCRegistries.HARDWARE_COMPONENT_KEY, ID);
    public static final DeferredRegister<IPCInteraction> INTERACTIONS = DeferredRegister.create(PCRegistries.INTERACTION_KEY, ID);

    /** Attaches every register to the mod bus. Called exactly once, from the mod constructor. */
    public static void registerAll(IEventBus modBus) {
        modBus.addListener(CoreRegistries::onNewRegistry);
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITY_TYPES.register(modBus);
        ENTITY_TYPES.register(modBus);
        MENU_TYPES.register(modBus);
        DATA_COMPONENTS.register(modBus);
        CREATIVE_TABS.register(modBus);
        SOUND_EVENTS.register(modBus);
        RECIPE_TYPES.register(modBus);
        RECIPE_SERIALIZERS.register(modBus);
        ATTACHMENT_TYPES.register(modBus);
        HARDWARE_COMPONENTS.register(modBus);
        INTERACTIONS.register(modBus);
    }

    private static void onNewRegistry(NewRegistryEvent event) {
        event.register(PCRegistries.HARDWARE_COMPONENTS);
        event.register(PCRegistries.INTERACTIONS);
    }
}
