package com.pcsimulator.core.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;

/** Per-world metadata: data schema version (for future migrations) and whether it is a PC Simulator world. */
public final class WorldMetaSavedData extends SavedData {
    public static final int CURRENT_SCHEMA = 1;

    private int schema = CURRENT_SCHEMA;
    private boolean pcWorldAtCreation;
    private boolean initialised;

    public static SavedData.Factory<WorldMetaSavedData> factory() {
        return new SavedData.Factory<>(WorldMetaSavedData::new, WorldMetaSavedData::load);
    }

    private static WorldMetaSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        WorldMetaSavedData d = new WorldMetaSavedData();
        d.schema = tag.getInt("schema");
        d.pcWorldAtCreation = tag.getBoolean("pcWorld");
        d.initialised = tag.getBoolean("initialised");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putInt("schema", schema);
        tag.putBoolean("pcWorld", pcWorldAtCreation);
        tag.putBoolean("initialised", initialised);
        return tag;
    }

    public int schema() { return schema; }

    public boolean wasPCWorldAtFirstLoad() { return pcWorldAtCreation; }

    public boolean isInitialised() { return initialised; }

    public void initialise(boolean pcWorld) {
        this.initialised = true;
        this.pcWorldAtCreation = pcWorld;
        this.schema = CURRENT_SCHEMA;
        setDirty();
    }
}
