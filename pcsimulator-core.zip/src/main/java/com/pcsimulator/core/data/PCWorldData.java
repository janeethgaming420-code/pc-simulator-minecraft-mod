package com.pcsimulator.core.data;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Persistence facade. World-global data = {@link SavedData} in the OVERWORLD's data storage (one copy per world,
 * independent of which dimension the player is in). Files are namespaced as
 * {@code data/pcsimulator_<moduleId>_<name>.dat}.
 *
 * <p>Guidelines: per-block data -> BlockEntity; per-player data -> NeoForge data attachments
 * ({@code CoreRegistries.ATTACHMENT_TYPES}); per-world global data -> this class. Server thread only.
 * Always call {@code setDirty()} after mutating a SavedData.
 */
public final class PCWorldData {
    private PCWorldData() {}

    public static <T extends SavedData> T get(MinecraftServer server, String moduleId, String name, SavedData.Factory<T> factory) {
        return server.overworld().getDataStorage().computeIfAbsent(factory, "pcsimulator_" + moduleId + "_" + name);
    }
}
