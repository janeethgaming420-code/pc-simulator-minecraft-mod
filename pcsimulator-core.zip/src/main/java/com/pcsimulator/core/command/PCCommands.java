package com.pcsimulator.core.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.api.economy.TransactionResult;
import com.pcsimulator.core.economy.EconomyServiceImpl;
import com.pcsimulator.core.module.ModuleLoader;
import com.pcsimulator.core.module.PCModule;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.stream.Collectors;

/** /pcsim balance [player] | economy give|set <player> <cents> (op) | info */
public final class PCCommands {
    private PCCommands() {}

    private static final ResourceLocation REASON = PCSimulatorAPI.id("command");

    public static void onRegisterCommands(RegisterCommandsEvent event) {
        register(event.getDispatcher());
    }

    private static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("pcsim")
                .then(Commands.literal("info").executes(ctx -> info(ctx.getSource())))
                .then(Commands.literal("balance")
                        .executes(ctx -> balance(ctx.getSource(), ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .requires(s -> s.hasPermission(2))
                                .executes(ctx -> balance(ctx.getSource(), EntityArgument.getPlayer(ctx, "player")))))
                .then(Commands.literal("economy").requires(s -> s.hasPermission(2))
                        .then(Commands.literal("give").then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("cents", LongArgumentType.longArg(1))
                                        .executes(ctx -> give(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"),
                                                LongArgumentType.getLong(ctx, "cents"))))))
                        .then(Commands.literal("set").then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("cents", LongArgumentType.longArg(0))
                                        .executes(ctx -> set(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"),
                                                LongArgumentType.getLong(ctx, "cents"))))))));
    }

    private static int info(CommandSourceStack src) {
        String modules = ModuleLoader.modules().stream().map(PCModule::id).collect(Collectors.joining(", "));
        String version = ModList.get().getModContainerById(PCSimulatorAPI.MOD_ID)
                .map(c -> c.getModInfo().getVersion().toString()).orElse("?");
        boolean pc = PCSimulatorAPI.isPCWorld(src.getServer());
        src.sendSuccess(() -> Component.translatable("commands.pcsimulator.info", version, pc,
                modules.isEmpty() ? "none" : modules), false);
        return 1;
    }

    private static int balance(CommandSourceStack src, ServerPlayer target) throws CommandSyntaxException {
        var eco = EconomyServiceImpl.current();
        String money = eco.format(eco.getBalance(target.getUUID()));
        boolean self = src.getPlayer() != null && src.getPlayer().getUUID().equals(target.getUUID());
        src.sendSuccess(() -> self
                ? Component.translatable("commands.pcsimulator.balance.self", money)
                : Component.translatable("commands.pcsimulator.balance.other", target.getDisplayName(), money), false);
        return 1;
    }

    private static int give(CommandSourceStack src, ServerPlayer target, long cents) {
        var eco = EconomyServiceImpl.current();
        TransactionResult r = eco.deposit(target.getUUID(), cents, REASON);
        if (!r.isSuccess()) return fail(src, r);
        src.sendSuccess(() -> Component.translatable("commands.pcsimulator.economy.give", eco.format(cents), target.getDisplayName()), true);
        return 1;
    }

    private static int set(CommandSourceStack src, ServerPlayer target, long cents) {
        var eco = EconomyServiceImpl.current();
        eco.setBalance(target.getUUID(), cents, REASON);
        src.sendSuccess(() -> Component.translatable("commands.pcsimulator.economy.set", target.getDisplayName(),
                eco.format(eco.getBalance(target.getUUID()))), true);
        return 1;
    }

    private static int fail(CommandSourceStack src, TransactionResult r) {
        src.sendFailure(Component.translatable("commands.pcsimulator.economy.failed", r.name()));
        return 0;
    }
}
