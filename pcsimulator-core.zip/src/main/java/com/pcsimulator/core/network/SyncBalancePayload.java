package com.pcsimulator.core.network;

import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.core.economy.ClientBalanceCache;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: the receiving player's current balance in cents. */
public record SyncBalancePayload(long balanceCents) implements CustomPacketPayload {
    public static final Type<SyncBalancePayload> TYPE = new Type<>(PCSimulatorAPI.id("core/sync_balance"));
    public static final StreamCodec<ByteBuf, SyncBalancePayload> STREAM_CODEC =
            ByteBufCodecs.VAR_LONG.map(SyncBalancePayload::new, SyncBalancePayload::balanceCents);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SyncBalancePayload payload, IPayloadContext context) {
        ClientBalanceCache.set(payload.balanceCents());
    }
}
