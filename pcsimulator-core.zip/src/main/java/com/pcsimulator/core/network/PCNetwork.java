package com.pcsimulator.core.network;

import com.pcsimulator.core.module.ModuleLoader;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

/**
 * Networking infrastructure.
 *
 * <p>Conventions:
 * <ul>
 *   <li>Payload = a {@code record} implementing {@link CustomPacketPayload} in the owning module's {@code network} package.</li>
 *   <li>Payload ids live in the {@code pcsimulator} namespace; prefix the path with the module id (e.g. {@code economy/shop_buy}).</li>
 *   <li>Server handlers MUST validate everything (range, permission, ownership) - never trust the client.</li>
 *   <li>Client handlers must delegate to a class that is safe to load on a dedicated server unless it is only
 *       referenced inside the lambda of a client-only path.</li>
 *   <li>Changing any payload layout => bump {@link #PROTOCOL_VERSION}.</li>
 * </ul>
 */
public final class PCNetwork {
    private PCNetwork() {}

    public static final String PROTOCOL_VERSION = "1";

    public static void onRegisterPayloads(RegisterPayloadHandlersEvent event) {
        PacketRegistrar registrar = new PacketRegistrar(event.registrar(PROTOCOL_VERSION));
        // core packets
        registrar.toClient(SyncBalancePayload.TYPE, SyncBalancePayload.STREAM_CODEC, SyncBalancePayload::handle);
        // module packets
        ModuleLoader.modules().forEach(m -> m.registerPackets(registrar));
    }

    public static void sendToPlayer(ServerPlayer player, CustomPacketPayload payload) {
        PacketDistributor.sendToPlayer(player, payload);
    }

    public static void sendToServer(CustomPacketPayload payload) {
        PacketDistributor.sendToServer(payload);
    }
}
