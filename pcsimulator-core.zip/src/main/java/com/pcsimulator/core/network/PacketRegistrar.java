package com.pcsimulator.core.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.handling.IPayloadHandler;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Thin wrapper over NeoForge's {@link PayloadRegistrar}. Every module registers its payloads through this in
 * {@code PCModule#registerPackets}; all share ONE protocol version ({@link PCNetwork#PROTOCOL_VERSION}).
 * Handlers run on the main thread (NeoForge default), so they may touch the world directly.
 */
public final class PacketRegistrar {
    private PayloadRegistrar delegate;

    PacketRegistrar(PayloadRegistrar delegate) {
        this.delegate = delegate;
    }

    public <T extends CustomPacketPayload> PacketRegistrar toClient(CustomPacketPayload.Type<T> type,
            StreamCodec<? super RegistryFriendlyByteBuf, T> codec, IPayloadHandler<T> handler) {
        delegate = delegate.playToClient(type, codec, handler);
        return this;
    }

    public <T extends CustomPacketPayload> PacketRegistrar toServer(CustomPacketPayload.Type<T> type,
            StreamCodec<? super RegistryFriendlyByteBuf, T> codec, IPayloadHandler<T> handler) {
        delegate = delegate.playToServer(type, codec, handler);
        return this;
    }

    public <T extends CustomPacketPayload> PacketRegistrar bidirectional(CustomPacketPayload.Type<T> type,
            StreamCodec<? super RegistryFriendlyByteBuf, T> codec, IPayloadHandler<T> handler) {
        delegate = delegate.playBidirectional(type, codec, handler);
        return this;
    }
}
