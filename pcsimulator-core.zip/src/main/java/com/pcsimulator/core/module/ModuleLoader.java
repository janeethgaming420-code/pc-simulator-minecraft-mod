package com.pcsimulator.core.module;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Resolves, orders and bootstraps {@link PCModule}s. Fails fast with a message naming the module. */
public final class ModuleLoader {
    private ModuleLoader() {}

    private static List<PCModule> modules;

    public static synchronized List<PCModule> modules() {
        if (modules == null) modules = resolve(ModuleList.create());
        return modules;
    }

    public static void registerAll(IEventBus modBus, ModContainer container, Dist dist) {
        for (PCModule module : modules()) {
            try {
                module.register(modBus, container, dist);
            } catch (RuntimeException e) {
                throw new IllegalStateException("Module '" + module.id() + "' failed during register()", e);
            }
        }
    }

    public static void registerClientAll(IEventBus modBus, ModContainer container) {
        for (PCModule module : modules()) {
            try {
                module.registerClient(modBus, container);
            } catch (RuntimeException e) {
                throw new IllegalStateException("Module '" + module.id() + "' failed during registerClient()", e);
            }
        }
    }

    private static List<PCModule> resolve(List<PCModule> declared) {
        Map<String, PCModule> byId = new LinkedHashMap<>();
        for (PCModule m : declared) {
            if (byId.put(m.id(), m) != null) throw new IllegalStateException("Duplicate module id: " + m.id());
        }
        List<PCModule> ordered = new ArrayList<>();
        Set<String> visiting = new HashSet<>();
        Set<String> done = new HashSet<>();
        for (PCModule m : byId.values()) visit(m, byId, visiting, done, ordered);
        return List.copyOf(ordered);
    }

    private static void visit(PCModule m, Map<String, PCModule> byId, Set<String> visiting, Set<String> done, List<PCModule> out) {
        if (done.contains(m.id())) return;
        if (!visiting.add(m.id())) throw new IllegalStateException("Module dependency cycle at '" + m.id() + "'");
        for (String dep : m.dependsOn()) {
            PCModule d = byId.get(dep);
            if (d == null) throw new IllegalStateException("Module '" + m.id() + "' depends on unknown module '" + dep + "'");
            visit(d, byId, visiting, done, out);
        }
        visiting.remove(m.id());
        done.add(m.id());
        out.add(m);
    }
}
