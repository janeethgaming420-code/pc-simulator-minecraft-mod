package com.pcsimulator.core.module;

import java.util.List;

/**
 * The ONLY place where modules are listed. Claude 7 adds one line per finished module, e.g.
 * <pre>
 *   new com.pcsimulator.hardware.HardwareModule(),
 *   new com.pcsimulator.pcbuild.PCBuildModule(),
 * </pre>
 * Order does not matter; {@link ModuleLoader} sorts by {@link PCModule#dependsOn()}.
 */
final class ModuleList {
    private ModuleList() {}

    static List<PCModule> create() {
        return List.of(
                // module instances go here
        );
    }
}
