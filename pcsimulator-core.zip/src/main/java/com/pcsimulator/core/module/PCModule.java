package com.pcsimulator.core.module;

import com.pcsimulator.core.network.PacketRegistrar;
import net.minecraft.server.MinecraftServer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

import java.util.List;

/**
 * Entry point of a subsystem (Claude 2-6 each implement exactly one). Hooks are invoked by the core in
 * dependency order. A module must NOT register its own @Mod / event subscribers for things covered here.
 */
public interface PCModule {
    /** Unique lowercase id, see {@link ModuleIds}. Also the sub-package name. */
    String id();

    /** Ids of modules that must be initialised first. Keep this graph minimal and acyclic. */
    default List<String> dependsOn() {
        return List.of();
    }

    /**
     * Mod constructor, both sides. Add entries to {@code CoreRegistries.*} here (touch your static holder
     * classes), register module configs, add items to {@code CoreCreativeTab}, subscribe to mod/game bus events.
     */
    void register(IEventBus modBus, ModContainer container, Dist dist);

    /** Client constructor only (screens, renderers, key mappings: register listeners on modBus). */
    default void registerClient(IEventBus modBus, ModContainer container) {}

    default void registerPackets(PacketRegistrar registrar) {}

    default void registerCapabilities(RegisterCapabilitiesEvent event) {}

    default void onServerStarted(MinecraftServer server) {}

    default void onServerStopped(MinecraftServer server) {}
}
