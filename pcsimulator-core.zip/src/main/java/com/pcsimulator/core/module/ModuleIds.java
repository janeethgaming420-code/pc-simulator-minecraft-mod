package com.pcsimulator.core.module;

/** Canonical module ids. Package: com.pcsimulator.<id>. Assignment to Claude instances is in docs/ARCHITECTURE.md. */
public final class ModuleIds {
    private ModuleIds() {}

    public static final String HARDWARE = "hardware";
    public static final String PCBUILD = "pcbuild";
    public static final String ECONOMY = "economy";
    public static final String UI = "ui";
    public static final String WORLD = "world";
}
