# PC Simulator – Core Architecture (Claude 1)

Minecraft 1.21.1 · NeoForge 21.1.x · Java 21 · mod id `pcsimulator` · base package `com.pcsimulator`

## 1. Layers and dependency rules

```
 api  (interfaces, enums, records, registry keys)      depends on: Minecraft + NeoForge only
  ^
 core (init, registries, config, network, data, eco)   depends on: api
  ^
 modules: hardware, pcbuild, economy, ui, world         depends on: api + core.{registry,network,config,module}
 client/PCSimulatorClient (core client wiring)
```
1. `api` never imports `core`, `client` or a module.
2. A module never imports another module's packages. Cross-module communication = `api` interfaces, custom registries, capabilities, events.
3. Module-to-module *load order* is declared through `PCModule#dependsOn()` (acyclic; checked at startup).
4. Client-only classes (screens, renderers) live in `com.pcsimulator.<module>.client` and are touched only from `PCModule#registerClient` or `@OnlyIn`-safe paths.

## 2. Package conventions

| Package | Purpose |
|---|---|
| `com.pcsimulator.api.*` | Public contracts (hardware, build, interaction, economy, event) |
| `com.pcsimulator.core.*` | Core implementation (`registry`, `config`, `network`, `data`, `economy`, `command`, `module`) |
| `com.pcsimulator.<moduleId>` | One module (`hardware`, `pcbuild`, `economy`, `ui`, `world`). Sub-packages: `block`, `item`, `entity`, `network`, `data`, `client`, `menu` |
| `com.pcsimulator.client` | Core client entry only |

Resources: `assets/pcsimulator/…`, `data/pcsimulator/…`. Registry names are `snake_case`; a module may prefix with a short word to avoid clashes (`cpu_basic`, not `basic`). Network payload ids: `pcsimulator:<moduleId>/<name>`.

## 3. Proposed module ownership (confirm with Claude 7)

| Module id | Owner | Owns (registry entries / APIs implemented) |
|---|---|---|
| `hardware` | Claude 2 | `IHardwareComponent` entries, hardware items, `IHardwareItem` |
| `pcbuild` | Claude 3 | PC/case blocks + block entities, `IPCBuild`, `PC_BUILD` capability providers, `IPCInteraction` entries, boot logic |
| `economy` | Claude 4 | shops, prices, income, jobs; uses `IEconomyService` (does **not** store balances itself) |
| `ui` | Claude 5 | menus, screens, HUD (reads `ClientBalanceCache`, `PCConfig.CLIENT`) |
| `world` | Claude 6 | structures/NPCs/content on top of the PC Simulator world type |

## 4. Registry ownership

* The **core owns every `DeferredRegister`** (`CoreRegistries`). Modules add entries from their own static holder classes, e.g.
  `public static final DeferredBlock<Block> PC = CoreRegistries.BLOCKS.registerBlock("pc", PcBlock::new, props);`
* Custom registries (created by core, entries added by modules):
  * `pcsimulator:hardware_component` → `IHardwareComponent` (owner: hardware)
  * `pcsimulator:interaction` → `IPCInteraction` (owner: pcbuild)
* One creative tab: `CoreCreativeTab.add(() -> item)` (no module creates its own tab).
* Shared data components: `CoreDataComponents.BUILD_ID`, `HARDWARE_ID`. A module needing another component adds it to `CoreRegistries.DATA_COMPONENTS` in its own holder class.
* Holder classes must be loaded during `PCModule#register` (call `MyRegistries.init()` – an empty static method – so the static fields run before `RegisterEvent`).
* Duplicate-prevention: ids are unique per registry; a module only registers ids inside its own domain (table above).

## 5. Lifecycle

```
Mod constructor (PCSimulator)
  1 PCConfig.register           COMMON / SERVER / CLIENT specs
  2 PCSimulatorAPI.bindEconomy
  3 CoreRegistries.registerAll  all DeferredRegisters + NewRegistryEvent listener
  4 ModuleLoader.registerAll    PCModule#register in dependency order
  5 mod-bus: RegisterPayloadHandlersEvent -> PCNetwork (core + PCModule#registerPackets)
            RegisterCapabilitiesEvent    -> PCModule#registerCapabilities
  6 game-bus: ServerStarting (world meta + economy bind), ServerStarted/Stopped (module hooks),
              PlayerLoggedIn (account + balance sync), RegisterCommands
Client constructor (PCSimulatorClient)
  config screen + PCModule#registerClient
```

## 6. Persistence

| Data | Where | API |
|---|---|---|
| Per block (PC contents) | `BlockEntity` NBT | `IPCBuild#save/load` |
| Per player | NeoForge data attachment | add to `CoreRegistries.ATTACHMENT_TYPES` |
| Per world (global) | `SavedData` in overworld storage | `PCWorldData.get(server, moduleId, name, factory)` → file `pcsimulator_<module>_<name>.dat` |
| Balances | `EconomySavedData` (`pcsimulator_core_economy`) | `IEconomyService` |
| World meta | `WorldMetaSavedData` (schema version, created-as-PC-world) | internal |

Always `setDirty()` after mutation; SavedData is server-thread only. Add a `version` int in every tag you write.

## 7. Configuration

`PCConfig.COMMON/SERVER/CLIENT` for core settings. Modules register **their own** spec via `PCConfig.registerModuleConfig(container, moduleId, type, spec)` → `config/pcsimulator/<module>-<type>.toml`. SERVER values may only be read once a world is loading (never in constructors / static init).

## 8. Networking

* One protocol version (`PCNetwork.PROTOCOL_VERSION`). Bump on any payload change.
* Register with `PCModule#registerPackets(PacketRegistrar)`: `toClient`, `toServer`, `bidirectional`.
* Handlers run on the main thread (NeoForge default). Validate all serverbound data.
* Send with `PCNetwork.sendToPlayer / sendToServer`.
* Core packet: `SyncBalancePayload` (S2C) → `ClientBalanceCache`.

## 9. PC Simulator world type

Data-driven, no code needed to appear in *Create New World → World Type*:
* `data/pcsimulator/worldgen/world_preset/pc_simulator.json` (vanilla-like terrain; Claude 6 may swap in a custom chunk generator)
* `data/pcsimulator/dimension_type/pc_overworld.json` (copy of vanilla overworld; acts as the **marker**)
* `data/minecraft/tags/worldgen/world_preset/normal.json` (adds it to the selectable list)
* lang key `generator.pcsimulator.pc_simulator`

Detection at runtime: `PCSimulatorAPI.isPCWorld(server | level)` (checks the dimension type). Content that should only exist in PC worlds gates on this. Limitation: players converting an existing world will not get the marker.

## 10. Shared API summary

* `PCSimulatorAPI` – `id()`, `economy()`, `isPCWorld()`
* `PCRegistries` – custom registries
* `hardware`: `IHardwareComponent`, `IHardwareItem`, `ComponentType`, `ComponentTier`
* `build`: `IPCBuild`, `IPCHost`, `ComponentSlot`, `InstallResult`, `BootResult`, `PCState`, `PCCapabilities.PC_BUILD`
* `interaction`: `IPCInteraction`, `InteractionContext`, `PCInteractions.perform`
* `economy`: `IEconomyService`, `TransactionResult`; `event.BalanceChangedEvent`

Units: money = **cents** (long), power = watts. Behavioural contracts are in each interface's Javadoc.

## 11. Module checklist (Claude 2–6)

1. Create `com.pcsimulator.<id>.<Name>Module implements PCModule`.
2. Put all registrations in static holders using `CoreRegistries.*`; load them in `register()`.
3. Packets via `registerPackets`; capabilities via `registerCapabilities`; client stuff via `registerClient`.
4. Ask for API changes instead of editing `api`/`core` (Claude 1 owns them).
5. Hand Claude 7 the single line to add in `core/module/ModuleList.java`.
6. Resources/lang: use own file names (`assets/pcsimulator/lang` keys prefixed by module are merged by Claude 7 — keep keys unique).
