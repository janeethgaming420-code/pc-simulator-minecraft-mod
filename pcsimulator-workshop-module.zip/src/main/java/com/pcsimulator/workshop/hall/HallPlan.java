package com.pcsimulator.workshop.hall;

import java.util.Map;
import java.util.TreeMap;

/**
 * Pure-Java layout of the PC Simulator workshop hall (no Minecraft dependency).
 *
 * <h3>Hall-local coordinates</h3>
 * {@code x} runs east 0..{@value #W}-1, {@code z} runs south 0..{@value #D}-1, {@code y} 0 is the first air layer
 * above the floor. The floor blocks are at {@code y = -1}, the ceiling at {@code y = }{@value #H}. Walls sit at
 * {@code x = -1 / W} and {@code z = -1 / D}. The interior is therefore 48 x 32 blocks with a 12 block high ceiling.
 *
 * <h3>Layout</h3>
 * <ul>
 *   <li>North/west/east/south walls: large windows (8-12 wide, 6 high) between wall piers; neutral grey walls.</li>
 *   <li>Entrance: 8 wide x 6 high opening in the south wall, with a short outside apron.</li>
 *   <li>Concrete floor with yellow floor-marking outlines for 8 open "build on the floor" bays.</li>
 *   <li>4 large PC-building tables (7x3) in the west half, 2 diagnostic tables (5x2) beside them.</li>
 *   <li>Shelves, cabinets, parts drawers and pegboards along the walls, below window height.</li>
 *   <li>Lighting: 5 rows of hanging LED strips, ceiling light panels, skylight strips, wall lights.</li>
 *   <li>8 wall-mounted air-conditioning units above the windows.</li>
 * </ul>
 */
public final class HallPlan {
    public static final int W = 48;
    public static final int D = 32;
    public static final int H = 12;

    /** Spawn position (hall-local) just inside the entrance. */
    public static final int SPAWN_X = 24;
    public static final int SPAWN_Z = 27;

    public record Cell(HallBlock block, HallFace face) {}

    private final Map<Long, Cell> cells = new TreeMap<>();

    private HallPlan() {}

    public static HallPlan build() {
        HallPlan p = new HallPlan();
        p.shell();
        p.windowsAndEntrance();
        p.ceilingAndLighting();
        p.floorMarkings();
        p.furniture();
        p.wallEquipment();
        return p;
    }

    // ---------------------------------------------------------------- access

    private static long key(int x, int y, int z) {
        // offset so negative coordinates sort sanely; hall extents are tiny
        return (((long) (y + 64)) << 40) | (((long) (z + 64)) << 20) | (long) (x + 64);
    }

    public Cell get(int x, int y, int z) {
        return cells.get(key(x, y, z));
    }

    public HallBlock blockAt(int x, int y, int z) {
        Cell c = get(x, y, z);
        return c == null ? HallBlock.AIR : c.block();
    }

    public int size() {
        return cells.size();
    }

    public void forEach(HallSink sink) {
        // TreeMap order = y, then z, then x: layers are emitted bottom-up
        for (Map.Entry<Long, Cell> e : cells.entrySet()) {
            long k = e.getKey();
            int x = (int) (k & 0xFFFFF) - 64;
            int z = (int) ((k >> 20) & 0xFFFFF) - 64;
            int y = (int) (k >> 40) - 64;
            sink.set(x, y, z, e.getValue().block(), e.getValue().face());
        }
    }

    /** Number of cells holding {@code block}. */
    public int count(HallBlock block) {
        int n = 0;
        for (Cell c : cells.values()) if (c.block() == block) n++;
        return n;
    }

    // ---------------------------------------------------------------- building helpers

    private void put(int x, int y, int z, HallBlock b, HallFace f) {
        cells.put(key(x, y, z), new Cell(b, f));
    }

    private void put(int x, int y, int z, HallBlock b) {
        put(x, y, z, b, HallFace.NORTH);
    }

    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, HallBlock b, HallFace f) {
        for (int y = y1; y <= y2; y++)
            for (int z = z1; z <= z2; z++)
                for (int x = x1; x <= x2; x++) put(x, y, z, b, f);
    }

    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, HallBlock b) {
        fill(x1, y1, z1, x2, y2, z2, b, HallFace.NORTH);
    }

    // ---------------------------------------------------------------- sections

    private void shell() {
        fill(-1, -3, -1, W, -2, D, HallBlock.FOUNDATION);
        fill(-1, -1, -1, W, -1, D, HallBlock.FLOOR);
        fill(-1, 0, -1, W, H - 1, -1, HallBlock.WALL);   // north
        fill(-1, 0, D, W, H - 1, D, HallBlock.WALL);     // south
        fill(-1, 0, -1, -1, H - 1, D, HallBlock.WALL);   // west
        fill(W, 0, -1, W, H - 1, D, HallBlock.WALL);     // east
        fill(-1, H, -1, W, H, D, HallBlock.CEILING_PANEL);
        fill(0, 0, 0, W - 1, H - 1, D - 1, HallBlock.AIR); // explicit interior (clears terrain/vegetation)
    }

    private void windowsAndEntrance() {
        int[][] northX = {{2, 9}, {14, 21}, {26, 33}, {38, 45}};
        for (int[] r : northX) fill(r[0], 4, -1, r[1], 9, -1, HallBlock.GLASS);
        int[][] southX = {{2, 13}, {34, 45}};
        for (int[] r : southX) fill(r[0], 4, D, r[1], 9, D, HallBlock.GLASS);
        int[][] sideZ = {{2, 9}, {12, 19}, {22, 29}};
        for (int[] r : sideZ) {
            fill(-1, 4, r[0], -1, 9, r[1], HallBlock.GLASS);
            fill(W, 4, r[0], W, 9, r[1], HallBlock.GLASS);
        }
        // entrance: 8 wide x 6 high opening with column jambs and a lintel, plus an outside apron
        fill(20, 0, D, 27, 5, D, HallBlock.AIR);
        fill(19, 0, D, 19, 6, D, HallBlock.COLUMN);
        fill(28, 0, D, 28, 6, D, HallBlock.COLUMN);
        fill(20, 6, D, 27, 6, D, HallBlock.WALL);
        fill(16, -1, D + 1, 31, -1, D + 5, HallBlock.FLOOR);
        fill(16, -3, D + 1, 31, -2, D + 5, HallBlock.FOUNDATION);
    }

    private void ceilingAndLighting() {
        // structural beams under the ceiling
        for (int bx : new int[]{12, 24, 36}) fill(bx, H - 1, 0, bx, H - 1, D - 1, HallBlock.BEAM_Z);
        // skylight strips
        for (int sx : new int[]{6, 18, 30, 42}) fill(sx, H, 2, sx + 2, H, D - 3, HallBlock.SKYLIGHT);
        // flush ceiling light panels
        for (int x = 3; x < W; x += 6)
            for (int z = 3; z < D; z += 6)
                if (blockAt(x, H, z) == HallBlock.CEILING_PANEL) put(x, H, z, HallBlock.CEILING_LIGHT);
        // hanging LED strips (5 rows) on chains
        for (int z : new int[]{4, 10, 16, 22, 28}) {
            fill(2, 6, z, 45, 6, z, HallBlock.LED_STRIP);
            for (int cx : new int[]{3, 15, 27, 39})
                for (int y = 7; y <= H - 1; y++) put(cx, y, z, HallBlock.CHAIN);
        }
    }

    private void floorMarkings() {
        int[][] bays = {
                {34, 3, 39, 8}, {41, 3, 46, 8},
                {34, 12, 39, 17}, {41, 12, 46, 17},
                {34, 21, 39, 26}, {41, 21, 46, 26},
                {3, 22, 8, 27}, {11, 22, 16, 27}};
        for (int[] b : bays) {
            for (int x = b[0]; x <= b[2]; x++) {
                put(x, -1, b[1], HallBlock.FLOOR_MARKING);
                put(x, -1, b[3], HallBlock.FLOOR_MARKING);
            }
            for (int z = b[1]; z <= b[3]; z++) {
                put(b[0], -1, z, HallBlock.FLOOR_MARKING);
                put(b[2], -1, z, HallBlock.FLOOR_MARKING);
            }
        }
    }

    private void furniture() {
        // 4 large PC-building tables, 7 x 3
        int[][] tables = {{4, 6}, {15, 6}, {4, 14}, {15, 14}};
        for (int[] t : tables) {
            fill(t[0], 0, t[1], t[0] + 6, 0, t[1] + 2, HallBlock.BUILDING_TABLE);
            int stoolZ = t[1] + 3;
            for (int sx : new int[]{t[0] + 1, t[0] + 3, t[0] + 5}) {
                put(sx, 0, stoolZ, HallBlock.STOOL);
                put(sx, 0, stoolZ + 1, HallBlock.ANTISTATIC_MAT);
            }
        }
        // 2 diagnostic tables, 5 x 2, operator stands on the south side (equipment at the back/north)
        for (int z : new int[]{6, 14}) {
            fill(27, 0, z, 31, 0, z + 1, HallBlock.DIAGNOSTIC_TABLE, HallFace.SOUTH);
            put(29, 0, z + 2, HallBlock.STOOL);
            put(29, 0, z + 3, HallBlock.ANTISTATIC_MAT);
        }
        // loose items on the floor next to the tables
        put(23, 0, 7, HallBlock.TOOLBOX, HallFace.WEST);
        put(23, 0, 15, HallBlock.TOOLBOX, HallFace.WEST);
        put(1, 0, 30, HallBlock.TRASH_BIN);
        put(46, 0, 30, HallBlock.TRASH_BIN);
        put(1, 0, 1, HallBlock.TRASH_BIN);
    }

    private void wallEquipment() {
        // shelves under the north windows, pegboards on the piers between
        int[][] northBays = {{2, 9}, {14, 21}, {26, 33}, {38, 45}};
        for (int[] r : northBays) fill(r[0], 0, 0, r[1], 2, 0, HallBlock.SHELF, HallFace.SOUTH);
        for (int[] pier : new int[][]{{10, 13}, {22, 25}, {34, 37}})
            fill(pier[0], 1, 0, pier[1], 2, 0, HallBlock.PEGBOARD, HallFace.SOUTH);
        put(11, 6, 0, HallBlock.WALL_LIGHT, HallFace.SOUTH);
        put(23, 6, 0, HallBlock.WALL_LIGHT, HallFace.SOUTH);
        put(35, 6, 0, HallBlock.WALL_LIGHT, HallFace.SOUTH);

        // west wall: shelves, east wall: cabinets and parts drawers
        int[][] sideBays = {{2, 9}, {12, 19}, {22, 29}};
        for (int[] r : sideBays) fill(0, 0, r[0], 0, 2, r[1], HallBlock.SHELF, HallFace.EAST);
        fill(W - 1, 0, 2, W - 1, 1, 9, HallBlock.CABINET, HallFace.WEST);
        fill(W - 1, 0, 12, W - 1, 1, 19, HallBlock.PARTS_DRAWER, HallFace.WEST);
        fill(W - 1, 0, 22, W - 1, 1, 29, HallBlock.CABINET, HallFace.WEST);
        for (int z : new int[]{10, 20}) {
            put(0, 6, z, HallBlock.WALL_LIGHT, HallFace.EAST);
            put(W - 1, 6, z, HallBlock.WALL_LIGHT, HallFace.WEST);
        }
        fill(W - 1, 2, 10, W - 1, 3, 11, HallBlock.WHITEBOARD, HallFace.WEST);

        // south wall, either side of the entrance
        fill(2, 0, D - 1, 7, 1, D - 1, HallBlock.CABINET, HallFace.NORTH);
        fill(8, 0, D - 1, 13, 0, D - 1, HallBlock.CRATES, HallFace.NORTH);
        fill(34, 0, D - 1, 39, 1, D - 1, HallBlock.PARTS_DRAWER, HallFace.NORTH);
        fill(40, 0, D - 1, 45, 2, D - 1, HallBlock.SHELF, HallFace.NORTH);
        put(18, 1, D - 1, HallBlock.EXTINGUISHER, HallFace.NORTH);
        put(29, 1, D - 1, HallBlock.EXTINGUISHER, HallFace.NORTH);
        put(18, 6, D - 1, HallBlock.WALL_LIGHT, HallFace.NORTH);
        put(29, 6, D - 1, HallBlock.WALL_LIGHT, HallFace.NORTH);

        // 8 wall-mounted air conditioners above the windows (2 wide each)
        for (int ax : new int[]{4, 16, 28, 40}) {
            fill(ax, 10, 0, ax + 1, 10, 0, HallBlock.AC_UNIT, HallFace.SOUTH);
        }
        for (int az : new int[]{5, 25}) {
            fill(0, 10, az, 0, 10, az + 1, HallBlock.AC_UNIT, HallFace.EAST);
            fill(W - 1, 10, az, W - 1, 10, az + 1, HallBlock.AC_UNIT, HallFace.WEST);
        }
    }
}
