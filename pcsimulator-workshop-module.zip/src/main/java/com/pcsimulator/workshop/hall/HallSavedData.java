package com.pcsimulator.workshop.hall;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

/** Remembers whether (and where) the hall was built. File: pcsimulator_workshop_hall.dat. */
public final class HallSavedData extends SavedData {
    private static final int VERSION = 1;

    private boolean built;
    private BlockPos origin = BlockPos.ZERO;

    public static SavedData.Factory<HallSavedData> factory() {
        return new SavedData.Factory<>(HallSavedData::new, HallSavedData::load);
    }

    private static HallSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        HallSavedData d = new HallSavedData();
        d.built = tag.getBoolean("built");
        d.origin = new BlockPos(tag.getInt("x"), tag.getInt("y"), tag.getInt("z"));
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putInt("version", VERSION);
        tag.putBoolean("built", built);
        tag.putInt("x", origin.getX());
        tag.putInt("y", origin.getY());
        tag.putInt("z", origin.getZ());
        return tag;
    }

    public boolean built() {
        return built;
    }

    /** World position of hall-local (0,0,0), or null if not built. */
    @Nullable
    public BlockPos origin() {
        return built ? origin : null;
    }

    public void markBuilt(BlockPos origin) {
        this.built = true;
        this.origin = origin.immutable();
        setDirty();
    }
}
