package com.pcsimulator.workshop.hall;

import com.pcsimulator.workshop.furniture.ConnectingTableBlock;
import com.pcsimulator.workshop.furniture.DiagnosticTableBlock;
import com.pcsimulator.workshop.furniture.WorkshopBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Builds a {@link HallPlan} into a world: flattens/excavates the terrain around it, fills the ground below with a
 * foundation, then places every plan cell. Server thread only. Blocks are set without neighbour updates (the
 * connecting tables get their states from the plan), which keeps a one-off 70k-block placement cheap.
 */
public final class HallPlacer {
    private HallPlacer() {}

    /** Extra flattened ring around the hall. */
    public static final int MARGIN = 5;
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;
    private static final int MAX_FILL_DEPTH = 24;

    /** World position of hall-local (0,0,0) for a hall centred on {@code center}, following the terrain height. */
    public static BlockPos pickOrigin(ServerLevel level, BlockPos center) {
        int x0 = center.getX() - HallPlan.W / 2;
        int z0 = center.getZ() - HallPlan.D / 2;
        long sum = 0;
        int n = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int sx = x0 + (HallPlan.W - 1) * i / 2;
                int sz = z0 + (HallPlan.D - 1) * j / 2;
                sum += level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, sx, sz);
                n++;
            }
        }
        int y = Math.max((int) Math.round(sum / (double) n), level.getSeaLevel() + 1);
        int maxY = level.getMaxBuildHeight() - HallPlan.H - 12;
        int minY = level.getMinBuildHeight() + MAX_FILL_DEPTH;
        return new BlockPos(x0, Math.max(minY, Math.min(y, maxY)), z0);
    }

    public static BlockPos spawnPos(BlockPos origin) {
        return origin.offset(HallPlan.SPAWN_X, 0, HallPlan.SPAWN_Z);
    }

    public static boolean isInsideFootprint(BlockPos origin, double x, double z) {
        return x >= origin.getX() - 1 && x <= origin.getX() + HallPlan.W + 1
                && z >= origin.getZ() - 1 && z <= origin.getZ() + HallPlan.D + 1;
    }

    private static boolean inHall(int x, int z) {
        boolean shell = x >= -1 && x <= HallPlan.W && z >= -1 && z <= HallPlan.D;
        boolean apron = x >= 16 && x <= 31 && z > HallPlan.D && z <= HallPlan.D + 5;
        return shell || apron;
    }

    public static void place(ServerLevel level, BlockPos origin) {
        HallPlan plan = HallPlan.build();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int topY = HallPlan.H + 10;
        int minX = -1 - MARGIN, maxX = HallPlan.W + MARGIN;
        int minZ = -1 - MARGIN, maxZ = HallPlan.D + MARGIN + 5;

        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                boolean hall = inHall(x, z);
                int clearFrom = hall ? HallPlan.H + 1 : 0;
                for (int y = clearFrom; y <= topY; y++) set(level, pos, origin, x, y, z, Blocks.AIR.defaultBlockState());
                int fillFrom;
                if (hall) {
                    fillFrom = -4;
                } else {
                    set(level, pos, origin, x, -1, z, Blocks.GRASS_BLOCK.defaultBlockState());
                    for (int y = -2; y >= -4; y--) set(level, pos, origin, x, y, z, Blocks.DIRT.defaultBlockState());
                    fillFrom = -5;
                }
                BlockState filler = hall ? Blocks.STONE.defaultBlockState() : Blocks.DIRT.defaultBlockState();
                for (int y = fillFrom; y >= fillFrom - MAX_FILL_DEPTH; y--) {
                    pos.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                    if (level.isOutsideBuildHeight(pos)) break;
                    BlockState existing = level.getBlockState(pos);
                    if (!existing.canBeReplaced() && existing.getFluidState().isEmpty() && !existing.isAir()) break;
                    level.setBlock(pos, filler, FLAGS);
                }
            }
        }

        plan.forEach((x, y, z, block, face) -> set(level, pos, origin, x, y, z, toState(plan, x, y, z, block, face)));
    }

    private static void set(ServerLevel level, BlockPos.MutableBlockPos pos, BlockPos origin, int x, int y, int z, BlockState state) {
        pos.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
        if (level.isOutsideBuildHeight(pos)) return;
        if (level.getBlockState(pos) != state) level.setBlock(pos, state, FLAGS);
    }

    private static Direction dir(HallFace f) {
        return switch (f) {
            case NORTH -> Direction.NORTH;
            case EAST -> Direction.EAST;
            case SOUTH -> Direction.SOUTH;
            case WEST -> Direction.WEST;
        };
    }

    private static BlockState facing(Block block, HallFace f) {
        return block.defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, dir(f));
    }

    private static BlockState table(HallPlan plan, int x, int y, int z, HallBlock type, Block block, HallFace f) {
        BlockState s = block.defaultBlockState();
        for (HallFace n : HallFace.values()) {
            boolean connected = plan.blockAt(x + n.dx, y, z + n.dz) == type;
            s = s.setValue(ConnectingTableBlock.property(dir(n)), connected);
        }
        if (type == HallBlock.DIAGNOSTIC_TABLE) s = s.setValue(DiagnosticTableBlock.FACING, dir(f));
        return s;
    }

    private static BlockState toState(HallPlan plan, int x, int y, int z, HallBlock b, HallFace f) {
        return switch (b) {
            case AIR -> Blocks.AIR.defaultBlockState();
            case FOUNDATION -> Blocks.STONE.defaultBlockState();
            case FLOOR -> WorkshopBlocks.CONCRETE_FLOOR.get().defaultBlockState();
            case FLOOR_MARKING -> WorkshopBlocks.FLOOR_MARKING.get().defaultBlockState();
            case WALL -> WorkshopBlocks.WORKSHOP_WALL.get().defaultBlockState();
            case CEILING_PANEL -> WorkshopBlocks.CEILING_PANEL.get().defaultBlockState();
            case CEILING_LIGHT -> WorkshopBlocks.CEILING_LIGHT.get().defaultBlockState();
            case SKYLIGHT, GLASS -> Blocks.GLASS.defaultBlockState();
            case COLUMN -> WorkshopBlocks.STEEL_COLUMN.get().defaultBlockState();
            case BEAM_Z -> WorkshopBlocks.STEEL_BEAM.get().defaultBlockState();
            case CHAIN -> Blocks.CHAIN.defaultBlockState();
            case LED_STRIP -> facing(WorkshopBlocks.LED_STRIP_LIGHT.get(), f);
            case WALL_LIGHT -> facing(WorkshopBlocks.WALL_LIGHT.get(), f);
            case AC_UNIT -> facing(WorkshopBlocks.WALL_AIR_CONDITIONER.get(), f);
            case BUILDING_TABLE -> table(plan, x, y, z, b, WorkshopBlocks.BUILDING_TABLE.get(), f);
            case DIAGNOSTIC_TABLE -> table(plan, x, y, z, b, WorkshopBlocks.DIAGNOSTIC_TABLE.get(), f);
            case SHELF -> facing(WorkshopBlocks.METAL_SHELF.get(), f);
            case CABINET -> facing(WorkshopBlocks.STORAGE_CABINET.get(), f);
            case PARTS_DRAWER -> facing(WorkshopBlocks.PARTS_DRAWER_UNIT.get(), f);
            case PEGBOARD -> facing(WorkshopBlocks.PEGBOARD.get(), f);
            case CRATES -> facing(WorkshopBlocks.PARTS_CRATES.get(), f);
            case STOOL -> facing(WorkshopBlocks.WORKSHOP_STOOL.get(), f);
            case TRASH_BIN -> facing(WorkshopBlocks.TRASH_BIN.get(), f);
            case EXTINGUISHER -> facing(WorkshopBlocks.FIRE_EXTINGUISHER.get(), f);
            case WHITEBOARD -> facing(WorkshopBlocks.WHITEBOARD.get(), f);
            case TOOLBOX -> facing(WorkshopBlocks.TOOLBOX.get(), f);
            case ANTISTATIC_MAT -> facing(WorkshopBlocks.ANTISTATIC_MAT.get(), f);
        };
    }
}
