package com.pcsimulator.workshop.hall;

/** Receives the cells of a {@link HallPlan}. Coordinates are hall-local (see {@link HallPlan}). */
@FunctionalInterface
public interface HallSink {
    void set(int x, int y, int z, HallBlock block, HallFace face);
}
