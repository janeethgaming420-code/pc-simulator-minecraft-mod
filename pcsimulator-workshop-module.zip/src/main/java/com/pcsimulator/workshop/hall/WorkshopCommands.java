package com.pcsimulator.workshop.hall;

import com.mojang.brigadier.context.CommandContext;
import com.pcsimulator.core.data.PCWorldData;
import com.pcsimulator.workshop.WorkshopModule;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Adds {@code /pcsim workshop build|info|tp} (op level 2). Registered into the core's {@code /pcsim} root: Brigadier
 * merges same-named literals, so the core command class is not touched.
 */
public final class WorkshopCommands {
    private WorkshopCommands() {}

    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("pcsim")
                .then(Commands.literal("workshop").requires(s -> s.hasPermission(2))
                        .then(Commands.literal("build").executes(WorkshopCommands::build))
                        .then(Commands.literal("info").executes(WorkshopCommands::info))
                        .then(Commands.literal("tp").executes(WorkshopCommands::tp))));
    }

    private static HallSavedData data(CommandSourceStack src) {
        return PCWorldData.get(src.getServer(), WorkshopModule.ID, "hall", HallSavedData.factory());
    }

    private static int build(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        ServerLevel level = src.getLevel();
        BlockPos origin = HallPlacer.pickOrigin(level, BlockPos.containing(src.getPosition()));
        HallPlacer.place(level, origin);
        data(src).markBuilt(origin);
        src.sendSuccess(() -> Component.translatable("commands.pcsimulator.workshop.built",
                origin.getX(), origin.getY(), origin.getZ()), true);
        return 1;
    }

    private static int info(CommandContext<CommandSourceStack> ctx) {
        BlockPos o = data(ctx.getSource()).origin();
        ctx.getSource().sendSuccess(() -> o == null
                ? Component.translatable("commands.pcsimulator.workshop.not_built")
                : Component.translatable("commands.pcsimulator.workshop.info", o.getX(), o.getY(), o.getZ(),
                HallPlan.W, HallPlan.D, HallPlan.H), false);
        return o == null ? 0 : 1;
    }

    private static int tp(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        BlockPos o = data(src).origin();
        if (o == null) {
            src.sendFailure(Component.translatable("commands.pcsimulator.workshop.not_built"));
            return 0;
        }
        ServerPlayer player = src.getPlayer();
        if (player == null) return 0;
        BlockPos s = HallPlacer.spawnPos(o);
        player.teleportTo(src.getServer().overworld(), s.getX() + 0.5, s.getY(), s.getZ() + 0.5, 180.0F, 0.0F);
        return 1;
    }
}
