package com.pcsimulator.workshop.hall;

/** Horizontal facing in hall space (north = -z, east = +x, south = +z, west = -x). */
public enum HallFace {
    NORTH(0, -1), EAST(1, 0), SOUTH(0, 1), WEST(-1, 0);

    public final int dx;
    public final int dz;

    HallFace(int dx, int dz) {
        this.dx = dx;
        this.dz = dz;
    }
}
