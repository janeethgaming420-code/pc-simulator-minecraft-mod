package com.pcsimulator.workshop.hall;

/**
 * Logical blocks used by {@link HallPlan}. The plan is deliberately free of Minecraft classes so the layout can
 * be tested and rendered outside the game. {@code HallPlacer} maps each value to a real block.
 */
public enum HallBlock {
    AIR, FOUNDATION, FLOOR, FLOOR_MARKING, WALL, CEILING_PANEL, CEILING_LIGHT, SKYLIGHT, GLASS, COLUMN, BEAM_Z,
    LED_STRIP, CHAIN, WALL_LIGHT, AC_UNIT,
    BUILDING_TABLE, DIAGNOSTIC_TABLE,
    SHELF, CABINET, PARTS_DRAWER, PEGBOARD, CRATES,
    STOOL, TRASH_BIN, EXTINGUISHER, WHITEBOARD, TOOLBOX, ANTISTATIC_MAT;

    /** Blocks that stop light propagation in the plan's light estimate. */
    public boolean opaque() {
        return switch (this) {
            case FOUNDATION, FLOOR, FLOOR_MARKING, WALL, CEILING_PANEL, CEILING_LIGHT, COLUMN, BEAM_Z -> true;
            default -> false;
        };
    }

    /** Light emitted by the block (matches the registered blocks' luminance). */
    public int emission() {
        return switch (this) {
            case CEILING_LIGHT, LED_STRIP -> 15;
            case WALL_LIGHT -> 13;
            default -> 0;
        };
    }
}
