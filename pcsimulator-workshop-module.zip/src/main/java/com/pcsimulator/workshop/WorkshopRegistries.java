package com.pcsimulator.workshop;

import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.core.registry.CoreCreativeTab;
import com.pcsimulator.core.registry.CoreRegistries;
import com.pcsimulator.workshop.cases.CaseShape;
import com.pcsimulator.workshop.cases.PCCaseBlock;
import com.pcsimulator.workshop.catalogue.WorkshopCatalogue;
import com.pcsimulator.workshop.furniture.WorkshopBlocks;
import com.pcsimulator.workshop.item.CaseBlockItem;
import com.pcsimulator.workshop.item.CoolerItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Registers cases (IHardwareComponent + placeable block + hardware item), coolers (IHardwareComponent + hardware
 * item) and the workshop blocks, using ONLY the core's shared DeferredRegisters. Creative tab order: cases,
 * coolers, then workshop blocks.
 */
public final class WorkshopRegistries {
    private WorkshopRegistries() {}

    private static final Map<String, DeferredBlock<PCCaseBlock>> CASE_BLOCKS = new LinkedHashMap<>();
    private static final Map<String, DeferredItem<CaseBlockItem>> CASE_ITEMS = new LinkedHashMap<>();
    private static final Map<String, DeferredItem<CoolerItem>> COOLER_ITEMS = new LinkedHashMap<>();
    private static boolean initialised;

    /** Idempotent. Must run from {@code PCModule#register} (before RegisterEvent). */
    public static synchronized void init() {
        if (initialised) return;
        initialised = true;
        WorkshopCatalogue.Loaded catalogue = WorkshopCatalogue.load();

        for (WorkshopCatalogue.CaseEntry e : catalogue.cases()) {
            ResourceLocation id = PCSimulatorAPI.id(e.name());
            CaseShape shape = CaseShape.byName(e.shape());
            CoreRegistries.HARDWARE_COMPONENTS.register(e.name(), e::definition);
            DeferredBlock<PCCaseBlock> block = CoreRegistries.BLOCKS.registerBlock(e.name(), p -> new PCCaseBlock(p, shape),
                    BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(1.5F, 6.0F)
                            .sound(SoundType.METAL).noOcclusion());
            DeferredItem<CaseBlockItem> item = CoreRegistries.ITEMS.registerItem(e.name(),
                    p -> new CaseBlockItem(block.get(), p, id), new Item.Properties().stacksTo(1));
            CASE_BLOCKS.put(e.name(), block);
            CASE_ITEMS.put(e.name(), item);
            CoreCreativeTab.add(item);
        }

        for (WorkshopCatalogue.CoolerEntry e : catalogue.coolers()) {
            ResourceLocation id = PCSimulatorAPI.id(e.name());
            CoreRegistries.HARDWARE_COMPONENTS.register(e.name(), e::definition);
            DeferredItem<CoolerItem> item = CoreRegistries.ITEMS.registerItem(e.name(),
                    p -> new CoolerItem(p, id), new Item.Properties().stacksTo(1));
            COOLER_ITEMS.put(e.name(), item);
            CoreCreativeTab.add(item);
        }

        WorkshopBlocks.init();
    }

    public static Map<String, DeferredBlock<PCCaseBlock>> caseBlocks() {
        return Collections.unmodifiableMap(CASE_BLOCKS);
    }

    public static Map<String, DeferredItem<CaseBlockItem>> caseItems() {
        return Collections.unmodifiableMap(CASE_ITEMS);
    }

    public static Map<String, DeferredItem<CoolerItem>> coolerItems() {
        return Collections.unmodifiableMap(COOLER_ITEMS);
    }
}
