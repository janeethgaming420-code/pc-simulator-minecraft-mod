package com.pcsimulator.workshop.cases;

import com.mojang.serialization.MapCodec;
import com.pcsimulator.workshop.furniture.ShapeUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Physical shell of a PC case. It only has a facing (front toward the placing player) and a shape. It is NOT a
 * block entity and holds no PC: pcbuild (Claude 4) attaches the build/installation behaviour to this block.
 */
public class PCCaseBlock extends HorizontalDirectionalBlock {
    /** Codec is only needed to satisfy Block#codec(); real instances are created in WorkshopRegistries. */
    public static final MapCodec<PCCaseBlock> CODEC = simpleCodec(p -> new PCCaseBlock(p, CaseShape.MID_TOWER));

    private final CaseShape caseShape;
    private final VoxelShape[] shapes;

    public PCCaseBlock(Properties properties, CaseShape shape) {
        super(properties);
        this.caseShape = shape;
        this.shapes = ShapeUtil.allFacings(shape.north());
        registerDefaultState(stateDefinition.any().setValue(FACING, net.minecraft.core.Direction.NORTH));
    }

    public CaseShape caseShape() {
        return caseShape;
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return shapes[state.getValue(FACING).get2DDataValue()];
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
}
