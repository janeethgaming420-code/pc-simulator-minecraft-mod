package com.pcsimulator.workshop.cases;

import com.pcsimulator.api.hardware.ComponentTier;
import com.pcsimulator.api.hardware.ComponentType;
import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.workshop.api.ICaseSpec;

import java.util.OptionalInt;
import java.util.Set;

/** Immutable PC case model. 0 price/power/score means "not set" (see {@link #unsetFields()}), not "free". */
public final class CaseDefinition implements IHardwareComponent, ICaseSpec {
    private final ComponentTier tier;
    private final long price;
    private final int draw;
    private final int score;
    private final String category;
    private final Set<String> formFactors;
    private final boolean openAir;
    private final OptionalInt maxCoolerHeight;
    private final Set<Integer> radiators;
    private final boolean provisional;
    private final Set<String> unset;

    public CaseDefinition(ComponentTier tier, long price, int draw, int score, String category, Set<String> formFactors,
                          boolean openAir, OptionalInt maxCoolerHeight, Set<Integer> radiators, boolean provisional,
                          Set<String> unset) {
        this.tier = tier;
        this.price = price;
        this.draw = draw;
        this.score = score;
        this.category = category;
        this.formFactors = Set.copyOf(formFactors);
        this.openAir = openAir;
        this.maxCoolerHeight = maxCoolerHeight;
        this.radiators = Set.copyOf(radiators);
        this.provisional = provisional;
        this.unset = Set.copyOf(unset);
    }

    @Override public ComponentType type() { return ComponentType.CASE; }
    @Override public ComponentTier tier() { return tier; }
    @Override public long basePriceCents() { return price; }
    @Override public int powerDrawWatts() { return draw; }
    @Override public int performanceScore() { return score; }

    @Override public String category() { return category; }
    @Override public Set<String> boardFormFactors() { return formFactors; }
    @Override public boolean openAir() { return openAir; }
    @Override public OptionalInt maxCoolerHeightMm() { return maxCoolerHeight; }
    @Override public Set<Integer> radiatorMountsMm() { return radiators; }

    public boolean provisional() { return provisional; }
    public Set<String> unsetFields() { return unset; }
}
