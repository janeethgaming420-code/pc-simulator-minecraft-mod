package com.pcsimulator.workshop.cases;

import com.pcsimulator.workshop.furniture.ShapeUtil;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.Locale;

/**
 * Collision/selection shape of a placed case block, authored facing NORTH (front at -z). Values are VISUAL block
 * dimensions in 1/16 block, NOT hardware specifications. Must match tools/gen_assets.py (CASE_SHAPES).
 */
public enum CaseShape {
    MID_TOWER(4, 0, 1, 12, 14, 15),
    GAMING_TOWER(3, 0, 1, 13, 15, 15),
    FULL_TOWER(3, 0, 0, 13, 16, 16),
    MICRO_ATX(4, 0, 2, 12, 11, 14),
    MINI_ITX(4, 0, 3, 12, 8, 13),
    SHOWCASE(3, 0, 2, 13, 14, 14),
    OPEN_BENCH(1, 0, 1, 15, 8, 15),
    MINING_CASE(1, 0, 2, 15, 8, 14),
    MINING_RACK(1, 0, 1, 15, 16, 15);

    private final VoxelShape north;

    CaseShape(int x1, int y1, int z1, int x2, int y2, int z2) {
        this.north = ShapeUtil.box(x1, y1, z1, x2, y2, z2);
    }

    public VoxelShape north() {
        return north;
    }

    public static CaseShape byName(String name) {
        return valueOf(name.toUpperCase(Locale.ROOT));
    }
}
