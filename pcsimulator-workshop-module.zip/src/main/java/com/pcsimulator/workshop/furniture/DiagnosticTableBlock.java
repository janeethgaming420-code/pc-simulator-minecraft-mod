package com.pcsimulator.workshop.furniture;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;

/**
 * Diagnostic bench: same connecting table, plus a facing. The operator stands on the FACING side; the test
 * equipment is drawn at the back. Only the physical furniture lives here (diagnostic logic belongs to pcbuild/ui).
 */
public class DiagnosticTableBlock extends ConnectingTableBlock {
    public static final MapCodec<DiagnosticTableBlock> CODEC = simpleCodec(DiagnosticTableBlock::new);
    public static final net.minecraft.world.level.block.state.properties.DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

    public DiagnosticTableBlock(Properties properties) {
        super(properties);
        registerDefaultState(defaultBlockState().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState base = super.getStateForPlacement(context);
        return base == null ? null : base.setValue(FACING, context.getHorizontalDirection().getOpposite());
    }
}
