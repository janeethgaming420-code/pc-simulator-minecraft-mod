package com.pcsimulator.workshop.furniture;

import com.pcsimulator.core.registry.CoreCreativeTab;
import com.pcsimulator.core.registry.CoreRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Workshop hall + furniture blocks (all registered through the core's shared BLOCKS/ITEMS registers).
 * Names must match tools/gen_assets.py (BLOCKS); tools/validate.py checks this.
 */
public final class WorkshopBlocks {
    private WorkshopBlocks() {}

    private static final Map<String, DeferredBlock<? extends Block>> ALL = new LinkedHashMap<>();

    private static BlockBehaviour.Properties metal() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(1.5F, 6.0F).sound(SoundType.METAL);
    }

    private static <B extends Block> DeferredBlock<B> reg(String name, Function<BlockBehaviour.Properties, B> factory,
                                                         BlockBehaviour.Properties props) {
        DeferredBlock<B> block = CoreRegistries.BLOCKS.registerBlock(name, factory, props);
        CoreCreativeTab.add(CoreRegistries.ITEMS.registerSimpleBlockItem(block));
        ALL.put(name, block);
        return block;
    }

    private static DeferredBlock<FacingDecorBlock> decor(String name, DecorShape shape, BlockBehaviour.Properties props) {
        return reg(name, p -> new FacingDecorBlock(p, shape), props.noOcclusion());
    }

    // ---- hall structure
    public static final DeferredBlock<Block> CONCRETE_FLOOR = reg("concrete_floor", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(2.0F, 8.0F).sound(SoundType.STONE));
    public static final DeferredBlock<Block> FLOOR_MARKING = reg("floor_marking", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_YELLOW).strength(2.0F, 8.0F).sound(SoundType.STONE));
    public static final DeferredBlock<Block> WORKSHOP_WALL = reg("workshop_wall", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_GRAY).strength(2.0F, 8.0F).sound(SoundType.STONE));
    public static final DeferredBlock<Block> CEILING_PANEL = reg("ceiling_panel", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(1.0F, 4.0F).sound(SoundType.STONE));
    public static final DeferredBlock<Block> CEILING_LIGHT = reg("ceiling_light", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(1.0F, 4.0F).sound(SoundType.GLASS).lightLevel(s -> 15));
    public static final DeferredBlock<Block> STEEL_COLUMN = reg("steel_column", Block::new, metal());
    public static final DeferredBlock<Block> STEEL_BEAM = reg("steel_beam", Block::new, metal());
    public static final DeferredBlock<FacingDecorBlock> LED_STRIP_LIGHT = decor("led_strip_light", DecorShape.LED_STRIP, metal().lightLevel(s -> 15));
    public static final DeferredBlock<FacingDecorBlock> WALL_LIGHT = decor("wall_light", DecorShape.WALL_LIGHT, metal().lightLevel(s -> 13));
    public static final DeferredBlock<FacingDecorBlock> WALL_AIR_CONDITIONER = decor("wall_air_conditioner", DecorShape.AIR_CONDITIONER, metal());

    // ---- tables
    public static final DeferredBlock<ConnectingTableBlock> BUILDING_TABLE = reg("building_table", ConnectingTableBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion());
    public static final DeferredBlock<DiagnosticTableBlock> DIAGNOSTIC_TABLE = reg("diagnostic_table", DiagnosticTableBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).strength(2.0F, 6.0F).sound(SoundType.METAL).noOcclusion());

    // ---- storage + decoration
    public static final DeferredBlock<FacingDecorBlock> METAL_SHELF = decor("metal_shelf", DecorShape.SHELF, metal());
    public static final DeferredBlock<FacingDecorBlock> STORAGE_CABINET = decor("storage_cabinet", DecorShape.CABINET, metal());
    public static final DeferredBlock<FacingDecorBlock> PARTS_DRAWER_UNIT = decor("parts_drawer_unit", DecorShape.PARTS_DRAWER, metal());
    public static final DeferredBlock<FacingDecorBlock> PEGBOARD = decor("pegboard", DecorShape.PEGBOARD, metal());
    public static final DeferredBlock<FacingDecorBlock> PARTS_CRATES = decor("parts_crates", DecorShape.CRATES, BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).strength(1.0F).sound(SoundType.WOOD));
    public static final DeferredBlock<FacingDecorBlock> WORKSHOP_STOOL = decor("workshop_stool", DecorShape.STOOL, metal());
    public static final DeferredBlock<FacingDecorBlock> TRASH_BIN = decor("trash_bin", DecorShape.TRASH_BIN, metal());
    public static final DeferredBlock<FacingDecorBlock> FIRE_EXTINGUISHER = decor("fire_extinguisher", DecorShape.EXTINGUISHER, metal());
    public static final DeferredBlock<FacingDecorBlock> WHITEBOARD = decor("whiteboard", DecorShape.WHITEBOARD, metal());
    public static final DeferredBlock<FacingDecorBlock> TOOLBOX = decor("toolbox", DecorShape.TOOLBOX, metal());
    public static final DeferredBlock<FacingDecorBlock> ANTISTATIC_MAT = decor("antistatic_mat", DecorShape.ANTISTATIC_MAT, BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(0.3F).sound(SoundType.WOOL));

    public static Map<String, DeferredBlock<? extends Block>> all() {
        return java.util.Collections.unmodifiableMap(ALL);
    }

    /** Forces class loading from {@code PCModule#register}. */
    public static void init() {}
}
