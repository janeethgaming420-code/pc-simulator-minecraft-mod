package com.pcsimulator.workshop.furniture;

import net.minecraft.core.Direction;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Shape helpers. Base shapes are authored for a block facing NORTH (front at -z, back at +z). */
public final class ShapeUtil {
    private ShapeUtil() {}

    public static VoxelShape box(double x1, double y1, double z1, double x2, double y2, double z2) {
        return Shapes.box(x1 / 16.0, y1 / 16.0, z1 / 16.0, x2 / 16.0, y2 / 16.0, z2 / 16.0);
    }

    /** Rotates a north-facing shape clockwise (seen from above) to {@code facing}; matches blockstate y rotation. */
    public static VoxelShape rotateFromNorth(VoxelShape shape, Direction facing) {
        int turns = switch (facing) {
            case EAST -> 1;
            case SOUTH -> 2;
            case WEST -> 3;
            default -> 0;
        };
        VoxelShape current = shape;
        for (int i = 0; i < turns; i++) {
            VoxelShape[] out = {Shapes.empty()};
            current.forAllBoxes((x1, y1, z1, x2, y2, z2) ->
                    out[0] = Shapes.or(out[0], Shapes.box(1 - z2, y1, x1, 1 - z1, y2, x2)));
            current = out[0];
        }
        return current;
    }

    /** Precomputed shapes indexed by {@code Direction.get2DDataValue()} (S=0, W=1, N=2, E=3). */
    public static VoxelShape[] allFacings(VoxelShape northShape) {
        VoxelShape[] arr = new VoxelShape[4];
        for (Direction d : Direction.Plane.HORIZONTAL) arr[d.get2DDataValue()] = rotateFromNorth(northShape, d);
        return arr;
    }
}
