package com.pcsimulator.workshop.furniture;

import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Shapes of facing decor blocks, authored facing NORTH (front at -z, back/wall side at +z), 1/16 block units.
 * Must match tools/gen_assets.py (DECOR). {@code wallMounted} blocks take the clicked wall face as facing.
 */
public enum DecorShape {
    SHELF(0, 0, 6, 16, 16, 16, false),
    CABINET(0, 0, 2, 16, 16, 16, false),
    PARTS_DRAWER(0, 0, 2, 16, 16, 16, false),
    PEGBOARD(0, 0, 14, 16, 16, 16, true),
    WHITEBOARD(0, 0, 14, 16, 16, 16, true),
    AIR_CONDITIONER(0, 6, 8, 16, 14, 16, true),
    LED_STRIP(0, 8, 4, 16, 12, 12, false),
    WALL_LIGHT(5, 5, 12, 11, 11, 16, true),
    CRATES(1, 0, 1, 15, 14, 15, false),
    STOOL(4, 0, 4, 12, 10, 12, false),
    TRASH_BIN(4, 0, 4, 12, 12, 12, false),
    EXTINGUISHER(5, 2, 10, 11, 14, 16, true),
    TOOLBOX(3, 0, 4, 13, 6, 12, false),
    ANTISTATIC_MAT(0, 0, 0, 16, 1, 16, false);

    private final VoxelShape north;
    private final boolean wallMounted;

    DecorShape(int x1, int y1, int z1, int x2, int y2, int z2, boolean wallMounted) {
        this.north = ShapeUtil.box(x1, y1, z1, x2, y2, z2);
        this.wallMounted = wallMounted;
    }

    public VoxelShape north() {
        return north;
    }

    public boolean wallMounted() {
        return wallMounted;
    }
}
