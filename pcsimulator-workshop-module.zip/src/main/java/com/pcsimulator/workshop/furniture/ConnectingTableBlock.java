package com.pcsimulator.workshop.furniture;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Workshop table: 3/16 thick top at exactly one block height (so a case placed on it sits flush) and corner legs.
 * Neighbouring tables of the same block connect (no legs / no gap between them), like fences.
 */
public class ConnectingTableBlock extends Block {
    public static final MapCodec<ConnectingTableBlock> CODEC = simpleCodec(ConnectingTableBlock::new);
    public static final BooleanProperty NORTH = BooleanProperty.create("north");
    public static final BooleanProperty EAST = BooleanProperty.create("east");
    public static final BooleanProperty SOUTH = BooleanProperty.create("south");
    public static final BooleanProperty WEST = BooleanProperty.create("west");

    private static final VoxelShape TOP = ShapeUtil.box(0, 13, 0, 16, 16, 16);
    private static final VoxelShape LEG_NW = ShapeUtil.box(0, 0, 0, 3, 13, 3);
    private static final VoxelShape LEG_NE = ShapeUtil.box(13, 0, 0, 16, 13, 3);
    private static final VoxelShape LEG_SW = ShapeUtil.box(0, 0, 13, 3, 13, 16);
    private static final VoxelShape LEG_SE = ShapeUtil.box(13, 0, 13, 16, 13, 16);
    private static final VoxelShape[] SHAPES = new VoxelShape[16];

    static {
        for (int i = 0; i < 16; i++) {
            boolean n = (i & 1) != 0, e = (i & 2) != 0, s = (i & 4) != 0, w = (i & 8) != 0;
            VoxelShape shape = TOP;
            if (!n && !w) shape = Shapes.or(shape, LEG_NW);
            if (!n && !e) shape = Shapes.or(shape, LEG_NE);
            if (!s && !w) shape = Shapes.or(shape, LEG_SW);
            if (!s && !e) shape = Shapes.or(shape, LEG_SE);
            SHAPES[i] = shape;
        }
    }

    public ConnectingTableBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(NORTH, false).setValue(EAST, false)
                .setValue(SOUTH, false).setValue(WEST, false));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NORTH, EAST, SOUTH, WEST);
    }

    public static BooleanProperty property(Direction d) {
        return switch (d) {
            case NORTH -> NORTH;
            case EAST -> EAST;
            case SOUTH -> SOUTH;
            default -> WEST;
        };
    }

    private boolean connects(BlockState neighbour) {
        return neighbour.is(this);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = defaultBlockState();
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockState n = context.getLevel().getBlockState(context.getClickedPos().relative(d));
            state = state.setValue(property(d), connects(n));
        }
        return state;
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (direction.getAxis().isHorizontal()) return state.setValue(property(direction), connects(neighborState));
        return state;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        int i = (state.getValue(NORTH) ? 1 : 0) | (state.getValue(EAST) ? 2 : 0)
                | (state.getValue(SOUTH) ? 4 : 0) | (state.getValue(WEST) ? 8 : 0);
        return SHAPES[i];
    }
}
