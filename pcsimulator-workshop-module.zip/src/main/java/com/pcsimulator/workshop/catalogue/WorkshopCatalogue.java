package com.pcsimulator.workshop.catalogue;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.pcsimulator.workshop.cases.CaseDefinition;
import com.pcsimulator.workshop.cooling.CoolerDefinition;
import com.pcsimulator.workshop.WorkshopModule;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Loads {@code /data/pcsimulator/workshop/catalogue.json}. Optional patch file
 * {@code <config>/pcsimulator/workshop-catalogue.json} (same schema) may only REPLACE entries that already exist in
 * the bundled file (a new id would have no block/item model). Missing numeric fields are not guessed: they load as
 * 0 / empty and are listed in {@code unsetFields()}.
 */
public final class WorkshopCatalogue {
    private WorkshopCatalogue() {}

    public static final String BUNDLED = "/data/pcsimulator/workshop/catalogue.json";
    private static final Pattern NAME = Pattern.compile("[a-z0-9_]+");

    public record CaseEntry(String name, CaseDefinition definition, String shape) {}
    public record CoolerEntry(String name, CoolerDefinition definition) {}
    public record Loaded(List<CaseEntry> cases, List<CoolerEntry> coolers) {}

    private static Loaded cached;

    public static synchronized Loaded load() {
        if (cached == null) cached = doLoad();
        return cached;
    }

    private static Loaded doLoad() {
        Map<String, JsonObject> cases = new LinkedHashMap<>();
        Map<String, JsonObject> coolers = new LinkedHashMap<>();
        try (InputStream in = WorkshopCatalogue.class.getResourceAsStream(BUNDLED)) {
            if (in == null) throw new IllegalStateException("Bundled workshop catalogue missing: " + BUNDLED);
            read(new InputStreamReader(in, StandardCharsets.UTF_8), BUNDLED, cases, coolers, true);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read bundled workshop catalogue", e);
        }
        Path patch = FMLPaths.CONFIGDIR.get().resolve("pcsimulator").resolve("workshop-catalogue.json");
        if (Files.isRegularFile(patch)) {
            try (Reader r = Files.newBufferedReader(patch, StandardCharsets.UTF_8)) {
                read(r, patch.toString(), cases, coolers, false);
            } catch (IOException e) {
                throw new IllegalStateException("Cannot read " + patch, e);
            }
        }
        List<CaseEntry> ce = new ArrayList<>();
        cases.forEach((n, o) -> ce.add(parseCase(n, o)));
        List<CoolerEntry> oe = new ArrayList<>();
        coolers.forEach((n, o) -> oe.add(new CoolerEntry(n, parseCooler(n, o))));
        return new Loaded(List.copyOf(ce), List.copyOf(oe));
    }

    private static void read(Reader reader, String source, Map<String, JsonObject> cases, Map<String, JsonObject> coolers, boolean bundled) {
        JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
        collect(root, "cases", "case_", source, cases, bundled);
        collect(root, "coolers", "cooler_", source, coolers, bundled);
    }

    private static void collect(JsonObject root, String key, String prefix, String source, Map<String, JsonObject> target, boolean bundled) {
        if (!root.has(key)) return;
        for (JsonElement e : root.getAsJsonArray(key)) {
            JsonObject o = e.getAsJsonObject();
            if (!o.has("id")) throw new IllegalStateException(source + ": entry without 'id' in " + key);
            String id = o.get("id").getAsString();
            if (!NAME.matcher(id).matches() || !id.startsWith(prefix))
                throw new IllegalStateException(source + ": bad id '" + id + "' (must match " + prefix + "[a-z0-9_]+)");
            if (!bundled && !target.containsKey(id)) {
                WorkshopModule.LOGGER.warn("{}: ignoring unknown workshop entry '{}' (patch files can only replace existing ids)", source, id);
                continue;
            }
            target.put(id, o);
        }
    }

    // ------------------------------------------------------------------ parsing

    private static CaseEntry parseCase(String name, JsonObject o) {
        try {
            Set<String> unset = new LinkedHashSet<>();
            long price = num(o, "basePriceCents", unset);
            int draw = (int) num(o, "powerDrawWatts", unset);
            int score = (int) num(o, "performanceScore", unset);
            Set<String> ff = new LinkedHashSet<>();
            for (JsonElement e : o.getAsJsonArray("boardFormFactors")) ff.add(e.getAsString());
            if (ff.isEmpty()) throw new IllegalStateException("boardFormFactors must not be empty");
            OptionalInt maxH = optInt(o, "maxCoolerHeightMm", unset);
            Set<Integer> rads = new LinkedHashSet<>();
            if (o.has("radiatorMountsMm")) for (JsonElement e : o.getAsJsonArray("radiatorMountsMm")) rads.add(e.getAsInt());
            else unset.add("radiatorMountsMm");
            boolean openAir = o.has("openAir") && o.get("openAir").getAsBoolean();
            CaseDefinition def = new CaseDefinition(tier(o), price, draw, score, str(o, "category"), ff, openAir, maxH, rads,
                    bool(o, "provisional"), unset);
            return new CaseEntry(name, def, str(o, "shape"));
        } catch (RuntimeException e) {
            throw new IllegalStateException("Workshop catalogue case '" + name + "': " + e.getMessage(), e);
        }
    }

    private static CoolerDefinition parseCooler(String name, JsonObject o) {
        try {
            Set<String> unset = new LinkedHashSet<>();
            long price = num(o, "basePriceCents", unset);
            int draw = (int) num(o, "powerDrawWatts", unset);
            int score = (int) num(o, "performanceScore", unset);
            Set<ResourceLocation> sockets = new LinkedHashSet<>();
            for (JsonElement e : o.getAsJsonArray("sockets")) {
                ResourceLocation rl = ResourceLocation.tryParse(e.getAsString());
                if (rl == null) throw new IllegalStateException("invalid socket id '" + e.getAsString() + "'");
                sockets.add(rl);
            }
            OptionalInt rad = o.has("radiatorMm") ? OptionalInt.of(o.get("radiatorMm").getAsInt()) : OptionalInt.empty();
            OptionalInt height = optInt(o, "heightMm", unset);
            String kind = str(o, "kind");
            return new CoolerDefinition(tier(o), price, draw, score, kind, o.has("display") ? str(o, "display") : "none",
                    bool(o, "rgb"), rad, height, sockets, bool(o, "provisional"), unset);
        } catch (RuntimeException e) {
            throw new IllegalStateException("Workshop catalogue cooler '" + name + "': " + e.getMessage(), e);
        }
    }

    private static com.pcsimulator.api.hardware.ComponentTier tier(JsonObject o) {
        String t = str(o, "tier");
        for (var v : com.pcsimulator.api.hardware.ComponentTier.values()) if (v.name().equalsIgnoreCase(t)) return v;
        throw new IllegalStateException("unknown tier '" + t + "'");
    }

    private static String str(JsonObject o, String k) {
        if (!o.has(k)) throw new IllegalStateException("missing '" + k + "'");
        return o.get(k).getAsString();
    }

    private static boolean bool(JsonObject o, String k) {
        return o.has(k) && o.get(k).getAsBoolean();
    }

    private static long num(JsonObject o, String k, Set<String> unset) {
        if (o.has(k)) {
            long v = o.get(k).getAsLong();
            if (v < 0) throw new IllegalStateException(k + " must be >= 0");
            return v;
        }
        unset.add(k);
        return 0L;
    }

    private static OptionalInt optInt(JsonObject o, String k, Set<String> unset) {
        if (o.has(k)) return OptionalInt.of(o.get(k).getAsInt());
        unset.add(k);
        return OptionalInt.empty();
    }
}
