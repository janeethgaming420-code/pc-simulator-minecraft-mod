package com.pcsimulator.workshop;

import com.mojang.logging.LogUtils;
import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.core.config.PCConfig;
import com.pcsimulator.core.data.PCWorldData;
import com.pcsimulator.core.module.PCModule;
import com.pcsimulator.workshop.config.WorkshopConfig;
import com.pcsimulator.workshop.hall.HallPlacer;
import com.pcsimulator.workshop.hall.HallPlan;
import com.pcsimulator.workshop.hall.HallSavedData;
import com.pcsimulator.workshop.hall.WorkshopCommands;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import org.slf4j.Logger;

/**
 * Cases, cooling and workshop (Claude 3). Claude 7 adds ONE line to ModuleList:
 * {@code new com.pcsimulator.workshop.WorkshopModule()}. Depends on no other module (shared registries + api only).
 */
public final class WorkshopModule implements PCModule {
    public static final String ID = "workshop";
    public static final Logger LOGGER = LogUtils.getLogger();

    @Override
    public String id() {
        return ID;
    }

    @Override
    public void register(IEventBus modBus, ModContainer container, Dist dist) {
        PCConfig.registerModuleConfig(container, ID, ModConfig.Type.SERVER, WorkshopConfig.SERVER.spec);
        WorkshopRegistries.init();
        NeoForge.EVENT_BUS.addListener(WorkshopCommands::onRegisterCommands);
        NeoForge.EVENT_BUS.addListener(WorkshopModule::onPlayerLoggedIn);
        NeoForge.EVENT_BUS.addListener(WorkshopModule::onPlayerRespawn);
    }

    @Override
    public void onServerStarted(MinecraftServer server) {
        if (!WorkshopConfig.SERVER.autoBuildHall.get() || !PCSimulatorAPI.isPCWorld(server)) return;
        HallSavedData data = PCWorldData.get(server, ID, "hall", HallSavedData.factory());
        if (data.built()) return;
        ServerLevel level = server.overworld();
        BlockPos origin = HallPlacer.pickOrigin(level, level.getSharedSpawnPos());
        LOGGER.info("Building workshop hall at {}", origin);
        HallPlacer.place(level, origin);
        data.markBuilt(origin);
        if (WorkshopConfig.SERVER.setWorldSpawn.get()) level.setDefaultSpawnPos(HallPlacer.spawnPos(origin), 180.0F);
    }

    private static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) keepOffRoof(p);
    }

    private static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) keepOffRoof(p);
    }

    /** Vanilla spawn placement uses the heightmap, which would put players on the hall roof. */
    private static void keepOffRoof(ServerPlayer player) {
        if (!WorkshopConfig.SERVER.setWorldSpawn.get() || player.getServer() == null) return;
        HallSavedData data = PCWorldData.get(player.getServer(), ID, "hall", HallSavedData.factory());
        BlockPos origin = data.origin();
        if (origin == null || player.level() != player.getServer().overworld()) return;
        if (HallPlacer.isInsideFootprint(origin, player.getX(), player.getZ()) && player.getY() >= origin.getY() + HallPlan.H) {
            BlockPos s = HallPlacer.spawnPos(origin);
            player.teleportTo(s.getX() + 0.5, s.getY(), s.getZ() + 0.5);
        }
    }
}
