package com.pcsimulator.workshop.api;

import java.util.Set;

/**
 * Motherboard form-factor ids used by cases. They follow the string convention Claude 2 uses for catalogue
 * attributes ({@code formFactor = "2.5_inch"}). ASSUMPTION TO CONFIRM WITH CLAUDE 2: motherboards expose their form
 * factor as the catalogue attribute {@code formFactor} with exactly these values (the current provisional
 * motherboard has no such attribute).
 */
public final class FormFactors {
    private FormFactors() {}

    public static final String ATTRIBUTE_KEY = "formFactor";
    public static final String ATX = "atx";
    public static final String MICRO_ATX = "micro_atx";
    public static final String MINI_ITX = "mini_itx";

    public static final Set<String> ALL = Set.of(ATX, MICRO_ATX, MINI_ITX);
}
