package com.pcsimulator.workshop.api;

import net.minecraft.resources.ResourceLocation;

import java.util.OptionalInt;
import java.util.Set;

/** Cooler-specific data. Implemented by the IHardwareComponent of every cooler. */
public interface ICoolerSpec {
    /** air_standard, air_tower, air_dual_tower, air_low_profile, aio_120, aio_240, aio_360. */
    String kind();

    /** none, lcd or infinity (AIO pump-head options). */
    String display();

    boolean rgb();

    boolean isLiquid();

    /** Radiator length for AIOs (120/240/360); empty for air coolers. */
    OptionalInt radiatorMm();

    /** Cooler height for air coolers; empty = not specified by the catalogue. */
    OptionalInt heightMm();

    /** CPU socket connector ids (same ids as {@code IHardwareComponent#connector()} of CPUs) this cooler mounts on. */
    Set<ResourceLocation> supportedSockets();
}
