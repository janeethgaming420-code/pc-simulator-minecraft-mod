package com.pcsimulator.workshop.api;

/**
 * Result of a compatibility query. {@code UNKNOWN} means "the catalogue does not specify the data needed" (it is
 * never silently turned into FITS or NO_FIT); the caller (Claude 4 / pcbuild) decides the policy.
 */
public record FitResult(Status status, String reasonKey) {
    public enum Status { FITS, NO_FIT, UNKNOWN }

    public static final FitResult FITS = new FitResult(Status.FITS, "compat.pcsimulator.workshop.fits");

    public static FitResult noFit(String reasonKey) {
        return new FitResult(Status.NO_FIT, reasonKey);
    }

    public static FitResult unknown(String reasonKey) {
        return new FitResult(Status.UNKNOWN, reasonKey);
    }

    public boolean fits() {
        return status == Status.FITS;
    }

    public boolean blocks() {
        return status == Status.NO_FIT;
    }
}
