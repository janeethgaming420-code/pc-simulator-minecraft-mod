package com.pcsimulator.workshop.api;

import com.pcsimulator.api.hardware.IHardwareComponent;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

/**
 * Stateless compatibility queries for Claude 4 (pcbuild). Inputs are plain core types so no module-to-module
 * import is needed:
 * <pre>
 *   IHardwareComponent caseDef = IHardwareItem.componentOf(caseStack).orElseThrow();
 *   FitResult r = WorkshopCompat.boardFitsCase(caseDef, boardFormFactor); // formFactor read by pcbuild
 * </pre>
 * Data that the catalogue does not specify yields {@link FitResult.Status#UNKNOWN}, never a guess.
 */
public final class WorkshopCompat {
    private WorkshopCompat() {}

    /** Does a motherboard of {@code boardFormFactor} (null = motherboard does not declare one) fit the case? */
    public static FitResult boardFitsCase(IHardwareComponent caseDef, @Nullable String boardFormFactor) {
        if (!(caseDef instanceof ICaseSpec spec)) return FitResult.unknown("compat.pcsimulator.workshop.not_a_case");
        if (boardFormFactor == null) return FitResult.unknown("compat.pcsimulator.workshop.board_form_factor_unknown");
        return spec.boardFormFactors().contains(boardFormFactor)
                ? FitResult.FITS : FitResult.noFit("compat.pcsimulator.workshop.board_too_large");
    }

    /** Does the cooler mount on the CPU socket {@code cpuSocket} (the CPU's {@code connector()})? */
    public static FitResult coolerFitsSocket(IHardwareComponent coolerDef, @Nullable ResourceLocation cpuSocket) {
        if (!(coolerDef instanceof ICoolerSpec spec)) return FitResult.unknown("compat.pcsimulator.workshop.not_a_cooler");
        if (cpuSocket == null) return FitResult.unknown("compat.pcsimulator.workshop.cpu_socket_unknown");
        if (spec.supportedSockets().isEmpty()) return FitResult.unknown("compat.pcsimulator.workshop.cooler_sockets_unspecified");
        return spec.supportedSockets().contains(cpuSocket)
                ? FitResult.FITS : FitResult.noFit("compat.pcsimulator.workshop.socket_mismatch");
    }

    /** Does the cooler physically fit the case (radiator mount for AIOs, clearance height for air coolers)? */
    public static FitResult coolerFitsCase(IHardwareComponent coolerDef, IHardwareComponent caseDef) {
        if (!(coolerDef instanceof ICoolerSpec cooler)) return FitResult.unknown("compat.pcsimulator.workshop.not_a_cooler");
        if (!(caseDef instanceof ICaseSpec box)) return FitResult.unknown("compat.pcsimulator.workshop.not_a_case");
        if (box.openAir()) return FitResult.FITS;
        if (cooler.isLiquid()) {
            if (cooler.radiatorMm().isEmpty()) return FitResult.unknown("compat.pcsimulator.workshop.radiator_unspecified");
            if (box.radiatorMountsMm().isEmpty()) return FitResult.unknown("compat.pcsimulator.workshop.case_radiator_unspecified");
            return box.radiatorMountsMm().contains(cooler.radiatorMm().getAsInt())
                    ? FitResult.FITS : FitResult.noFit("compat.pcsimulator.workshop.radiator_unsupported");
        }
        if (cooler.heightMm().isEmpty()) return FitResult.unknown("compat.pcsimulator.workshop.cooler_height_unspecified");
        if (box.maxCoolerHeightMm().isEmpty()) return FitResult.unknown("compat.pcsimulator.workshop.case_height_unspecified");
        return cooler.heightMm().getAsInt() <= box.maxCoolerHeightMm().getAsInt()
                ? FitResult.FITS : FitResult.noFit("compat.pcsimulator.workshop.cooler_too_tall");
    }
}
