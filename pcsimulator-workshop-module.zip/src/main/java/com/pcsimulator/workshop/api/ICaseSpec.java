package com.pcsimulator.workshop.api;

import java.util.OptionalInt;
import java.util.Set;

/** Case-specific data. Implemented by the IHardwareComponent of every case: {@code if (c instanceof ICaseSpec s)}. */
public interface ICaseSpec {
    /** Catalogue category, e.g. "standard", "gaming", "full_tower", "micro_atx", "mini_itx", "showcase", "open_bench", "mining_case", "mining_rack". */
    String category();

    /** Motherboard form factors (see {@link FormFactors}) this case can host. */
    Set<String> boardFormFactors();

    /** True for cases without an enclosure (test bench, mining frames): no cooler height / radiator limits apply. */
    boolean openAir();

    /** Maximum air-cooler height in millimetres; empty = not specified by the catalogue. */
    OptionalInt maxCoolerHeightMm();

    /** Radiator lengths (120/240/360) the case can mount; empty = not specified by the catalogue. */
    Set<Integer> radiatorMountsMm();
}
