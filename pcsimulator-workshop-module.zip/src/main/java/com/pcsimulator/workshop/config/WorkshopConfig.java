package com.pcsimulator.workshop.config;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Server config of the workshop module: {@code <world>/serverconfig/pcsimulator/workshop-server.toml}. */
public final class WorkshopConfig {
    private WorkshopConfig() {}

    public static final class Server {
        public final ModConfigSpec spec;
        public final ModConfigSpec.BooleanValue autoBuildHall;
        public final ModConfigSpec.BooleanValue setWorldSpawn;

        private Server(ModConfigSpec.Builder b) {
            b.push("hall");
            autoBuildHall = b.comment("Build the workshop hall at the world spawn the first time a PC Simulator world starts.")
                    .define("autoBuildHall", true);
            setWorldSpawn = b.comment("After building the hall, move the world spawn inside it and keep players off its roof.")
                    .define("setWorldSpawn", true);
            b.pop();
            spec = b.build();
        }
    }

    public static final Server SERVER = new Server(new ModConfigSpec.Builder());
}
