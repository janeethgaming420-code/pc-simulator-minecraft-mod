package com.pcsimulator.workshop.cooling;

import com.pcsimulator.api.hardware.ComponentTier;
import com.pcsimulator.api.hardware.ComponentType;
import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.workshop.api.ICoolerSpec;
import net.minecraft.resources.ResourceLocation;

import java.util.OptionalInt;
import java.util.Set;

/** Immutable cooler model. 0 price/power/score means "not set". Sockets are exposed as accepted connectors. */
public final class CoolerDefinition implements IHardwareComponent, ICoolerSpec {
    private final ComponentTier tier;
    private final long price;
    private final int draw;
    private final int score;
    private final String kind;
    private final String display;
    private final boolean rgb;
    private final OptionalInt radiator;
    private final OptionalInt height;
    private final Set<ResourceLocation> sockets;
    private final boolean provisional;
    private final Set<String> unset;

    public CoolerDefinition(ComponentTier tier, long price, int draw, int score, String kind, String display, boolean rgb,
                            OptionalInt radiator, OptionalInt height, Set<ResourceLocation> sockets, boolean provisional,
                            Set<String> unset) {
        this.tier = tier;
        this.price = price;
        this.draw = draw;
        this.score = score;
        this.kind = kind;
        this.display = display;
        this.rgb = rgb;
        this.radiator = radiator;
        this.height = height;
        this.sockets = Set.copyOf(sockets);
        this.provisional = provisional;
        this.unset = Set.copyOf(unset);
    }

    @Override public ComponentType type() { return ComponentType.COOLER; }
    @Override public ComponentTier tier() { return tier; }
    @Override public long basePriceCents() { return price; }
    @Override public int powerDrawWatts() { return draw; }
    @Override public int performanceScore() { return score; }
    /** The CPU sockets this cooler mounts on. */
    @Override public Set<ResourceLocation> acceptedConnectors() { return sockets; }

    @Override public String kind() { return kind; }
    @Override public String display() { return display; }
    @Override public boolean rgb() { return rgb; }
    @Override public boolean isLiquid() { return kind.startsWith("aio_"); }
    @Override public OptionalInt radiatorMm() { return radiator; }
    @Override public OptionalInt heightMm() { return height; }
    @Override public Set<ResourceLocation> supportedSockets() { return sockets; }

    public boolean provisional() { return provisional; }
    public Set<String> unsetFields() { return unset; }
}
