package com.pcsimulator.workshop.item;

import com.pcsimulator.api.PCRegistries;
import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.api.hardware.IHardwareItem;
import com.pcsimulator.core.registry.CoreDataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** A CPU cooler (air or AIO) as a hardware item. Installation is handled by pcbuild (Claude 4). */
public class CoolerItem extends Item implements IHardwareItem {
    private final ResourceLocation defaultComponentId;

    public CoolerItem(Properties properties, ResourceLocation defaultComponentId) {
        super(properties);
        this.defaultComponentId = defaultComponentId;
    }

    @Override
    public ItemStack getDefaultInstance() {
        ItemStack stack = super.getDefaultInstance();
        stack.set(CoreDataComponents.HARDWARE_ID.get(), defaultComponentId);
        return stack;
    }

    @Nullable
    @Override
    public IHardwareComponent getComponent(ItemStack stack) {
        return PCRegistries.HARDWARE_COMPONENTS.get(stack.getOrDefault(CoreDataComponents.HARDWARE_ID.get(), defaultComponentId));
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        IHardwareComponent c = getComponent(stack);
        if (c != null) WorkshopItemTooltips.append(c, lines);
    }
}
