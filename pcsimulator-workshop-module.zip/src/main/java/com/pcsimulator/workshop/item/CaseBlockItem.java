package com.pcsimulator.workshop.item;

import com.pcsimulator.api.PCRegistries;
import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.api.hardware.IHardwareItem;
import com.pcsimulator.core.registry.CoreDataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.Block;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** A PC case: a hardware item (CASE) that is also placeable as a physical case block. */
public class CaseBlockItem extends BlockItem implements IHardwareItem {
    private final ResourceLocation defaultComponentId;

    public CaseBlockItem(Block block, Properties properties, ResourceLocation defaultComponentId) {
        super(block, properties);
        this.defaultComponentId = defaultComponentId;
    }

    @Override
    public ItemStack getDefaultInstance() {
        ItemStack stack = super.getDefaultInstance();
        stack.set(CoreDataComponents.HARDWARE_ID.get(), defaultComponentId);
        return stack;
    }

    @Nullable
    @Override
    public IHardwareComponent getComponent(ItemStack stack) {
        return PCRegistries.HARDWARE_COMPONENTS.get(stack.getOrDefault(CoreDataComponents.HARDWARE_ID.get(), defaultComponentId));
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        IHardwareComponent c = getComponent(stack);
        if (c != null) WorkshopItemTooltips.append(c, lines);
    }
}
