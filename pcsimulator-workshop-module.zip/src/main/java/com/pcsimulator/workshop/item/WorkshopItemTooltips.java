package com.pcsimulator.workshop.item;

import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.workshop.cases.CaseDefinition;
import com.pcsimulator.workshop.cooling.CoolerDefinition;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

import java.util.List;

final class WorkshopItemTooltips {
    private WorkshopItemTooltips() {}

    private static String sorted(java.util.Collection<String> c) {
        return String.join(", ", c.stream().sorted().toList());
    }

    static void append(IHardwareComponent c, List<Component> lines) {
        lines.add(Component.translatable("tooltip.pcsimulator.workshop.type",
                Component.translatable("pcsimulator.workshop.type." + c.type().getSerializedName()),
                Component.translatable("pcsimulator.workshop.tier." + c.tier().getSerializedName())).withStyle(ChatFormatting.GRAY));
        if (c instanceof CaseDefinition d) {
            lines.add(Component.translatable("tooltip.pcsimulator.workshop.case_category",
                    Component.translatable("pcsimulator.workshop.case_category." + d.category())).withStyle(ChatFormatting.GRAY));
            lines.add(Component.translatable("tooltip.pcsimulator.workshop.boards", sorted(d.boardFormFactors())).withStyle(ChatFormatting.GRAY));
            if (d.openAir()) lines.add(Component.translatable("tooltip.pcsimulator.workshop.open_air").withStyle(ChatFormatting.GRAY));
            if (d.provisional()) lines.add(Component.translatable("tooltip.pcsimulator.workshop.provisional").withStyle(ChatFormatting.YELLOW));
            if (!d.unsetFields().isEmpty())
                lines.add(Component.translatable("tooltip.pcsimulator.workshop.unset", sorted(d.unsetFields())).withStyle(ChatFormatting.DARK_GRAY));
        } else if (c instanceof CoolerDefinition d) {
            lines.add(Component.translatable("tooltip.pcsimulator.workshop.cooler_kind",
                    Component.translatable("pcsimulator.workshop.cooler_kind." + d.kind())).withStyle(ChatFormatting.GRAY));
            if (d.radiatorMm().isPresent())
                lines.add(Component.translatable("tooltip.pcsimulator.workshop.radiator", d.radiatorMm().getAsInt()).withStyle(ChatFormatting.GRAY));
            if (!"none".equals(d.display()))
                lines.add(Component.translatable("tooltip.pcsimulator.workshop.display." + d.display()).withStyle(ChatFormatting.GRAY));
            if (d.rgb()) lines.add(Component.translatable("tooltip.pcsimulator.workshop.rgb").withStyle(ChatFormatting.LIGHT_PURPLE));
            if (d.provisional()) lines.add(Component.translatable("tooltip.pcsimulator.workshop.provisional").withStyle(ChatFormatting.YELLOW));
            if (!d.unsetFields().isEmpty())
                lines.add(Component.translatable("tooltip.pcsimulator.workshop.unset", sorted(d.unsetFields())).withStyle(ChatFormatting.DARK_GRAY));
        }
    }
}
