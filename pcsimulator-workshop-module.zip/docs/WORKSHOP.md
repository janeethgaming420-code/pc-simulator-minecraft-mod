# Cases, Cooling and Workshop (`com.pcsimulator.workshop`) - Claude 3

Module id `workshop` (not in `ModuleIds`; core files were NOT edited). `ModuleList` was NOT edited. Claude 7 adds ONE line:

    new com.pcsimulator.workshop.WorkshopModule()

The module depends on no other module. It uses only `CoreRegistries` (BLOCKS, ITEMS, HARDWARE_COMPONENTS),
`CoreCreativeTab`, `CoreDataComponents.HARDWARE_ID`, `PCConfig.registerModuleConfig`, `PCWorldData`, `PCSimulatorAPI`.
Note: ARCHITECTURE s3 proposed the id `pcbuild` for "Claude 3"; this assignment (cases/cooling/workshop) is different, so
`pcbuild` stays free for Claude 4.

## Honest status
* **Not compiled, not run in-game.** The sandbox had a JRE but no `javac`, Gradle or network.
* What WAS verified here: (1) `HallPlan` (pure Java) compiles and runs - counts, light estimate and the renders in
  `docs/screenshots/` come from its real output; (2) all other Java passes a javac parse (only unresolved Minecraft
  symbols remain); (3) `tools/validate.py` cross-checks Java block names, shapes, blockstates, models, textures, loot,
  tags and lang (32 blocks, 16 coolers: OK). Expect some API-signature fixes on the first real `./gradlew compileJava`.
* Screenshots are schematic renders of the generator output, not in-game captures.

## What is implemented
**Cases** (9, `data/pcsimulator/workshop/catalogue.json`): `case_standard`, `case_gaming`, `case_full_tower`,
`case_micro_atx`, `case_mini_itx`, `case_showcase`, `case_open_bench`, `case_mining` (Bitcoin mining case),
`case_mining_rack`. Each is (a) an `IHardwareComponent` (type CASE) in `HARDWARE_COMPONENTS` implementing `ICaseSpec`,
(b) a placeable `PCCaseBlock` (facing + shape, no block entity), (c) a `CaseBlockItem` that implements `IHardwareItem`.

**Cooling** (16 items): air standard / tower / dual-tower / low-profile, RGB tower + RGB dual-tower, AIO 120/240/360,
RGB 120/240/360, LCD 240/360, Infinity 240/360. Each is an `IHardwareComponent` (type COOLER) implementing
`ICoolerSpec` plus a `CoolerItem`. RGB/LCD/Infinity icons use animated colour textures (no fan rotation anywhere).

**Workshop** (23 blocks): concrete floor, floor marking, workshop wall, ceiling panel, ceiling light, steel column/beam,
LED strip light, wall light, wall air conditioner, PC building table, diagnostic table, metal shelf, storage cabinet,
parts drawer unit, pegboard, parts crates, stool, trash bin, fire extinguisher, whiteboard, toolbox, anti-static mat.
Tables connect to neighbours (fence-style legs); the table top is exactly one block high so a placed case sits flush.

**Hall** (`HallPlan`, built by `HallPlacer`): 48 x 32 interior, 12 high ceiling, concrete floor, grey walls, 6 high
windows (north 4, south 2, west 3, east 3), 8 wide entrance in the south wall, skylight strips, 40 ceiling lights,
5 rows of hanging LED strips, 9 wall lights, 8 wall air conditioners, 4 building tables (7x3), 2 diagnostic tables (5x2),
186 shelf blocks plus cabinets/drawers/pegboards/whiteboard, and **8 marked open-floor bays** (6x6) plus free floor.
Estimated floor light (block light only, BFS over the plan): average 7.3, minimum 3 (14 of 1536 floor cells < 5);
skylights add daylight. Mobs cannot spawn (block light > 0 everywhere; the dimension type has block-light limit 0).

Building the hall: automatic once per PC world at `ServerStarted` around the world spawn (server config
`workshop-server.toml`: `autoBuildHall`, `setWorldSpawn`), or `/pcsim workshop build` (op, centred on you),
`/pcsim workshop info`, `/pcsim workshop tp`. The terrain is flattened (ring of 5 blocks), a foundation fills below.
Vanilla puts new/respawning players on the highest block (the roof), so players found on the roof inside the footprint
are teleported to the hall spawn on login/respawn (`setWorldSpawn`).

## Compatibility rules and what is NOT specified (rule 11)
No agreed numbers exist for case dimensions, cooler heights or radiator mounts, so none were invented. All price, power,
score, `maxCoolerHeightMm`, `radiatorMountsMm`, `heightMm` fields are **unset** (0 / empty), shown as "Not set" in tooltips,
and all entries carry `provisional: true`, tier `entry` (the core API requires a tier).
`WorkshopCompat` therefore returns `UNKNOWN` (never a guess) when data is missing:

| Query | Rule |
|---|---|
| `boardFitsCase(case, boardFormFactor)` | form factor in the case's `boardFormFactors` (ids `atx`, `micro_atx`, `mini_itx`; mATX case = {micro_atx, mini_itx}, ITX case = {mini_itx}, everything else = all three) |
| `coolerFitsSocket(cooler, cpuSocket)` | socket in cooler `sockets` (currently only `pcsimulator:connector/cpu_socket/provisional`) |
| `coolerFitsCase(cooler, case)` | open-air case = fits; AIO: radiator size in case mounts; air: height <= case clearance; missing data = UNKNOWN |

The "all three form factors for ATX-class cases" and "mining frames are open-air" rows are category-level assumptions;
change them in the JSON only. Patch file `config/pcsimulator/workshop-catalogue.json` may replace existing ids.

## Integration notes for Claude 4 (pcbuild)
1. **No import of `com.pcsimulator.workshop`** (ARCHITECTURE rule 2). Detect parts through tags:
   `pcsimulator:pc_cases` (block + item), `pcsimulator:pc_coolers` (item), `pcsimulator:workshop_tables` and
   `pcsimulator:pc_build_surfaces` (block). Read definitions via `IHardwareItem.componentOf(stack)`.
2. **Decision needed (Claude 1/7):** `workshop.api.*` (`WorkshopCompat`, `FitResult`, `ICaseSpec`, `ICoolerSpec`,
   `FormFactors`) is what pcbuild needs, but it lives in a module package. It only depends on core api + Minecraft, so the
   clean fix is to move it to `com.pcsimulator.api.hardware` (no code change). Until then pcbuild can read
   `component.acceptedConnectors()` (coolers: supported CPU sockets) and tags.
3. A placed case is `PCCaseBlock` (`HorizontalDirectionalBlock.FACING`, front = north in the model; shape table in
   `CaseShape`). It has no block entity and no `IPCHost`: add yours by registering a block-entity type for the blocks of
   tag `pcsimulator:pc_cases` and swap/extend the block via your own `BlockEntityType`. Cases drop themselves; the item
   works without the `HARDWARE_ID` component (falls back to its own id), like Claude 2's items.
4. Case-side data you need: `ICaseSpec.boardFormFactors()`; the motherboard's form factor must come from Claude 2.
   **Claude 2 must add `formFactor` (`atx`/`micro_atx`/`mini_itx`) to motherboard attributes** (the provisional board has
   none) and finalise CPU socket ids; then update `sockets` in my catalogue. `HardwareMeta` is not reachable across
   modules (Claude 2 documented this); pcbuild needs an api accessor or must parse the catalogue.
5. Not done (yours): grabbing, rotating, snapping, installing, panel opening, per-slot counts for case drive bays/fans.
   No wires, screws or fan rotation exist in my assets.
6. Table surfaces: top face at exactly y+1.0; build surfaces include the concrete floor and floor-marking blocks.

## Other integration points for Claude 7
* `python3 tools/merge_lang.py --write` merges `en_us.workshop.json` and `en_us.hardware.json` into `en_us.json`
  (conflict-checked). Without it item/block names show as raw keys.
* New resource paths: `data/pcsimulator/workshop/`, `loot_table/blocks/*`, `tags/{block,item}/*`, and
  `data/minecraft/tags/block/mineable/pickaxe.json` (only mine).
* Claude 6 (world): the hall is built at the shared spawn if `autoBuildHall` is on; turn it off and call
  `HallPlacer.place(level, HallPlacer.pickOrigin(level, center))` yourself if you prefer another site.
* The CoreCreativeTab icon is still the core placeholder.

## Known limitations
* Shelves, cabinets and drawers are decorative (no inventories). Storage UI/containers would be a follow-up.
* Hall light under the hanging LED rows is 9-10, minimum 3 in corners; add lamps if brighter is wanted.
* Textures are generated placeholders; models are cuboid approximations (the case models have not been viewed in-game).
* A catalogue patch cannot add new ids (no model/asset would exist).

## Regenerating assets / checks
    python3 tools/gen_assets.py      # textures, models, blockstates, loot, tags, lang fragment (Pillow)
    python3 tools/validate.py        # static consistency checks
    ./gradlew build                  # real build (needs JDK 21 + network); quick check: ./gradlew compileJava
