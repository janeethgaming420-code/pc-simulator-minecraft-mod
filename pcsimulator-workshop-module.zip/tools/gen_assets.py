#!/usr/bin/env python3
"""Generates every workshop asset (textures, models, blockstates, loot tables, tags, lang fragment).

Run from the project root:  python3 tools/gen_assets.py   (needs Pillow)
Re-running overwrites generated files. Textures are procedural placeholder art, not final art.
Block names / shapes here must match WorkshopBlocks.java, DecorShape.java and CaseShape.java
(tools/validate.py checks the names)."""
import colorsys, json, os, random
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
RES = os.path.join(ROOT, "src/main/resources")
NS = "pcsimulator"
A = f"{RES}/assets/{NS}"
D = f"{RES}/data/{NS}"


def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(text)


def wj(path, obj):
    w(path, json.dumps(obj, indent=2) + "\n")


# ------------------------------------------------------------------ textures
def img(fill=(0, 0, 0, 255), size=16):
    return Image.new("RGBA", (size, size), fill)


def noise(im, amt, seed=1):
    r = random.Random(seed)
    px = im.load()
    for y in range(im.height):
        for x in range(im.width):
            c = px[x, y]
            if c[3] == 0:
                continue
            d = r.randint(-amt, amt)
            px[x, y] = (max(0, min(255, c[0] + d)), max(0, min(255, c[1] + d)), max(0, min(255, c[2] + d)), c[3])
    return im


def save_tex(kind, name, im):
    p = f"{A}/textures/{kind}/{name}.png"
    os.makedirs(os.path.dirname(p), exist_ok=True)
    im.save(p)


def anim(kind, name, frames, frametime=4):
    strip = Image.new("RGBA", (16, 16 * len(frames)))
    for i, f in enumerate(frames):
        strip.paste(f, (0, 16 * i))
    save_tex(kind, name, strip)
    wj(f"{A}/textures/{kind}/{name}.png.mcmeta", {"animation": {"frametime": frametime}})


def hue(h, s=1.0, v=1.0):
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, s, v)
    return (int(r * 255), int(g * 255), int(b * 255), 255)


def block_textures():
    T = lambda n, im: save_tex("block", n, im)
    # concrete floor with a faint expansion joint
    im = noise(img((128, 128, 130, 255)), 7, 1)
    d = ImageDraw.Draw(im)
    d.line([(0, 15), (15, 15)], fill=(104, 104, 106, 255))
    d.line([(15, 0), (15, 15)], fill=(104, 104, 106, 255))
    T("concrete_floor", im)
    # yellow floor marking
    im = noise(img((128, 128, 130, 255)), 7, 2)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 5, 15, 10], fill=(232, 190, 30, 255))
    T("floor_marking", noise(im, 4, 3))
    T("workshop_wall", noise(img((156, 158, 162, 255)), 5, 4))
    im = noise(img((226, 228, 230, 255)), 4, 5)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], outline=(190, 192, 196, 255))
    T("ceiling_panel", im)
    im = img((240, 244, 250, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], outline=(170, 176, 186, 255))
    d.rectangle([2, 2, 13, 13], fill=(255, 255, 245, 255))
    T("ceiling_light", im)
    im = noise(img((92, 96, 104, 255)), 6, 6)
    d = ImageDraw.Draw(im)
    d.line([(0, 0), (0, 15)], fill=(120, 124, 132, 255))
    d.line([(15, 0), (15, 15)], fill=(60, 62, 68, 255))
    T("steel_column", im)
    T("steel_beam", noise(img((74, 78, 86, 255)), 6, 7))
    T("metal_dark", noise(img((60, 63, 70, 255)), 6, 8))
    T("metal_light", noise(img((150, 154, 162, 255)), 6, 9))
    # table
    im = noise(img((40, 76, 58, 255)), 5, 10)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], outline=(30, 56, 44, 255))
    for i in range(2, 15, 4):
        d.line([(i, 2), (i, 13)], fill=(46, 88, 66, 255))
    T("table_top", im)
    T("table_edge", noise(img((84, 88, 96, 255)), 5, 11))
    T("table_leg", noise(img((58, 61, 68, 255)), 5, 12))
    im = noise(img((36, 54, 90, 255)), 5, 13)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], outline=(26, 40, 70, 255))
    d.rectangle([5, 5, 10, 10], outline=(70, 110, 170, 255))
    T("diag_top", im)
    # diagnostic equipment
    im = img((40, 42, 48, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([1, 1, 14, 8], fill=(10, 30, 20, 255), outline=(90, 94, 100, 255))
    d.line([(2, 5), (4, 3), (6, 7), (8, 4), (10, 6), (12, 3)], fill=(60, 255, 120, 255))
    for i in range(3):
        d.rectangle([2 + i * 4, 11, 4 + i * 4, 13], fill=(180, 60, 50, 255) if i == 1 else (170, 172, 178, 255))
    T("equip_front", im)
    im = img((18, 20, 26, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([1, 1, 14, 14], fill=(24, 60, 110, 255))
    d.line([(2, 12), (5, 8), (8, 10), (11, 5), (14, 6)], fill=(120, 220, 255, 255))
    T("screen", im)
    # shelving / storage
    T("shelf_board", noise(img((120, 124, 132, 255)), 6, 14))
    T("shelf_post", noise(img((46, 90, 160, 255)), 5, 15))
    im = noise(img((170, 174, 180, 255)), 5, 16)
    d = ImageDraw.Draw(im)
    d.line([(8, 1), (8, 14)], fill=(110, 114, 120, 255))
    d.rectangle([0, 0, 15, 15], outline=(120, 124, 130, 255))
    T("cabinet_front", im)
    T("cabinet_side", noise(img((150, 154, 160, 255)), 5, 17))
    im = noise(img((150, 154, 160, 255)), 4, 18)
    d = ImageDraw.Draw(im)
    for y in (0, 4, 8, 12):
        d.rectangle([1, y + 1, 14, y + 3], outline=(96, 100, 106, 255), fill=(172, 176, 182, 255))
        d.rectangle([6, y + 2, 9, y + 2], fill=(50, 52, 58, 255))
    T("drawer_front", im)
    im = noise(img((196, 170, 120, 255)), 5, 19)
    d = ImageDraw.Draw(im)
    for y in range(1, 16, 3):
        for x in range(1, 16, 3):
            d.point((x, y), fill=(90, 70, 40, 255))
    T("pegboard", im)
    T("tool_red", noise(img((190, 50, 44, 255)), 5, 20))
    T("tool_grey", noise(img((120, 124, 130, 255)), 5, 21))
    im = img((236, 238, 240, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], outline=(150, 154, 160, 255))
    d.line([(2, 4), (9, 4)], fill=(40, 80, 200, 255))
    d.line([(2, 7), (12, 7)], fill=(200, 50, 50, 255))
    d.line([(2, 10), (7, 10)], fill=(40, 40, 40, 255))
    T("whiteboard", im)
    im = noise(img((50, 100, 170, 255)), 6, 22)
    d = ImageDraw.Draw(im)
    d.line([(0, 8), (15, 8)], fill=(30, 66, 120, 255))
    d.rectangle([0, 0, 15, 15], outline=(36, 76, 134, 255))
    T("crate", im)
    T("stool_seat", noise(img((30, 32, 38, 255)), 6, 23))
    T("bin", noise(img((90, 94, 102, 255)), 6, 24))
    T("bin_dark", noise(img((40, 42, 48, 255)), 6, 25))
    T("extinguisher", noise(img((200, 40, 36, 255)), 6, 26))
    im = noise(img((200, 56, 40, 255)), 6, 27)
    d = ImageDraw.Draw(im)
    d.line([(0, 8), (15, 8)], fill=(120, 30, 24, 255))
    T("toolbox", im)
    T("mat", noise(img((24, 24, 28, 255)), 4, 28))
    # air conditioner
    im = img((236, 238, 240, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], outline=(190, 194, 198, 255))
    for y in range(9, 14, 2):
        d.line([(1, y), (14, y)], fill=(170, 174, 180, 255))
    d.rectangle([11, 2, 13, 3], fill=(60, 200, 90, 255))
    T("ac_front", im)
    T("ac_body", noise(img((226, 228, 232, 255)), 4, 29))
    # lights
    im = img((70, 72, 78, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([2, 2, 13, 13], fill=(255, 255, 240, 255))
    T("light_panel", im)
    im = img((255, 255, 240, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 3], fill=(200, 204, 210, 255))
    d.rectangle([0, 12, 15, 15], fill=(200, 204, 210, 255))
    T("led_strip", im)
    # case textures
    im = noise(img((34, 36, 42, 255)), 5, 30)
    d = ImageDraw.Draw(im)
    for y in range(2, 14, 2):
        for x in range(1, 15, 2):
            d.point((x + (y // 2) % 2, y), fill=(14, 15, 18, 255))
    d.ellipse([7, 12, 8, 13], fill=(180, 190, 200, 255))
    d.point((11, 13), fill=(60, 220, 90, 255))
    T("case_front", im)
    T("case_side", noise(img((44, 46, 54, 255)), 5, 31))
    im = noise(img((38, 40, 46, 255)), 5, 32)
    d = ImageDraw.Draw(im)
    for x in range(3, 14, 2):
        d.line([(x, 3), (x, 12)], fill=(18, 19, 22, 255))
    T("case_top", im)
    T("case_white_side", noise(img((226, 228, 232, 255)), 4, 33))
    im = img((120, 180, 230, 70))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], outline=(190, 220, 245, 150))
    T("case_glass", im)
    im = noise(img((26, 70, 48, 255)), 6, 34)
    d = ImageDraw.Draw(im)
    d.rectangle([3, 3, 7, 7], fill=(150, 150, 156, 255))
    d.rectangle([9, 9, 14, 11], fill=(20, 22, 26, 255))
    T("case_interior", im)
    T("bench_board", noise(img((200, 204, 210, 255)), 5, 35))
    T("mining_frame", noise(img((176, 180, 188, 255)), 5, 36))
    T("rack_steel", noise(img((110, 114, 122, 255)), 5, 37))
    im = noise(img((24, 24, 28, 255)), 4, 38)
    d = ImageDraw.Draw(im)
    d.rectangle([2, 5, 13, 11], outline=(60, 60, 66, 255))
    d.ellipse([4, 6, 7, 10], fill=(12, 12, 14, 255))
    d.ellipse([9, 6, 12, 10], fill=(12, 12, 14, 255))
    T("gpu_rig", im)
    frames = []
    for i in range(8):
        f = img((20, 20, 24, 255))
        d = ImageDraw.Draw(f)
        for x in range(16):
            d.line([(x, 6), (x, 9)], fill=hue(i / 8 + x / 24))
        frames.append(f)
    anim("block", "case_rgb", frames, 4)


# ------------------------------------------------------------------ item textures (coolers)
def circle_fan(d, cx, cy, r, ring=(30, 30, 34, 255), hub=(90, 94, 100, 255)):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=ring)
    d.ellipse([cx - 1, cy - 1, cx + 1, cy + 1], fill=hub)
    d.point((cx, cy - r + 1), fill=hub)
    d.point((cx, cy + r - 1), fill=hub)


def fins(d, x1, y1, x2, y2, horizontal=False):
    d.rectangle([x1, y1, x2, y2], fill=(176, 180, 188, 255))
    if horizontal:
        for y in range(y1, y2 + 1, 2):
            d.line([(x1, y), (x2, y)], fill=(120, 124, 132, 255))
    else:
        for x in range(x1, x2 + 1, 2):
            d.line([(x, y1), (x, y2)], fill=(120, 124, 132, 255))


def cooler_icon(kind, accent=None, display="none"):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    ring = accent if accent else (30, 30, 34, 255)
    if kind == "air_standard":
        d.rectangle([3, 8, 12, 14], fill=(150, 154, 162, 255))
        fins(d, 3, 8, 12, 14)
        circle_fan(d, 8, 5, 4, ring)
    elif kind == "air_tower":
        fins(d, 4, 2, 11, 13)
        d.rectangle([4, 14, 11, 15], fill=(200, 140, 70, 255))
        circle_fan(d, 8, 8, 3, ring)
    elif kind == "air_dual_tower":
        fins(d, 1, 2, 5, 13)
        fins(d, 10, 2, 14, 13)
        d.rectangle([1, 14, 14, 15], fill=(200, 140, 70, 255))
        circle_fan(d, 8, 8, 2, ring)
    elif kind == "air_low_profile":
        d.rectangle([2, 8, 13, 13], fill=(150, 154, 162, 255))
        fins(d, 2, 10, 13, 13, horizontal=True)
        circle_fan(d, 8, 8, 3, ring)
    else:
        n = int(kind.split("_")[1])
        # radiator + fans
        if n == 120:
            d.rectangle([9, 1, 14, 14], fill=(60, 62, 68, 255))
            circle_fan(d, 11, 7, 2, ring)
            pump = (1, 8, 6, 13)
        elif n == 240:
            d.rectangle([7, 0, 15, 15], fill=(60, 62, 68, 255))
            circle_fan(d, 11, 4, 3, ring)
            circle_fan(d, 11, 12, 3, ring)
            pump = (0, 8, 5, 13)
        else:
            d.rectangle([9, 0, 15, 15], fill=(60, 62, 68, 255))
            circle_fan(d, 12, 3, 2, ring)
            circle_fan(d, 12, 8, 2, ring)
            circle_fan(d, 12, 13, 2, ring)
            pump = (1, 6, 7, 12)
        d.rectangle(list(pump), fill=(28, 30, 36, 255), outline=(110, 114, 122, 255))
        px1, py1, px2, py2 = pump
        if display == "lcd":
            d.rectangle([px1 + 1, py1 + 1, px2 - 1, py2 - 1], fill=(40, 120, 220, 255))
        elif display == "infinity":
            d.rectangle([px1 + 1, py1 + 1, px2 - 1, py2 - 1], outline=ring if accent else (200, 80, 240, 255))
            d.rectangle([px1 + 2, py1 + 2, px2 - 2, py2 - 2], outline=(120, 60, 200, 255))
        d.line([(px2, (py1 + py2) // 2), (8, (py1 + py2) // 2)], fill=(24, 24, 28, 255))
    return im


def item_textures(coolers):
    for c in coolers:
        kind, rgb, disp = c["kind"], c.get("rgb", False), c.get("display", "none")
        if rgb or disp != "none":
            frames = []
            for i in range(8):
                acc = hue(i / 8) if (rgb or disp == "infinity") else None
                frames.append(cooler_icon(kind, acc, disp))
            anim("item", c["id"], frames, 5)
        else:
            save_tex("item", c["id"], cooler_icon(kind))
        wj(f"{A}/models/item/{c['id']}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"{NS}:item/{c['id']}"}})


# ------------------------------------------------------------------ model helpers
FACES = ["north", "south", "east", "west", "up", "down"]


def box(frm, to, tex, **over):
    """tex: texture key for all faces, overridden per face by north=..., up=..., side=... (east+west+south+north not set)."""
    faces = {}
    for f in FACES:
        k = over.get(f)
        if k is None and f in ("east", "west", "south", "north") and "side" in over:
            k = over["side"]
        faces[f] = {"texture": "#" + (k or tex)}
    return {"from": list(frm), "to": list(to), "faces": faces}


def model(textures, elements, parent="minecraft:block/block", translucent=False, particle=None):
    t = dict(textures)
    t["particle"] = t[particle] if particle else next(iter(textures.values()))
    m = {"parent": parent, "textures": t, "elements": elements}
    if translucent:
        m["render_type"] = "minecraft:translucent"
    return m


def tx(name):
    return f"{NS}:block/{name}"


def save_model(name, m):
    wj(f"{A}/models/block/{name}.json", m)


def item_model(name, parent=None):
    wj(f"{A}/models/item/{name}.json", {"parent": f"{NS}:block/{parent or name}"})


def facing_state(model_name):
    rot = {"north": 0, "east": 90, "south": 180, "west": 270}
    return {"variants": {f"facing={f}": ({"model": f"{NS}:block/{model_name}", "y": y} if y else {"model": f"{NS}:block/{model_name}"})
                         for f, y in rot.items()}}


def blockstate(name, st):
    wj(f"{A}/blockstates/{name}.json", st)


# ------------------------------------------------------------------ case geometry (facing north, front at z min)
CASE_SHAPES = {  # must match CaseShape.java
    "mid_tower": (4, 0, 1, 12, 14, 15), "gaming_tower": (3, 0, 1, 13, 15, 15), "full_tower": (3, 0, 0, 13, 16, 16),
    "micro_atx": (4, 0, 2, 12, 11, 14), "mini_itx": (4, 0, 3, 12, 8, 13), "showcase": (3, 0, 2, 13, 14, 14),
    "open_bench": (1, 0, 1, 15, 8, 15), "mining_case": (1, 0, 2, 15, 8, 14), "mining_rack": (1, 0, 1, 15, 16, 15),
}


def solid_case(name, shp, front="case_front", side="case_side", top="case_top", glass_side=False, rgb_front=False):
    x1, y1, z1, x2, y2, z2 = shp
    tex = {"front": tx(front), "side": tx(side), "top": tx(top), "glass": tx("case_glass"), "inner": tx("case_interior"),
           "rgb": tx("case_rgb"), "metal": tx("metal_dark")}
    els = []
    right = x2 - 1 if glass_side else x2
    els.append(box((x1, y1 + 1, z1), (right, y2, z2), "side", north="front", up="top", down="metal"))
    els.append(box((x1 + 1, y1, z1 + 1), (x1 + 3, y1 + 1, z1 + 3), "metal"))
    els.append(box((x2 - 3, y1, z1 + 1), (x2 - 1, y1 + 1, z1 + 3), "metal"))
    els.append(box((x1 + 1, y1, z2 - 3), (x1 + 3, y1 + 1, z2 - 1), "metal"))
    els.append(box((x2 - 3, y1, z2 - 3), (x2 - 1, y1 + 1, z2 - 1), "metal"))
    if glass_side:
        # interior seen through the tempered-glass panel on the +x side (static fans/boards only)
        els.append(box((right - 0.5, y1 + 2, z1 + 3), (right, y2 - 2, z2 - 2), "inner"))
        els.append(box((right, y1 + 1, z1), (x2, y2, z2), "glass"))
    if rgb_front:
        els.append(box((x1 + 1, y1 + 3, z1 - 0.5), (x2 - 1, y1 + 5, z1), "rgb"))
    return model(tex, els, translucent=glass_side, particle="side")


def showcase_case(name, shp):
    x1, y1, z1, x2, y2, z2 = shp
    tex = {"frame": tx("metal_dark"), "glass": tx("case_glass"), "inner": tx("case_interior"), "front": tx("case_front"),
           "rgb": tx("case_rgb")}
    els = []
    for (a, b) in [(x1, z1), (x2 - 1, z1), (x1, z2 - 1), (x2 - 1, z2 - 1)]:
        els.append(box((a, y1, b), (a + 1, y2, b + 1), "frame"))
    els.append(box((x1, y1, z1), (x2, y1 + 1, z2), "frame"))
    els.append(box((x1, y2 - 1, z1), (x2, y2, z2), "frame"))
    els.append(box((x1 + 1, y1 + 1, z1 + 1), (x2 - 1, y2 - 1, z1 + 2), "front", north="front"))
    els.append(box((x1 + 2, y1 + 2, z1 + 3), (x1 + 3, y2 - 3, z2 - 2), "inner"))
    els.append(box((x1 + 3, y1 + 2, z2 - 4), (x2 - 3, y1 + 4, z2 - 2), "rgb"))
    els.append(box((x1 + 1, y1 + 1, z1), (x2 - 1, y2 - 1, z2), "glass", up="glass", down="glass"))
    return model(tex, els, translucent=True, particle="frame")


def bench_case(shp):
    tex = {"base": tx("rack_steel"), "board": tx("bench_board"), "post": tx("metal_dark"), "inner": tx("case_interior")}
    els = [box((1, 0, 1), (15, 1, 15), "base"),
           box((1, 1, 1), (2, 8, 2), "post"), box((14, 1, 1), (15, 8, 2), "post"),
           box((1, 1, 14), (2, 8, 15), "post"), box((14, 1, 14), (15, 8, 15), "post"),
           box((3, 3, 3), (13, 4, 13), "board"), box((4, 4, 4), (12, 4.5, 12), "inner"),
           box((1, 7, 1), (15, 8, 2), "post"), box((1, 7, 14), (15, 8, 15), "post")]
    return model(tex, els, particle="base")


def mining_case(shp):
    tex = {"frame": tx("mining_frame"), "plate": tx("rack_steel"), "rig": tx("gpu_rig")}
    els = [box((1, 0, 2), (15, 1, 14), "plate")]
    for (a, b) in [(1, 2), (14, 2), (1, 13), (14, 13)]:
        els.append(box((a, 1, b), (a + 1, 8, b + 1), "frame"))
    els.append(box((1, 7, 2), (15, 8, 3), "frame"))
    els.append(box((1, 7, 13), (15, 8, 14), "frame"))
    els.append(box((1, 3, 4), (15, 4, 12), "frame"))
    for i in range(6):
        els.append(box((2 + i * 2.2, 4, 5), (3.9 + i * 2.2, 7, 11), "rig", up="plate", down="plate"))
    return model(tex, els, particle="plate")


def mining_rack(shp):
    tex = {"frame": tx("rack_steel"), "shelf": tx("mining_frame"), "rig": tx("gpu_rig")}
    els = []
    for (a, b) in [(1, 1), (14, 1), (1, 14), (14, 14)]:
        els.append(box((a, 0, b), (a + 1, 16, b + 1), "frame"))
    for y in (0, 5, 10, 15):
        els.append(box((1, y, 1), (15, y + 1, 15), "shelf"))
    for y in (1, 6, 11):
        for i in range(3):
            els.append(box((2 + i * 4, y, 3), (5.5 + i * 4, y + 3, 13), "rig", up="shelf", down="shelf"))
    return model(tex, els, particle="frame")


def build_case_models():
    for shape, shp in CASE_SHAPES.items():
        if shape == "mid_tower":
            m = solid_case(shape, shp)
        elif shape == "gaming_tower":
            m = solid_case(shape, shp, glass_side=True, rgb_front=True)
        elif shape == "full_tower":
            m = solid_case(shape, shp, glass_side=True)
        elif shape == "micro_atx":
            m = solid_case(shape, shp, side="case_white_side")
        elif shape == "mini_itx":
            m = solid_case(shape, shp, side="case_white_side")
        elif shape == "showcase":
            m = showcase_case(shape, shp)
        elif shape == "open_bench":
            m = bench_case(shp)
        elif shape == "mining_case":
            m = mining_case(shp)
        else:
            m = mining_rack(shp)
        save_model(f"case_shape_{shape}", m)


# ------------------------------------------------------------------ furniture / hall models
def cube_all(name, tex):
    save_model(name, {"parent": "minecraft:block/cube_all", "textures": {"all": tx(tex)}})
    blockstate(name, {"variants": {"": {"model": f"{NS}:block/{name}"}}})
    item_model(name)


def decor(name, textures, elements, particle=None):
    save_model(name, model({k: tx(v) for k, v in textures.items()}, elements, particle=particle))
    blockstate(name, facing_state(name))
    item_model(name)


def build_furniture():
    for n, t in [("concrete_floor", "concrete_floor"), ("floor_marking", "floor_marking"), ("workshop_wall", "workshop_wall"),
                 ("ceiling_panel", "ceiling_panel"), ("ceiling_light", "ceiling_light"), ("steel_beam", "steel_beam")]:
        cube_all(n, t)
    save_model("steel_column", {"parent": "minecraft:block/cube_all", "textures": {"all": tx("steel_column")}})
    blockstate("steel_column", {"variants": {"": {"model": f"{NS}:block/steel_column"}}})
    item_model("steel_column")

    # tables (multipart: top + corner legs only where no neighbouring table)
    def table(name, top, edge, leg):
        tex = {"top": tx(top), "edge": tx(edge), "leg": tx(leg)}
        save_model(f"{name}_top", model(tex, [box((0, 13, 0), (16, 16, 16), "edge", up="top")], particle="edge"))
        corners = {"nw": (0, 0), "ne": (13, 0), "sw": (0, 13), "se": (13, 13)}
        for c, (x, z) in corners.items():
            save_model(f"{name}_leg_{c}", model(tex, [box((x, 0, z), (x + 3, 13, z + 3), "leg")], particle="leg"))
        els = [box((0, 13, 0), (16, 16, 16), "edge", up="top")] + \
              [box((x, 0, z), (x + 3, 13, z + 3), "leg") for (x, z) in corners.values()]
        save_model(f"{name}_item", model(tex, els, particle="edge"))
        wj(f"{A}/models/item/{name}.json", {"parent": f"{NS}:block/{name}_item"})
        return corners

    corners = table("building_table", "table_top", "table_edge", "table_leg")
    legs = {"nw": ("north", "west"), "ne": ("north", "east"), "sw": ("south", "west"), "se": ("south", "east")}

    def multipart(name, extra=None):
        parts = [{"apply": {"model": f"{NS}:block/{name}_top"}}]
        for c, (a, b) in legs.items():
            parts.append({"when": {"AND": [{a: "false"}, {b: "false"}]}, "apply": {"model": f"{NS}:block/{name}_leg_{c}"}})
        if extra:
            parts += extra
        return {"multipart": parts}

    blockstate("building_table", multipart("building_table"))

    table("diagnostic_table", "diag_top", "table_edge", "table_leg")
    # operator side = facing; equipment at the back (opposite side). Model authored for facing=north (back at +z).
    eq = model({"equip": tx("equip_front"), "screen": tx("screen"), "metal": tx("metal_dark")},
               [box((1, 16, 9), (8, 23, 16), "metal", north="equip"),
                box((10, 16, 13), (14, 17, 16), "metal"), box((11, 17, 14), (13, 20, 15), "metal"),
                box((9, 19, 12), (15, 26, 13.5), "metal", north="screen")], particle="metal")
    save_model("diagnostic_table_equipment", eq)
    extra = []
    for f, y in (("north", 0), ("east", 90), ("south", 180), ("west", 270)):
        ap = {"model": f"{NS}:block/diagnostic_table_equipment"}
        if y:
            ap["y"] = y
        extra.append({"when": {"facing": f}, "apply": ap})
    blockstate("diagnostic_table", multipart("diagnostic_table", extra))

    # shelf (back at +z)
    els = []
    for (x, z) in [(0, 6), (14.5, 6), (0, 14.5), (14.5, 14.5)]:
        els.append(box((x, 0, z), (x + 1.5, 16, z + 1.5), "post"))
    for y in (0, 5, 10, 15):
        els.append(box((0, y, 6), (16, y + 1, 16), "board"))
    els += [box((2, 1, 8), (6, 4, 13), "crate"), box((8, 1, 9), (13, 3, 14), "crate"),
            box((3, 6, 8), (7, 9, 14), "crate"), box((9, 11, 9), (14, 14, 14), "crate")]
    decor("metal_shelf", {"post": "shelf_post", "board": "shelf_board", "crate": "crate"}, els, particle="board")
    # cabinet
    els = [box((0, 0, 2), (16, 16, 16), "side", north="front"),
           box((7, 6, 1), (8, 10, 2), "metal"), box((8, 6, 1), (9, 10, 2), "metal")]
    decor("storage_cabinet", {"front": "cabinet_front", "side": "cabinet_side", "metal": "metal_dark"}, els, particle="side")
    els = [box((0, 0, 2), (16, 16, 16), "side", north="front")]
    decor("parts_drawer_unit", {"front": "drawer_front", "side": "cabinet_side"}, els, particle="side")
    # pegboard with hanging tools
    els = [box((0, 0, 14), (16, 16, 16), "back", north="front"),
           box((3, 6, 12), (5, 13, 14), "red"), box((7, 3, 12), (8.5, 12, 14), "grey"), box((11, 7, 12), (13, 11, 14), "red")]
    decor("pegboard", {"front": "pegboard", "back": "metal_dark", "red": "tool_red", "grey": "tool_grey"}, els, particle="front")
    els = [box((0, 0, 14), (16, 16, 16), "back", north="front"), box((2, 0, 12), (14, 1, 14), "back")]
    decor("whiteboard", {"front": "whiteboard", "back": "metal_dark"}, els, particle="front")
    # air conditioner (wall mounted, back at +z)
    els = [box((0, 6, 8), (16, 14, 16), "body", north="front", down="body"),
           box((1, 5, 8), (15, 6, 14), "dark"), box((0, 14, 9), (16, 14.2, 15), "body")]
    decor("wall_air_conditioner", {"front": "ac_front", "body": "ac_body", "dark": "metal_dark"}, els, particle="body")
    els = [box((5, 5, 12), (11, 11, 16), "metal"), box((6, 6, 11), (10, 10, 12), "lamp")]
    decor("wall_light", {"metal": "metal_dark", "lamp": "light_panel"}, els, particle="metal")
    els = [box((0, 8, 4), (16, 12, 12), "metal", down="lamp"), box((7, 12, 7), (9, 16, 9), "metal")]
    decor("led_strip_light", {"metal": "metal_light", "lamp": "led_strip"}, els, particle="metal")
    els = [box((1, 0, 1), (15, 14, 15), "crate"), box((3, 14, 3), (13, 16, 13), "crate")]
    decor("parts_crates", {"crate": "crate"}, els)
    els = [box((4, 8, 4), (12, 10, 12), "seat"), box((7, 1, 7), (9, 8, 9), "metal"), box((5, 0, 5), (11, 1, 11), "metal")]
    decor("workshop_stool", {"seat": "stool_seat", "metal": "metal_light"}, els, particle="seat")
    els = [box((4, 0, 4), (12, 11, 12), "bin"), box((4, 11, 4), (12, 12, 12), "dark")]
    decor("trash_bin", {"bin": "bin", "dark": "bin_dark"}, els, particle="bin")
    els = [box((6, 2, 11), (10, 12, 15), "red"), box((7, 12, 12), (9, 14, 14), "metal"), box((6, 13, 12.5), (8, 14, 13.5), "metal")]
    decor("fire_extinguisher", {"red": "extinguisher", "metal": "metal_dark"}, els, particle="red")
    els = [box((3, 0, 4), (13, 5, 12), "red"), box((6, 5, 7), (10, 6, 9), "metal")]
    decor("toolbox", {"red": "toolbox", "metal": "metal_dark"}, els, particle="red")
    decor("antistatic_mat", {"mat": "mat"}, [box((0, 0, 0), (16, 1, 16), "mat")])

    # LED strip / wall equipment lights need no cull tweaks; keep models simple.


def build_case_blockstates(cases):
    for c in cases:
        name = c["id"]
        blockstate(name, facing_state(f"case_shape_{c['shape']}"))
        item_model(name, f"case_shape_{c['shape']}")


# ------------------------------------------------------------------ data
def loot(name):
    wj(f"{D}/loot_table/blocks/{name}.json", {
        "type": "minecraft:block",
        "pools": [{"rolls": 1.0, "bonus_rolls": 0.0,
                   "entries": [{"type": "minecraft:item", "name": f"{NS}:{name}"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})


HALL_BLOCKS = {
    "concrete_floor": "Concrete Floor", "floor_marking": "Floor Marking", "workshop_wall": "Workshop Wall",
    "ceiling_panel": "Ceiling Panel", "ceiling_light": "Ceiling Light", "steel_column": "Steel Column",
    "steel_beam": "Steel Beam", "led_strip_light": "LED Strip Light", "wall_light": "Wall Light",
    "wall_air_conditioner": "Wall-Mounted Air Conditioner", "building_table": "PC Building Table",
    "diagnostic_table": "Diagnostic Table", "metal_shelf": "Metal Shelf", "storage_cabinet": "Storage Cabinet",
    "parts_drawer_unit": "Parts Drawer Unit", "pegboard": "Pegboard", "parts_crates": "Parts Crates",
    "workshop_stool": "Workshop Stool", "trash_bin": "Trash Bin", "fire_extinguisher": "Fire Extinguisher",
    "whiteboard": "Whiteboard", "toolbox": "Toolbox", "antistatic_mat": "Anti-Static Mat"}

CASE_NAMES = {
    "case_standard": "Standard PC Case", "case_gaming": "Gaming PC Case", "case_full_tower": "Full Tower PC Case",
    "case_micro_atx": "Micro-ATX PC Case", "case_mini_itx": "Mini-ITX PC Case", "case_showcase": "Showcase PC Case",
    "case_open_bench": "Open-Air Test Bench", "case_mining": "Bitcoin Mining Case", "case_mining_rack": "Bitcoin Mining Rack"}


def main():
    cat = json.load(open(f"{D}/workshop/catalogue.json"))
    block_textures()
    item_textures(cat["coolers"])
    build_case_models()
    build_furniture()
    build_case_blockstates(cat["cases"])
    for n in list(HALL_BLOCKS) + [c["id"] for c in cat["cases"]]:
        loot(n)
    names = list(HALL_BLOCKS) + [c["id"] for c in cat["cases"]]
    wj(f"{D.replace('/pcsimulator','/minecraft')}/tags/block/mineable/pickaxe.json",
       {"replace": False, "values": [f"{NS}:{n}" for n in names]})

    # decoupling tags: other modules may not import this package, so they detect parts through tags
    tagdir = f"{D}/tags"
    wj(f"{tagdir}/block/pc_cases.json", {"replace": False, "values": [f"{NS}:{c['id']}" for c in cat["cases"]]})
    wj(f"{tagdir}/item/pc_cases.json", {"replace": False, "values": [f"{NS}:{c['id']}" for c in cat["cases"]]})
    wj(f"{tagdir}/item/pc_coolers.json", {"replace": False, "values": [f"{NS}:{c['id']}" for c in cat["coolers"]]})
    wj(f"{tagdir}/block/pc_build_surfaces.json", {"replace": False, "values": [f"{NS}:building_table", f"{NS}:diagnostic_table", f"{NS}:concrete_floor", f"{NS}:floor_marking", f"{NS}:antistatic_mat"]})
    wj(f"{tagdir}/block/workshop_tables.json", {"replace": False, "values": [f"{NS}:building_table", f"{NS}:diagnostic_table"]})

    lang = {}
    for n, t in HALL_BLOCKS.items():
        lang[f"block.{NS}.{n}"] = t
    for n, t in CASE_NAMES.items():
        lang[f"block.{NS}.{n}"] = t
    for c in cat["coolers"]:
        lang[f"item.{NS}.{c['id']}"] = c["name"]
    lang.update({
        "pcsimulator.workshop.type.case": "PC Case", "pcsimulator.workshop.type.cooler": "CPU Cooler",
        "pcsimulator.workshop.tier.entry": "Entry", "pcsimulator.workshop.tier.mid": "Mid",
        "pcsimulator.workshop.tier.high": "High", "pcsimulator.workshop.tier.enthusiast": "Enthusiast",
        "tooltip.pcsimulator.workshop.type": "%s - %s tier",
        "tooltip.pcsimulator.workshop.case_category": "Category: %s",
        "tooltip.pcsimulator.workshop.boards": "Motherboards: %s",
        "tooltip.pcsimulator.workshop.open_air": "Open-air: no enclosure limits",
        "tooltip.pcsimulator.workshop.provisional": "Provisional values",
        "tooltip.pcsimulator.workshop.unset": "Not set: %s",
        "tooltip.pcsimulator.workshop.cooler_kind": "Type: %s",
        "tooltip.pcsimulator.workshop.radiator": "Radiator: %s mm",
        "tooltip.pcsimulator.workshop.display.lcd": "LCD pump head",
        "tooltip.pcsimulator.workshop.display.infinity": "Infinity-mirror pump head",
        "tooltip.pcsimulator.workshop.rgb": "RGB lighting",
        "pcsimulator.workshop.case_category.standard": "Standard", "pcsimulator.workshop.case_category.gaming": "Gaming",
        "pcsimulator.workshop.case_category.full_tower": "Full Tower", "pcsimulator.workshop.case_category.micro_atx": "Micro-ATX",
        "pcsimulator.workshop.case_category.mini_itx": "Mini-ITX", "pcsimulator.workshop.case_category.showcase": "Showcase",
        "pcsimulator.workshop.case_category.open_bench": "Open-Air Test Bench",
        "pcsimulator.workshop.case_category.mining_case": "Mining Case", "pcsimulator.workshop.case_category.mining_rack": "Mining Rack",
        "pcsimulator.workshop.cooler_kind.air_standard": "Standard air cooler", "pcsimulator.workshop.cooler_kind.air_tower": "Tower air cooler",
        "pcsimulator.workshop.cooler_kind.air_dual_tower": "Dual-tower air cooler", "pcsimulator.workshop.cooler_kind.air_low_profile": "Low-profile air cooler",
        "pcsimulator.workshop.cooler_kind.aio_120": "120 mm AIO liquid cooler", "pcsimulator.workshop.cooler_kind.aio_240": "240 mm AIO liquid cooler",
        "pcsimulator.workshop.cooler_kind.aio_360": "360 mm AIO liquid cooler",
        "compat.pcsimulator.workshop.fits": "Compatible",
        "compat.pcsimulator.workshop.not_a_case": "Not a case", "compat.pcsimulator.workshop.not_a_cooler": "Not a cooler",
        "compat.pcsimulator.workshop.board_form_factor_unknown": "Motherboard form factor is not specified",
        "compat.pcsimulator.workshop.board_too_large": "Motherboard does not fit this case",
        "compat.pcsimulator.workshop.cpu_socket_unknown": "CPU socket is not specified",
        "compat.pcsimulator.workshop.cooler_sockets_unspecified": "Cooler socket support is not specified",
        "compat.pcsimulator.workshop.socket_mismatch": "Cooler does not support this CPU socket",
        "compat.pcsimulator.workshop.radiator_unspecified": "Radiator size is not specified",
        "compat.pcsimulator.workshop.case_radiator_unspecified": "Case radiator support is not specified",
        "compat.pcsimulator.workshop.radiator_unsupported": "Case cannot mount this radiator",
        "compat.pcsimulator.workshop.cooler_height_unspecified": "Cooler height is not specified",
        "compat.pcsimulator.workshop.case_height_unspecified": "Case cooler clearance is not specified",
        "compat.pcsimulator.workshop.cooler_too_tall": "Cooler is too tall for this case",
        "commands.pcsimulator.workshop.built": "Workshop hall built at %s %s %s",
        "commands.pcsimulator.workshop.not_built": "The workshop hall has not been built in this world",
        "commands.pcsimulator.workshop.info": "Workshop hall origin %s %s %s (%s x %s, ceiling %s)"})
    wj(f"{A}/lang/en_us.workshop.json", lang)
    print("assets generated:", len(names), "blocks,", len(cat["coolers"]), "coolers")


if __name__ == "__main__":
    main()
