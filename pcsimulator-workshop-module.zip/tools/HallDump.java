import com.pcsimulator.workshop.hall.*;
public class HallDump { public static void main(String[] a){ HallPlan.build().forEach((x,y,z,b,f)->System.out.println(x+","+y+","+z+","+b+","+f)); } }
