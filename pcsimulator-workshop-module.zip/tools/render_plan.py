#!/usr/bin/env python3
"""Renders the hall layout (from HallPlan via a CSV dump) as a top-down plan and two sections.
NOT in-game screenshots: a schematic of the generator's output.
Usage: java ... HallDump > cells.csv ; python3 tools/render_plan.py cells.csv docs/screenshots"""
import csv, sys
from PIL import Image, ImageDraw
rows = list(csv.reader(open(sys.argv[1])))
out = sys.argv[2]
cells = {(int(x), int(y), int(z)): b for x, y, z, b, f in rows}
COL = {"FLOOR": (128, 128, 130), "FLOOR_MARKING": (232, 190, 30), "WALL": (156, 158, 162), "GLASS": (140, 200, 235),
       "COLUMN": (80, 84, 92), "BUILDING_TABLE": (40, 90, 64), "DIAGNOSTIC_TABLE": (40, 70, 140), "SHELF": (46, 90, 160),
       "CABINET": (180, 184, 190), "PARTS_DRAWER": (160, 164, 170), "PEGBOARD": (196, 170, 120), "CRATES": (50, 100, 170),
       "STOOL": (30, 32, 38), "TRASH_BIN": (90, 94, 102), "EXTINGUISHER": (200, 40, 36), "WHITEBOARD": (240, 240, 240),
       "TOOLBOX": (200, 56, 40), "ANTISTATIC_MAT": (24, 24, 28), "AC_UNIT": (236, 238, 240), "WALL_LIGHT": (255, 240, 150),
       "LED_STRIP": (255, 255, 200), "CEILING_LIGHT": (255, 255, 230), "CEILING_PANEL": (226, 228, 230), "SKYLIGHT": (170, 220, 250),
       "BEAM_Z": (74, 78, 86), "CHAIN": (60, 60, 60), "FOUNDATION": (100, 100, 100)}
S = 14
W, D, H = 48, 32, 12
# plan: top-down view with ceiling removed (what a visitor sees looking down into the hall)
im = Image.new("RGB", ((W + 2 + 0) * S, (D + 2 + 6) * S), (60, 120, 60))
d = ImageDraw.Draw(im)
for z in range(-1, D + 6):
    for x in range(-1, W + 1):
        col = None
        for y in range(H - 1, -2, -1):
            b = cells.get((x, y, z))
            if b in (None, "AIR", "CHAIN", "LED_STRIP", "CEILING_LIGHT", "CEILING_PANEL", "SKYLIGHT", "BEAM_Z") and y >= 3:
                continue
            if b in (None, "AIR"):
                continue
            col = COL.get(b, (255, 0, 255)); break
        if col:
            d.rectangle([(x + 1) * S, (z + 1) * S, (x + 2) * S - 1, (z + 2) * S - 1], fill=col)
im.save(f"{out}/hall_plan_topdown.png")
# section along x at z=7 (through a building table row) and along z at x=29
def section(fixed_axis, val, name):
    n = W if fixed_axis == "z" else D
    sec = Image.new("RGB", ((n + 2) * S, (H + 4) * S), (200, 220, 240))
    sd = ImageDraw.Draw(sec)
    for u in range(-1, n + 1):
        for y in range(-3, H + 1):
            b = cells.get((u, y, val) if fixed_axis == "z" else (val, y, u))
            if b in (None, "AIR"): continue
            sd.rectangle([(u + 1) * S, (H - y) * S, (u + 2) * S - 1, (H - y + 1) * S - 1], fill=COL.get(b, (255, 0, 255)))
    sec.save(f"{out}/{name}.png")
section("z", 7, "hall_section_x_through_tables")
section("x", 29, "hall_section_z_through_diagnostics")
print("rendered")
