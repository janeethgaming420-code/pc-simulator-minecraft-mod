#!/usr/bin/env python3
"""Static consistency checks (a substitute for a compiler run in sandboxes without Gradle):
 - every block registered in Java has blockstate, models, item model, loot table, lang name; and vice versa
 - every model/texture/parent reference resolves; every JSON parses
 - Java shape tables (CaseShape/DecorShape) equal the generator's tables
 - catalogue ids/shapes are valid
Run:  python3 tools/validate.py   (exit code 1 on failure)"""
import glob, json, os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
RES = f"{ROOT}/src/main/resources"; A = f"{RES}/assets/pcsimulator"; D = f"{RES}/data/pcsimulator"
J = f"{ROOT}/src/main/java/com/pcsimulator/workshop"
errs = []
def err(m): errs.append(m)
def load(p):
    try: return json.load(open(p))
    except Exception as e: err(f"bad json {p}: {e}"); return {}
for p in glob.glob(f"{RES}/**/*.json", recursive=True): load(p)

blocks_java = re.findall(r'(?:reg|decor)\("([a-z0-9_]+)"', open(f"{J}/furniture/WorkshopBlocks.java").read())
cat = load(f"{D}/workshop/catalogue.json")
case_ids = [c["id"] for c in cat["cases"]]
lang = load(f"{A}/lang/en_us.workshop.json")
all_blocks = blocks_java + case_ids
if len(set(all_blocks)) != len(all_blocks): err("duplicate block ids")
for b in all_blocks:
    for p in (f"{A}/blockstates/{b}.json", f"{A}/models/item/{b}.json", f"{D}/loot_table/blocks/{b}.json"):
        if not os.path.exists(p): err(f"missing {os.path.relpath(p, ROOT)}")
    if f"block.pcsimulator.{b}" not in lang: err(f"missing lang block.pcsimulator.{b}")
for c in cat["coolers"]:
    if not os.path.exists(f"{A}/models/item/{c['id']}.json"): err(f"missing item model {c['id']}")
    if not os.path.exists(f"{A}/textures/item/{c['id']}.png"): err(f"missing item texture {c['id']}")
    if f"item.pcsimulator.{c['id']}" not in lang: err(f"missing lang for {c['id']}")
tag = load(f"{RES}/data/minecraft/tags/block/mineable/pickaxe.json")["values"]
for b in all_blocks:
    if f"pcsimulator:{b}" not in tag: err(f"{b} not in pickaxe tag")

def model_path(ref):
    ns, _, n = ref.partition(":")
    return f"{A}/models/{n}.json" if ns == "pcsimulator" else None
def tex_path(ref):
    ns, _, n = ref.partition(":")
    return f"{A}/textures/{n}.png" if ns == "pcsimulator" else None
for p in glob.glob(f"{A}/models/**/*.json", recursive=True):
    m = load(p)
    par = m.get("parent", "")
    if par.startswith("pcsimulator:") and not os.path.exists(model_path(par)): err(f"{p}: parent {par} missing")
    for k, v in m.get("textures", {}).items():
        if v.startswith("pcsimulator:") and not os.path.exists(tex_path(v)): err(f"{p}: texture {v} missing")
        if v.startswith("#"): err(f"{p}: unresolved alias {v}")
    keys = set(m.get("textures", {}))
    for e in m.get("elements", []):
        for f in e["faces"].values():
            k = f["texture"].lstrip("#")
            if k not in keys: err(f"{p}: face uses undefined texture key {k}")
for p in glob.glob(f"{A}/blockstates/*.json"):
    s = load(p)
    refs = []
    for v in s.get("variants", {}).values(): refs.append(v["model"])
    for part in s.get("multipart", []): refs.append(part["apply"]["model"])
    for r in refs:
        if not os.path.exists(model_path(r)): err(f"{p}: model {r} missing")

# shape tables Java vs python
gen = open(f"{ROOT}/tools/gen_assets.py").read()
py_cases = eval(re.search(r"CASE_SHAPES = (\{.*?\n\})", gen, re.S).group(1).replace("# must match CaseShape.java", ""))
java_cases = {m[0].lower(): tuple(int(x) for x in m[1].split(",")) for m in re.findall(r"([A-Z_]+)\(([\d, ]+)\)", open(f"{J}/cases/CaseShape.java").read())}
if {k: tuple(v) for k, v in py_cases.items()} != java_cases: err(f"CaseShape mismatch: {py_cases} vs {java_cases}")
for c in cat["cases"]:
    if c["shape"] not in java_cases: err(f"case {c['id']} unknown shape {c['shape']}")
# decor shapes: java vs hand-copied expectations in gen_assets box() calls are visual; just ensure enum names exist
ds = re.findall(r"^\s+([A-Z_]+)\(", open(f"{J}/furniture/DecorShape.java").read(), re.M)
print("decor shapes:", len(ds), "| blocks:", len(all_blocks), "| coolers:", len(cat["coolers"]))
# every HallBlock maps in HallPlacer
hb = re.search(r"enum HallBlock \{(.*?)\n\n", open(f"{J}/hall/HallBlock.java").read(), re.S).group(1)
names = re.findall(r"[A-Z_]{3,}", hb.split(";")[0])
placer = open(f"{J}/hall/HallPlacer.java").read()
for n in names:
    if f"case {n}" not in placer and f", {n}" not in placer and f"{n}," not in placer.split("toState")[1]: err(f"HallPlacer does not map {n}")
print("FAIL" if errs else "OK")
for e in errs[:40]: print(" -", e)
sys.exit(1 if errs else 0)
