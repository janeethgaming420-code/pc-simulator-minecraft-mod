#!/usr/bin/env python3
"""Merges every assets/pcsimulator/lang/en_us.<fragment>.json into en_us.json (Claude 7 integration step).
Minecraft only loads en_us.json, so fragments (hardware, workshop, ...) must be merged. Duplicate keys with
different values abort the merge. Usage: python3 tools/merge_lang.py [--write]"""
import glob, json, os, sys
d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../src/main/resources/assets/pcsimulator/lang")
base_p = f"{d}/en_us.json"
base = json.load(open(base_p))
merged = dict(base)
for frag in sorted(glob.glob(f"{d}/en_us.*.json")):
    for k, v in json.load(open(frag)).items():
        if k in merged and merged[k] != v:
            sys.exit(f"conflict on {k!r} in {os.path.basename(frag)}")
        merged[k] = v
print(f"{len(base)} -> {len(merged)} keys")
if "--write" in sys.argv:
    json.dump(merged, open(base_p, "w"), indent=2, ensure_ascii=False)
    open(base_p, "a").write("\n")
    print("written", base_p)
