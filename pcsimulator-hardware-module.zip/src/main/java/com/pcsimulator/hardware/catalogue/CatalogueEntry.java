package com.pcsimulator.hardware.catalogue;

import com.pcsimulator.hardware.component.HardwareDefinition;

/** One parsed catalogue row: registry/item name plus its definition. */
public record CatalogueEntry(String name, HardwareDefinition definition) {}
