package com.pcsimulator.hardware.catalogue;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.pcsimulator.api.hardware.ComponentTier;
import com.pcsimulator.api.hardware.ComponentType;
import com.pcsimulator.hardware.Connectors;
import com.pcsimulator.hardware.component.ConnectorPool;
import com.pcsimulator.hardware.component.HardwareDefinition;
import com.pcsimulator.hardware.component.HardwareMeta;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Loads the hardware catalogue. Sources, later overrides earlier (replace by {@code id}):
 * <ol>
 *   <li>classpath {@value #BUNDLED}</li>
 *   <li>optional {@code <config>/pcsimulator/hardware-catalogue.json} (same schema)</li>
 * </ol>
 * Runs once during the mod constructor (items must be registered then), so it cannot use datapacks.
 * Client and server MUST use the same ids (registry sync); values should match too.
 * Missing numeric fields are NOT guessed: they become 0 and are reported via
 * {@link HardwareDefinition#unsetFields()}. Any malformed entry fails startup with the entry id in the message.
 */
public final class CatalogueLoader {
    private CatalogueLoader() {}

    public static final String BUNDLED = "/data/pcsimulator/hardware/catalogue.json";
    private static final Pattern NAME = Pattern.compile("[a-z0-9_]+");

    public static List<CatalogueEntry> load() {
        Map<String, JsonObject> merged = new LinkedHashMap<>();
        try (InputStream in = CatalogueLoader.class.getResourceAsStream(BUNDLED)) {
            if (in == null) throw new IllegalStateException("Bundled hardware catalogue missing: " + BUNDLED);
            readInto(merged, new InputStreamReader(in, StandardCharsets.UTF_8), BUNDLED);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read bundled hardware catalogue", e);
        }
        Path override = FMLPaths.CONFIGDIR.get().resolve("pcsimulator").resolve("hardware-catalogue.json");
        if (Files.isRegularFile(override)) {
            try (Reader r = Files.newBufferedReader(override, StandardCharsets.UTF_8)) {
                readInto(merged, r, override.toString());
            } catch (IOException e) {
                throw new IllegalStateException("Cannot read " + override, e);
            }
        }
        List<CatalogueEntry> out = new ArrayList<>();
        merged.forEach((name, obj) -> out.add(new CatalogueEntry(name, parse(name, obj))));
        return out;
    }

    private static void readInto(Map<String, JsonObject> target, Reader reader, String source) {
        JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
        if (!root.has("entries")) throw new IllegalStateException(source + ": missing 'entries'");
        for (JsonElement e : root.getAsJsonArray("entries")) {
            JsonObject o = e.getAsJsonObject();
            if (!o.has("id")) throw new IllegalStateException(source + ": entry without 'id'");
            String id = o.get("id").getAsString();
            if (!NAME.matcher(id).matches()) throw new IllegalStateException(source + ": bad id '" + id + "'");
            target.put(id, o);
        }
    }

    private static HardwareDefinition parse(String name, JsonObject o) {
        try {
            ComponentType type = enumOf(ComponentType.values(), req(o, "type"));
            ComponentTier tier = enumOf(ComponentTier.values(), req(o, "tier"));
            boolean psu = type == ComponentType.PSU;
            Set<String> unset = new LinkedHashSet<>();
            long price = num(o, "basePriceCents", true, unset);
            int draw = (int) num(o, "powerDrawWatts", !psu, unset);
            int output = (int) num(o, "powerOutputWatts", psu, unset);
            int score = (int) num(o, "performanceScore", true, unset);
            ResourceLocation connector = o.has("connector") ? rl(o.get("connector").getAsString()) : null;
            Set<ResourceLocation> accepted = new LinkedHashSet<>();
            if (o.has("acceptedConnectors"))
                for (JsonElement c : o.getAsJsonArray("acceptedConnectors")) accepted.add(rl(c.getAsString()));

            if (type == ComponentType.STORAGE && (connector == null || !Connectors.STORAGE.contains(connector)))
                throw new IllegalStateException("STORAGE needs connector in " + Connectors.STORAGE);

            Map<String, String> attrs = new LinkedHashMap<>();
            if (o.has("attributes"))
                o.getAsJsonObject("attributes").entrySet().forEach(en -> attrs.put(en.getKey(), en.getValue().getAsString()));
            HardwareMeta meta = new HardwareMeta(pools(o, "slots"), pools(o, "supplies"), pools(o, "requires"), attrs);
            boolean provisional = o.has("provisional") && o.get("provisional").getAsBoolean();
            return new HardwareDefinition(type, tier, price, draw, output, score, connector, accepted, meta, provisional, unset);
        } catch (RuntimeException e) {
            throw new IllegalStateException("Hardware catalogue entry '" + name + "': " + e.getMessage(), e);
        }
    }

    private static List<ConnectorPool> pools(JsonObject o, String key) {
        List<ConnectorPool> list = new ArrayList<>();
        if (!o.has(key)) return list;
        JsonArray arr = o.getAsJsonArray(key);
        for (JsonElement e : arr) {
            JsonObject p = e.getAsJsonObject();
            Set<ResourceLocation> cs = new LinkedHashSet<>();
            for (JsonElement c : p.getAsJsonArray("accepts")) cs.add(rl(c.getAsString()));
            list.add(new ConnectorPool(cs, p.get("count").getAsInt()));
        }
        return list;
    }

    private static long num(JsonObject o, String key, boolean track, Set<String> unset) {
        if (o.has(key)) {
            long v = o.get(key).getAsLong();
            if (v < 0) throw new IllegalStateException(key + " must be >= 0");
            return v;
        }
        if (track) unset.add(key);
        return 0L;
    }

    private static String req(JsonObject o, String key) {
        if (!o.has(key)) throw new IllegalStateException("missing '" + key + "'");
        return o.get(key).getAsString();
    }

    private static ResourceLocation rl(String s) {
        ResourceLocation r = ResourceLocation.tryParse(s);
        if (r == null) throw new IllegalStateException("invalid resource location '" + s + "'");
        return r;
    }

    private static <E extends Enum<E>> E enumOf(E[] values, String s) {
        for (E v : values) if (v.name().equalsIgnoreCase(s)) return v;
        throw new IllegalStateException("unknown value '" + s + "'");
    }
}
