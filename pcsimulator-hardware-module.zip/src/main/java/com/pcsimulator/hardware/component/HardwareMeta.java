package com.pcsimulator.hardware.component;

import java.util.List;
import java.util.Map;

/**
 * Hardware-module metadata that the core API cannot express.
 * <ul>
 *   <li>{@code slots}    - what this part PROVIDES (motherboard RAM slots, M.2 slots, SATA ports, GPU/NIC slots)</li>
 *   <li>{@code supplies} - what this part SUPPLIES (PSU connector types and counts)</li>
 *   <li>{@code requires} - what this part NEEDS (e.g. a GPU's power connectors)</li>
 *   <li>{@code attributes} - free-form catalogue values (capacity, form factor, network kind ...)</li>
 * </ul>
 * An empty list means "not specified / none", see {@link HardwareDefinition#unsetFields()}.
 */
public record HardwareMeta(List<ConnectorPool> slots, List<ConnectorPool> supplies, List<ConnectorPool> requires,
                           Map<String, String> attributes) {
    public static final HardwareMeta EMPTY = new HardwareMeta(List.of(), List.of(), List.of(), Map.of());

    public HardwareMeta {
        slots = List.copyOf(slots);
        supplies = List.copyOf(supplies);
        requires = List.copyOf(requires);
        attributes = Map.copyOf(attributes);
    }
}
