package com.pcsimulator.hardware.component;

import com.pcsimulator.api.hardware.ComponentTier;
import com.pcsimulator.api.hardware.ComponentType;
import com.pcsimulator.api.hardware.IHardwareComponent;
import net.minecraft.resources.ResourceLocation;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/** Immutable hardware model: the core {@link IHardwareComponent} contract plus {@link HardwareMeta}. */
public final class HardwareDefinition implements IHardwareComponent {
    private final ComponentType type;
    private final ComponentTier tier;
    private final long basePriceCents;
    private final int powerDrawWatts;
    private final int powerOutputWatts;
    private final int performanceScore;
    private final ResourceLocation connector;
    private final Set<ResourceLocation> accepted;
    private final HardwareMeta meta;
    private final boolean provisional;
    private final Set<String> unsetFields;

    public HardwareDefinition(ComponentType type, ComponentTier tier, long basePriceCents, int powerDrawWatts,
                              int powerOutputWatts, int performanceScore, ResourceLocation connector,
                              Set<ResourceLocation> explicitAccepted, HardwareMeta meta, boolean provisional,
                              Set<String> unsetFields) {
        this.type = type;
        this.tier = tier;
        this.basePriceCents = basePriceCents;
        this.powerDrawWatts = powerDrawWatts;
        this.powerOutputWatts = powerOutputWatts;
        this.performanceScore = performanceScore;
        this.connector = connector;
        Set<ResourceLocation> all = new HashSet<>(explicitAccepted);
        meta.slots().forEach(p -> all.addAll(p.connectors()));
        this.accepted = Set.copyOf(all);
        this.meta = meta;
        this.provisional = provisional;
        this.unsetFields = Set.copyOf(unsetFields);
    }

    @Override public ComponentType type() { return type; }
    @Override public ComponentTier tier() { return tier; }
    @Override public long basePriceCents() { return basePriceCents; }
    @Override public int powerDrawWatts() { return powerDrawWatts; }
    @Override public int powerOutputWatts() { return powerOutputWatts; }
    @Override public int performanceScore() { return performanceScore; }
    @Override public Optional<ResourceLocation> connector() { return Optional.ofNullable(connector); }
    /** Explicitly listed connectors plus every connector of {@link HardwareMeta#slots()}. */
    @Override public Set<ResourceLocation> acceptedConnectors() { return accepted; }

    public HardwareMeta meta() { return meta; }
    /** True while the entry is a placeholder awaiting the agreed catalogue values. */
    public boolean provisional() { return provisional; }
    /** Names of numeric fields the catalogue did not provide (their value above is 0 = "not set", not "free"). */
    public Set<String> unsetFields() { return unsetFields; }
}
