package com.pcsimulator.hardware.component;

import net.minecraft.resources.ResourceLocation;

import java.util.Set;

/**
 * "{@code count} physical connections, each accepting ANY of {@code connectors}".
 * A shared M.2 slot that takes NVMe or M.2 SATA drives is ONE pool with two connector ids (no double counting).
 */
public record ConnectorPool(Set<ResourceLocation> connectors, int count) {
    public ConnectorPool {
        if (connectors.isEmpty()) throw new IllegalArgumentException("ConnectorPool needs at least one connector");
        if (count < 1) throw new IllegalArgumentException("ConnectorPool count must be >= 1");
        connectors = Set.copyOf(connectors);
    }
}
