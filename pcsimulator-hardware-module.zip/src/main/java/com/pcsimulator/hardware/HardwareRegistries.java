package com.pcsimulator.hardware;

import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.core.registry.CoreCreativeTab;
import com.pcsimulator.core.registry.CoreRegistries;
import com.pcsimulator.hardware.catalogue.CatalogueEntry;
import com.pcsimulator.hardware.catalogue.CatalogueLoader;
import com.pcsimulator.hardware.item.HardwareItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Registers every catalogue entry as (a) an {@code IHardwareComponent} in the core's custom registry and
 * (b) an item, using ONLY the core's shared DeferredRegisters. No DeferredRegister is created here.
 */
public final class HardwareRegistries {
    private HardwareRegistries() {}

    private static final Map<String, DeferredItem<HardwareItem>> ITEMS = new LinkedHashMap<>();
    private static boolean initialised;

    /** Idempotent. Must run from {@code PCModule#register} (before RegisterEvent). */
    public static synchronized void init() {
        if (initialised) return;
        initialised = true;
        for (CatalogueEntry entry : CatalogueLoader.load()) {
            ResourceLocation id = PCSimulatorAPI.id(entry.name());
            CoreRegistries.HARDWARE_COMPONENTS.register(entry.name(), () -> entry.definition());
            DeferredItem<HardwareItem> item = CoreRegistries.ITEMS.registerItem(entry.name(),
                    props -> new HardwareItem(props, id), new Item.Properties().stacksTo(1));
            ITEMS.put(entry.name(), item);
            CoreCreativeTab.add(item);
        }
    }

    public static Map<String, DeferredItem<HardwareItem>> items() {
        return Collections.unmodifiableMap(ITEMS);
    }
}
