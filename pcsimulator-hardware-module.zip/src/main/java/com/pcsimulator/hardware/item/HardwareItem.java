package com.pcsimulator.hardware.item;

import com.pcsimulator.api.PCRegistries;
import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.api.hardware.IHardwareItem;
import com.pcsimulator.core.registry.CoreDataComponents;
import com.pcsimulator.hardware.component.HardwareDefinition;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Item representing one hardware model. Identity = {@code HARDWARE_ID} data component (defaults to this item's own model). */
public class HardwareItem extends Item implements IHardwareItem {
    private final ResourceLocation defaultComponentId;

    public HardwareItem(Properties properties, ResourceLocation defaultComponentId) {
        super(properties);
        this.defaultComponentId = defaultComponentId;
    }

    @Override
    public ItemStack getDefaultInstance() {
        ItemStack stack = super.getDefaultInstance();
        stack.set(CoreDataComponents.HARDWARE_ID.get(), defaultComponentId);
        return stack;
    }

    @Nullable
    @Override
    public IHardwareComponent getComponent(ItemStack stack) {
        ResourceLocation id = stack.getOrDefault(CoreDataComponents.HARDWARE_ID.get(), defaultComponentId);
        return PCRegistries.HARDWARE_COMPONENTS.get(id);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        IHardwareComponent c = getComponent(stack);
        if (c == null) return;
        lines.add(Component.translatable("tooltip.pcsimulator.hardware.type",
                Component.translatable("pcsimulator.hardware.type." + c.type().getSerializedName()),
                Component.translatable("pcsimulator.hardware.tier." + c.tier().getSerializedName())).withStyle(ChatFormatting.GRAY));
        if (c instanceof HardwareDefinition d) {
            if (d.provisional())
                lines.add(Component.translatable("tooltip.pcsimulator.hardware.provisional").withStyle(ChatFormatting.YELLOW));
            if (!d.unsetFields().isEmpty())
                lines.add(Component.translatable("tooltip.pcsimulator.hardware.unset", String.join(", ", d.unsetFields())).withStyle(ChatFormatting.DARK_GRAY));
            d.meta().attributes().forEach((k, v) ->
                    lines.add(Component.translatable("tooltip.pcsimulator.hardware.attribute", k, v).withStyle(ChatFormatting.GRAY)));
        }
        if (c.powerDrawWatts() > 0)
            lines.add(Component.translatable("tooltip.pcsimulator.hardware.power_draw", c.powerDrawWatts()).withStyle(ChatFormatting.GRAY));
        if (c.powerOutputWatts() > 0)
            lines.add(Component.translatable("tooltip.pcsimulator.hardware.power_output", c.powerOutputWatts()).withStyle(ChatFormatting.GRAY));
    }
}
