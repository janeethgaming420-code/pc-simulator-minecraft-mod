package com.pcsimulator.hardware;

import com.pcsimulator.core.module.ModuleIds;
import com.pcsimulator.core.module.PCModule;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;

/** Physical hardware module. Claude 7 adds {@code new com.pcsimulator.hardware.HardwareModule()} to ModuleList. */
public final class HardwareModule implements PCModule {
    @Override
    public String id() {
        return ModuleIds.HARDWARE;
    }

    @Override
    public void register(IEventBus modBus, ModContainer container, Dist dist) {
        HardwareRegistries.init();
    }
}
