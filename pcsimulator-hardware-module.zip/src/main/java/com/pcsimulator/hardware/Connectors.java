package com.pcsimulator.hardware;

import com.pcsimulator.api.PCSimulatorAPI;
import net.minecraft.resources.ResourceLocation;

import java.util.Set;

/**
 * Stable connector ids fixed by the agreed design. These are the only connector ids hard-coded in Java.
 * <p>All other connector ids (CPU sockets, memory generations, GPU interfaces, network interfaces, PSU
 * connector types) come from the catalogue data, because their agreed names were not available to the
 * implementer. Once a connector id ships it must never be renamed (it is stored in worlds).
 * <p>Storage connector = DATA INTERFACE. Physical form factor (2.5in / 3.5in / m2) is the catalogue attribute
 * {@code formFactor}, so a case can offer bays without the core API distinguishing them.
 */
public final class Connectors {
    private Connectors() {}

    public static final ResourceLocation STORAGE_SATA = PCSimulatorAPI.id("connector/storage/sata");
    public static final ResourceLocation STORAGE_M2_NVME = PCSimulatorAPI.id("connector/storage/m2_nvme");
    public static final ResourceLocation STORAGE_M2_SATA = PCSimulatorAPI.id("connector/storage/m2_sata");

    public static final Set<ResourceLocation> STORAGE = Set.of(STORAGE_SATA, STORAGE_M2_NVME, STORAGE_M2_SATA);

    /** Catalogue attribute key holding the physical form factor of a part. */
    public static final String ATTR_FORM_FACTOR = "formFactor";
}
