# Hardware module (`com.pcsimulator.hardware`) - Claude 2

Status: source complete against the supplied core APIs. **NOT compiled, NOT run** (no network / no javac in the authoring sandbox).

## Integration
* Entry: `HardwareModule implements PCModule` (id `hardware`, no dependencies). Claude 7 adds ONE line to `ModuleList`:
  `new com.pcsimulator.hardware.HardwareModule()`   (ModuleList was NOT edited.)
* Uses only core shared registers: `CoreRegistries.HARDWARE_COMPONENTS`, `CoreRegistries.ITEMS`, `CoreCreativeTab.add`, `CoreDataComponents.HARDWARE_ID`.
* Items implement `IHardwareItem`; identity = `HARDWARE_ID` component (defaults to the item's own model via `getDefaultInstance`).
* Lang: `assets/pcsimulator/lang/en_us.hardware.json` is a FRAGMENT. Minecraft only loads `en_us.json`, so Claude 7 must merge it
  (per ARCHITECTURE s11.6) or item names show as raw keys.
* Textures are generated placeholder art (colour-coded 16x16).

## Catalogue (data-driven)
`data/pcsimulator/hardware/catalogue.json`, optional override/extension `config/pcsimulator/hardware-catalogue.json`
(same schema, replace-by-id). Loaded once in the mod constructor; client and server must use identical ids.

Entry: `id`, `type` (ComponentType), `tier` (ComponentTier), `provisional`, `basePriceCents`, `powerDrawWatts`,
`powerOutputWatts` (PSU), `performanceScore`, `connector`, `acceptedConnectors[]`,
`slots[]` / `supplies[]` / `requires[]` = `{ "accepts": [connector ids], "count": n }`, `attributes{}` (capacity, formFactor, ...).
Missing numeric fields are **not guessed**: they load as 0 and are listed in the tooltip as "Not set".

### Implemented now: one PROVISIONAL placeholder per family (11 items)
motherboard, cpu, gpu, ram, 2.5" SATA SSD, M.2 NVMe SSD, M.2 SATA SSD, 3.5" HDD, PSU, Ethernet NIC, Wi-Fi card.
All are tier `entry` (the core API requires a tier), have no price/power/score/capacity/slot counts, and carry connector ids only.
**The agreed capacity lists and exact models were not available to the implementer; none were invented.**
Replace/add rows in the JSON (rename `*_provisional` ids before release; ids are persisted in worlds).

### Connector ids
Fixed in code (`Connectors`): `pcsimulator:connector/storage/sata`, `.../storage/m2_nvme`, `.../storage/m2_sata`.
Storage connector = data interface; form factor (`2.5_inch`, `3.5_inch`, `m2`) is attribute `formFactor`.
Provisional placeholders (agreed names pending): `connector/cpu_socket/provisional`, `connector/memory/provisional`,
`connector/gpu_interface/provisional`, `connector/network_interface/provisional`.
Assumption to confirm: NICs/Wi-Fi cards use the generic network interface connector.

## Core API limitations (not worked around in core)
1. **Cross-module metadata access.** Slot counts / PSU connectors live in `HardwareDefinition.meta()`, but ARCHITECTURE s1 forbids
   pcbuild importing `com.pcsimulator.hardware`, and `IHardwareComponent` has no accessor for it. pcbuild currently cannot read
   slot counts. Options: (a) add `default Object/IHardwareMeta metadata()` to the api, (b) pcbuild parses the catalogue JSON, (c) pcbuild asks for an api capability.
2. Shared M.2 slots are modelled as one `ConnectorPool` accepting two connectors; `acceptedConnectors()` flattens this and loses counts.
3. `connector()` is single-valued; hence the data-interface + `formFactor` split for storage.
4. 0 price/score/power means "unset", not "free"; economy/pcbuild should treat `provisional()` parts as unpriced/unbootable.
5. Core `CoreCreativeTab` icon is a placeholder (cosmetic).

## Build
`./gradlew build` (Java 21, needs network for first run). Quick check: `./gradlew compileJava`.
