package com.pcsimulator.vpc.server;

import com.pcsimulator.api.build.BootResult;
import com.pcsimulator.api.build.IPCBuild;
import com.pcsimulator.api.build.PCCapabilities;
import com.pcsimulator.api.build.PCState;
import com.pcsimulator.core.network.PCNetwork;
import com.pcsimulator.vpc.VpcApi;
import com.pcsimulator.vpc.VpcConfig;
import com.pcsimulator.vpc.api.INetworkEnvironment;
import com.pcsimulator.vpc.network.VpcActionPayload;
import com.pcsimulator.vpc.network.VpcSnapshotPayload;
import com.pcsimulator.vpc.sim.AppId;
import com.pcsimulator.vpc.sim.NetworkModel;
import com.pcsimulator.vpc.sim.NetworkStatus;
import com.pcsimulator.vpc.sim.OsType;
import com.pcsimulator.vpc.sim.PerformanceModel;
import com.pcsimulator.vpc.sim.PowerState;
import com.pcsimulator.vpc.sim.Tuning;
import com.pcsimulator.vpc.sim.VirtualPcSession;
import com.pcsimulator.vpc.sim.VirtualPerformance;
import com.pcsimulator.vpc.sim.VpcSnapshot;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Server-side controller. Cost model: with no player looking at a virtual PC this class does NOTHING per tick
 * (the viewer map is empty). Sessions are caught up lazily from absolute game-tick timestamps when somebody
 * touches them. With viewers, one check every 10 ticks per viewer and a re-validation of the physical build every
 * 20 ticks; snapshots are sent only when the session version changed.
 */
public final class VpcManager {
    private VpcManager() {}

    private static final class Viewer {
        final UUID buildId;
        final ResourceKey<Level> dim;
        final BlockPos pos;
        int sentVersion = -1;
        Viewer(UUID buildId, ResourceKey<Level> dim, BlockPos pos) { this.buildId = buildId; this.dim = dim; this.pos = pos; }
    }

    private static final Map<UUID, Viewer> VIEWERS = new HashMap<>();

    /** Everything derived from the build for one operation. */
    private record Ctx(ServerLevel level, BlockPos pos, IPCBuild build, VirtualPcSession session, Tuning tuning,
                       BuildProfiler.Profiled hw, VirtualPerformance perf, NetworkStatus net, long now) {}

    // ---- public entry points ----------------------------------------------------------------------------
    public static void open(ServerPlayer player, Level level, BlockPos pos, IPCBuild build) {
        if (!(level instanceof ServerLevel sl)) return;
        Viewer v = new Viewer(build.buildId(), sl.dimension(), pos.immutable());
        VIEWERS.put(player.getUUID(), v);
        Ctx c = context(sl, pos, build);
        guardPhysical(c);
        push(player, v, c, true);
    }

    /**
     * Block-interaction power toggle (used by {@link VpcInteractions}). Same validation path as the on-screen
     * button, but it does not register the player as a screen viewer and only reports what actually happened.
     */
    public static void togglePower(ServerPlayer player, Level level, BlockPos pos, IPCBuild build) {
        if (!(level instanceof ServerLevel sl)) return;
        Ctx c = context(sl, pos, build);
        guardPhysical(c);
        VirtualPcSession.Persisted before = c.session().persisted();
        PowerState was = c.session().power();
        if (was == PowerState.OFF) {
            powerOn(player, c);
            if (c.session().power() == PowerState.BOOTING) msg(player, "pcsimulator.vpc.msg.starting");
        } else if (was == PowerState.BOOTING || was == PowerState.RUNNING) {
            c.session().shutdown(c.now(), c.perf(), c.tuning());
            msg(player, "pcsimulator.vpc.msg.shutting_down");
        } // SHUTTING_DOWN: nothing to do
        c.session().advance(c.now(), c.net());
        persistIfChanged(sl, before, c.session());
        Viewer v = VIEWERS.get(player.getUUID());
        if (v != null && v.pos.equals(pos) && v.buildId.equals(build.buildId())) push(player, v, c, false);
    }

    public static PowerState powerState(MinecraftServer server, UUID buildId) {
        VpcSavedData data = VpcSavedData.get(server);
        VirtualPcSession s = data.peek(buildId);
        if (s == null) return PowerState.OFF;
        // Sessions are caught up lazily; settle a finished boot/shutdown so callers never see a stale phase.
        if (s.settlePhase(server.overworld().getGameTime())) data.touch();
        return s.power();
    }

    public static void revalidate(MinecraftServer server, IPCBuild build) {
        VirtualPcSession s = VpcSavedData.get(server).peek(build.buildId());
        if (s == null || !s.isActive()) return;
        if (!bootable(build)) {
            s.forceOff("pcsimulator.vpc.notice.hardware_fault");
            VpcSavedData.get(server).touch();
        }
    }

    public static void handleAction(ServerPlayer player, VpcActionPayload a) {
        if (a.action() == VpcActionPayload.Action.CLOSE_SCREEN) {
            VIEWERS.remove(player.getUUID());
            return;
        }
        ServerLevel level = player.serverLevel();
        double range = VpcConfig.COMMON.range();
        if (player.distanceToSqr(Vec3.atCenterOf(a.pos())) > range * range) return;
        IPCBuild build = level.getCapability(PCCapabilities.PC_BUILD, a.pos());
        if (build == null) {
            VIEWERS.remove(player.getUUID());
            return;
        }
        Viewer v = VIEWERS.get(player.getUUID());
        if (v == null || !v.pos.equals(a.pos()) || !v.buildId.equals(build.buildId())) {
            v = new Viewer(build.buildId(), level.dimension(), a.pos().immutable());
            VIEWERS.put(player.getUUID(), v);
        }
        Ctx c = context(level, a.pos(), build);
        guardPhysical(c);
        VirtualPcSession.Persisted before = c.session().persisted();

        switch (a.action()) {
            case POWER_ON -> powerOn(player, c);
            case POWER_OFF -> c.session().shutdown(c.now(), c.perf(), c.tuning());
            case SELECT_OS -> {
                VirtualPcSession.Result r = c.session().selectOs(OsType.byOrdinal(a.arg()));
                if (r != VirtualPcSession.Result.OK) msg(player, "pcsimulator.vpc.msg.os_locked");
            }
            case OPEN_APP -> {
                VirtualPcSession.Result r = c.session().openApp(AppId.byOrdinal(a.arg()), c.now(), c.perf(), c.net());
                if (r == VirtualPcSession.Result.NO_INTERNET) msg(player, "pcsimulator.vpc.msg.no_internet");
                else if (r == VirtualPcSession.Result.TOO_MANY_WINDOWS) msg(player, "pcsimulator.vpc.msg.out_of_memory");
            }
            case CLOSE_WINDOW -> c.session().closeWindow(a.arg());
            case FOCUS_WINDOW -> c.session().focusWindow(a.arg());
            case SET_WIFI -> c.session().setWifiJoined(a.arg() != 0);
            case SET_ETHERNET -> c.session().setEthernetPlugged(a.arg() != 0);
            case OPEN_SHOP -> openShop(player, c);
            default -> { }
        }
        // network may have changed because of the switches above
        Ctx after = a.action() == VpcActionPayload.Action.SET_WIFI || a.action() == VpcActionPayload.Action.SET_ETHERNET
                ? context(level, a.pos(), build) : c;
        after.session().advance(after.now(), after.net());
        persistIfChanged(level, before, after.session());
        push(player, v, after, a.action() == VpcActionPayload.Action.REQUEST_SYNC);
    }

    // ---- ticking ----------------------------------------------------------------------------------------
    public static void onServerTick(ServerTickEvent.Post event) {
        if (VIEWERS.isEmpty()) return; // zero cost when nobody is looking at a virtual PC
        MinecraftServer server = event.getServer();
        int tick = server.getTickCount();
        if (tick % 10 != 0) return;
        double range = VpcConfig.COMMON.range();
        Iterator<Map.Entry<UUID, Viewer>> it = VIEWERS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Viewer> e = it.next();
            ServerPlayer player = server.getPlayerList().getPlayer(e.getKey());
            Viewer v = e.getValue();
            if (player == null || player.level().dimension() != v.dim
                    || player.distanceToSqr(Vec3.atCenterOf(v.pos)) > (range + 2) * (range + 2)) {
                it.remove();
                continue;
            }
            ServerLevel level = player.serverLevel();
            IPCBuild build = level.getCapability(PCCapabilities.PC_BUILD, v.pos);
            if (build == null || !build.buildId().equals(v.buildId)) {
                it.remove();
                continue;
            }
            Ctx c = context(level, v.pos, build);
            VirtualPcSession.Persisted before = c.session().persisted();
            if (tick % 20 == 0) guardPhysical(c);
            c.session().advance(c.now(), c.net());
            persistIfChanged(level, before, c.session());
            if (c.session().version() != v.sentVersion) push(player, v, c, false);
        }
    }

    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        VIEWERS.remove(event.getEntity().getUUID());
    }

    public static void onDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        VIEWERS.remove(event.getEntity().getUUID());
    }

    /** Called from {@code VpcModule#onServerStopped} (core lifecycle hook). */
    public static void onServerStopped() {
        VIEWERS.clear();
    }

    // ---- internals --------------------------------------------------------------------------------------
    private static Ctx context(ServerLevel level, BlockPos pos, IPCBuild build) {
        Tuning t = VpcConfig.tuning();
        VpcSavedData data = VpcSavedData.get(level.getServer());
        VirtualPcSession s = data.session(build.buildId());
        BuildProfiler.Profiled hw = BuildProfiler.profile(build, t);
        VirtualPerformance perf = PerformanceModel.evaluate(hw.profile(), s.os(), t);
        INetworkEnvironment.Environment env = VpcApi.networkEnvironment().resolve(level, pos);
        NetworkStatus net = NetworkModel.evaluate(hw.profile(), s.wifiJoined(), s.ethernetPlugged(),
                env.wifiAvailable(), env.ethernetAvailable(), env.capMbps(), t);
        return new Ctx(level, pos, build, s, t, hw, perf, net, level.getGameTime());
    }

    private static boolean bootable(IPCBuild build) {
        if (build.state() == PCState.FAULT) return false;
        BootResult r = build.checkBoot();
        return r.success();
    }

    /** A running virtual PC whose physical build is no longer bootable loses power at once. */
    private static void guardPhysical(Ctx c) {
        if (c.session().isActive() && !bootable(c.build())) {
            c.session().forceOff("pcsimulator.vpc.notice.hardware_fault");
            VpcSavedData.get(c.level().getServer()).touch();
        }
    }

    private static void powerOn(ServerPlayer player, Ctx c) {
        IPCBuild b = c.build();
        if (b.state() == PCState.FAULT) {
            msg(player, "pcsimulator.vpc.msg.fault");
            return;
        }
        if (VpcConfig.COMMON.followPhysical() && b.state() != PCState.RUNNING) {
            msg(player, "pcsimulator.vpc.msg.physical_off");
            return;
        }
        BootResult boot = b.checkBoot();
        if (!boot.success()) {
            player.displayClientMessage(boot.message(), true); // reason is produced by the pcbuild module
            return;
        }
        VirtualPcSession.Result r = c.session().powerOn(c.now(), c.perf(), c.tuning());
        if (r == VirtualPcSession.Result.BLOCKED && c.perf().blocker() != null) {
            player.displayClientMessage(Component.translatable(c.perf().blocker().langKey(), Component.translatable(c.session().os().langKey())), true);
        }
    }

    private static void openShop(ServerPlayer player, Ctx c) {
        // Deliberately NO network check: the BTC shop must work offline.
        if (c.session().power() != PowerState.RUNNING) return;
        if (!VpcApi.shopLauncher().open(player, c.build().buildId())) msg(player, "pcsimulator.vpc.msg.shop_unavailable");
    }

    private static void persistIfChanged(ServerLevel level, VirtualPcSession.Persisted before, VirtualPcSession s) {
        if (!before.equals(s.persisted())) VpcSavedData.get(level.getServer()).touch();
    }

    private static void push(ServerPlayer player, Viewer v, Ctx c, boolean open) {
        VpcSnapshot snap = VpcSnapshot.of(c.now(), c.session(), c.perf(), c.net(), c.hw().profile(),
                c.hw().cpuLabel(), c.hw().gpuLabel());
        v.sentVersion = c.session().version();
        PCNetwork.sendToPlayer(player, new VpcSnapshotPayload(v.pos, open, snap));
    }

    private static void msg(ServerPlayer p, String key) {
        p.displayClientMessage(Component.translatable(key), true);
    }
}
