package com.pcsimulator.vpc;

import com.pcsimulator.core.config.PCConfig;
import com.pcsimulator.core.module.PCModule;
import com.pcsimulator.core.network.PacketRegistrar;
import com.pcsimulator.vpc.client.VpcClientHooks;
import com.pcsimulator.vpc.network.VpcActionPayload;
import com.pcsimulator.vpc.network.VpcSnapshotPayload;
import com.pcsimulator.vpc.server.VpcInteractions;
import com.pcsimulator.vpc.server.VpcManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;

/**
 * Virtual PC Systems (Claude 5). Claude 7 adds ONE line to {@code ModuleList}:
 * {@code new com.pcsimulator.vpc.VpcModule()}. No dependsOn: only the public api + core registries are used.
 */
public final class VpcModule implements PCModule {
    public static final String ID = "vpc";

    @Override
    public String id() {
        return ID;
    }

    @Override
    public void register(IEventBus modBus, ModContainer container, Dist dist) {
        PCConfig.registerModuleConfig(container, ID, ModConfig.Type.COMMON, VpcConfig.COMMON_SPEC);
        if (dist.isClient()) {
            PCConfig.registerModuleConfig(container, ID, ModConfig.Type.CLIENT, VpcConfig.CLIENT_SPEC);
        }
        VpcInteractions.init();
        NeoForge.EVENT_BUS.addListener(VpcManager::onServerTick);
        NeoForge.EVENT_BUS.addListener(VpcManager::onLogout);
        NeoForge.EVENT_BUS.addListener(VpcManager::onDimensionChange);
    }

    /** Core lifecycle hook (PCModule contract) - replaces a private ServerStoppedEvent subscriber. */
    @Override
    public void onServerStopped(MinecraftServer server) {
        VpcManager.onServerStopped();
    }

    @Override
    public void registerPackets(PacketRegistrar registrar) {
        registrar.toServer(VpcActionPayload.TYPE, VpcActionPayload.STREAM_CODEC, (payload, ctx) -> {
            if (ctx.player() instanceof ServerPlayer sp) VpcManager.handleAction(sp, payload);
        });
        registrar.toClient(VpcSnapshotPayload.TYPE, VpcSnapshotPayload.STREAM_CODEC,
                (payload, ctx) -> VpcClientHooks.onSnapshot(payload));
    }
}
