package com.pcsimulator.vpc.server;

import com.pcsimulator.core.data.PCWorldData;
import com.pcsimulator.vpc.VpcModule;
import com.pcsimulator.vpc.sim.OsType;
import com.pcsimulator.vpc.sim.PowerState;
import com.pcsimulator.vpc.sim.VirtualPcSession;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Per-world store of every virtual PC session, keyed by {@code IPCBuild#buildId()}. File: pcsimulator_vpc_sessions.dat */
public final class VpcSavedData extends SavedData {
    private static final int VERSION = 1;
    private final Map<UUID, VirtualPcSession> sessions = new HashMap<>();

    public static final SavedData.Factory<VpcSavedData> FACTORY =
            new SavedData.Factory<>(VpcSavedData::new, VpcSavedData::load);

    static VpcSavedData get(MinecraftServer server) {
        return PCWorldData.get(server, VpcModule.ID, "sessions", FACTORY);
    }

    VirtualPcSession session(UUID buildId) {
        return sessions.computeIfAbsent(buildId, id -> new VirtualPcSession());
    }

    VirtualPcSession peek(UUID buildId) {
        return sessions.get(buildId);
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putInt("version", VERSION);
        ListTag list = new ListTag();
        for (Map.Entry<UUID, VirtualPcSession> e : sessions.entrySet()) {
            VirtualPcSession.Persisted p = e.getValue().persisted();
            CompoundTag c = new CompoundTag();
            c.putUUID("id", e.getKey());
            c.putString("os", p.os().id);
            c.putInt("power", p.power().ordinal());
            c.putLong("phaseStart", p.phaseStart());
            c.putLong("phaseEnd", p.phaseEnd());
            c.putBoolean("wifi", p.wifiJoined());
            c.putBoolean("eth", p.ethernetPlugged());
            list.add(c);
        }
        tag.put("sessions", list);
        return tag;
    }

    static VpcSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        VpcSavedData d = new VpcSavedData();
        ListTag list = tag.getList("sessions", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            if (!c.hasUUID("id")) continue;
            VirtualPcSession.Persisted p = new VirtualPcSession.Persisted(
                    OsType.byId(c.getString("os"), OsType.WINDOWS_10),
                    PowerState.byOrdinal(c.getInt("power")),
                    c.getLong("phaseStart"), c.getLong("phaseEnd"),
                    !c.contains("wifi") || c.getBoolean("wifi"),
                    !c.contains("eth") || c.getBoolean("eth"));
            d.sessions.put(c.getUUID("id"), VirtualPcSession.restore(p));
        }
        return d;
    }

    void touch() {
        setDirty();
    }
}
