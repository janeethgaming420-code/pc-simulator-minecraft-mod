package net.minecraft.world.level.saveddata; import java.util.function.*; import net.minecraft.nbt.CompoundTag; import net.minecraft.core.HolderLookup;
public abstract class SavedData { public void setDirty(){} public abstract CompoundTag save(CompoundTag t, HolderLookup.Provider p);
 public record Factory<T extends SavedData>(Supplier<T> constructor, BiFunction<CompoundTag,HolderLookup.Provider,T> deserializer, Object type){ public Factory(Supplier<T> c, BiFunction<CompoundTag,HolderLookup.Provider,T> d){ this(c,d,null); } } }
