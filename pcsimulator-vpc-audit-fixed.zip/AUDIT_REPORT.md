# VPC module audit - `pcsimulator-vpc-module.zip` vs `pcsimulator-core.zip`

Scope respected: only the VPC module was changed. Core, Hardware and Workshop were not touched; no integration was started.

## Verdict
The VPC module **conforms to the Core API as written** (no missing interfaces, no signature or package mismatches, no dependency on any other module). The virtual-PC **lifecycle is really implemented** (power state machine, OS requirements, hardware-driven performance, network model, windows, persistence, packets, server validation). The **apps are scaffolds** (see "Implementation status"). It has **never been compiled against real Minecraft/NeoForge** - and I could not do that either.

## 1. Core API conformance (checked against the real Core sources, not the module's stubs)
| Core API used | Result |
|---|---|
| `PCModule` (`id`, `dependsOn`, `register(IEventBus, ModContainer, Dist)`, `registerPackets`, `onServerStopped`) | matches; VpcModule is public, no-arg, listable in `ModuleList` |
| `IPCInteraction.canPerform/perform`, `InteractionContext` (6-field record), `CoreRegistries.INTERACTIONS.register` | matches |
| `IPCBuild` (`buildId`, `installed`, `state`, `checkBoot`), `BootResult`, `PCState`, `ComponentSlot` | matches (only read access is used) |
| `IHardwareComponent` (`type`, `tier`, `performanceScore`), `IHardwareItem.componentOf`, `PCRegistries.hardwareId` | matches |
| `PCCapabilities.PC_BUILD` (`BlockCapability<IPCBuild,Void>`) via `level.getCapability(cap, pos)` | matches |
| `PCNetwork.sendToPlayer/sendToServer`, `PacketRegistrar.toClient/toServer` (`StreamCodec<? super RegistryFriendlyByteBuf,T>`) | matches; the `FriendlyByteBuf`/`ByteBuf` codecs satisfy the bound |
| `PCConfig.registerModuleConfig`, `PCWorldData.get` | matches; file names `pcsimulator/vpc-<type>.toml`, `pcsimulator_vpc_sessions.dat` follow the conventions |
| Payload ids `pcsimulator:vpc/action`, `vpc/snapshot` | follow `<moduleId>/<name>` |

Package/dependency findings: `com.pcsimulator.vpc.*` follows the `com.pcsimulator.<moduleId>` rule. Imports are only `com.pcsimulator.api`, the allowed core helpers, Minecraft and NeoForge - **no reference to hardware/pcbuild/economy/ui/world/workshop**. The module has no Gradle project by design: it is a source drop-in for Core's build (Core's `build.gradle` needs no extra dependency for it).

## 2. Changes made (all inside the VPC module; diff in `CHANGES.diff`)
1. **`VpcApi.powerState` returned stale data.** A PC that finished booting/shutting down while nobody was watching still reported BOOTING/SHUTTING_DOWN. Added `VirtualPcSession.settlePhase(now)` (no network side effects) and used it there; `advance()` now reuses it.
2. **Power-toggle interaction was wrong in three ways.** It reused the screen action path, so it (a) registered a phantom screen viewer that was never removed, (b) overwrote the real failure message (e.g. "No CPU") with "Starting the PC...", (c) claimed "shutting down" when already shutting down. New `VpcManager.togglePower` reports only what actually happened and registers no viewer.
3. **Boot-blocker message showed a raw id** ("windows_10 needs more RAM"). Now passes the translated OS name, as the client already did.
4. **Server stop used a private game-bus listener**, contrary to Core's rule (module hooks cover it). Now implemented through `PCModule#onServerStopped`.
5. **SavedData factory** aligned with Core's own 2-argument pattern (was a 3-argument form with `null`).
6. Verification tooling: stubs updated to mirror the real `PCModule` and `SavedData.Factory`; 6 regression checks added (`settlePhase`). Sim checks: 130 -> **136 pass, 0 fail**; stub typecheck passes; lang check passes (38 keys, none missing/unused).

## 3. Implementation status
Implemented: virtual power OFF/BOOTING/RUNNING/SHUTTING_DOWN gated by `checkBoot()`; OS minimums and weights; performance from installed CPU/GPU/RAM/NIC; network up/down gating Chrome; window limits; per-build persistence; server-validated actions; six OS skins; adaptive client rendering.
Scaffolded / partial: **Chrome** is a static mock page (no navigation or input); **Terminal** prints a fixed spec dump; **BTC Shop** only calls `IShopLauncher` (default: "shop not installed"); **Settings** shows specs and two toggles; open windows are not persisted; no keyboard input anywhere.

## 4. Unresolved issues (reported, not invented)
- **No real compile and no in-game run.** The sandbox cannot reach NeoForge/Minecraft Maven repos. The stub typecheck only proves internal consistency. Highest-risk unverified areas: `GuiGraphics`/`Screen` overrides, payload codecs, `SavedData` persistence, `ModConfigSpec`, event signatures. First action for the integrator: `./gradlew compileJava`.
- **API gaps (Core cannot express these, so VPC approximates):** `IPCBuild` has no way to change `PCState`, so virtual power is separate from physical state (`followPhysicalState` config exists, default false); `IHardwareComponent` has no RAM capacity (RAM GB comes from a tier table) and no NIC kind (Wi-Fi/Ethernet guessed from registry-id substrings, overridable via `VpcApi.setNicKindResolver`); the `performanceScore` scale is undefined (tuning uses a provisional 0-100 scale with tier fallbacks).
- **Architecture rule conflict:** Core rule 2 forbids importing another module's packages, but economy/world must import `VpcApi`, `IShopLauncher` and `INetworkEnvironment` from `com.pcsimulator.vpc`. Needs a Core decision (move those interfaces into `com.pcsimulator.api` or grant an exception). Also: `ModuleIds` and the ownership table in ARCHITECTURE.md do not list `vpc`, and VPC adds entries to the interaction registry whose documented owner is pcbuild.
- **Unverified pcbuild contract:** VPC cuts power if `checkBoot()` fails while a virtual PC is active. The API doc only says "pure check"; it does not say the check stays true for a PC that is already on. pcbuild must confirm.
- **Session store never shrinks:** sessions are created per `buildId` and not purged when a build is destroyed (the API has no build-removed event).
- **Lang file will not load as shipped:** `en_us.vpc.json` is not a Minecraft language name; keys show raw until merged into Core's `en_us.json` (Core file, not touched).

## 5. Integration requirements (NOT performed)
1. Copy `vpc/src/main/java` and the lang keys into Core's source tree; add `new com.pcsimulator.vpc.VpcModule()` to `ModuleList`; merge the 38 lang keys into `en_us.json`.
2. pcbuild must expose `PCCapabilities.PC_BUILD` on the PC block, call `PCInteractions.perform(VpcApi.OPEN_DESKTOP / TOGGLE_POWER, ctx)` from its use handler, and call `VpcApi.notifyBuildChanged(server, build)` after parts change. Without pcbuild the module loads but nothing can open a desktop. (VPC deliberately has no `dependsOn("pcbuild")`: Core's loader throws if a dependency is not listed.)
3. economy: call `VpcApi.setShopLauncher`. hardware/world: optional `setNicKindResolver` / `setNetworkEnvironment`.
4. Core decides whether the two new payloads require bumping `PCNetwork.PROTOCOL_VERSION` (ARCHITECTURE section 8 says any payload change does).
5. Resolve the cross-module API placement question above.
