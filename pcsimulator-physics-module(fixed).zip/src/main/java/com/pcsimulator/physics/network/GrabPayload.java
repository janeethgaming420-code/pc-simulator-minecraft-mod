package com.pcsimulator.physics.network;

import com.pcsimulator.api.PCSimulatorAPI;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: the grab key went down ({@code true}) or up ({@code false}). Carries no position; the server aims itself. */
public record GrabPayload(boolean holding) implements CustomPacketPayload {
    public static final Type<GrabPayload> TYPE = new Type<>(PCSimulatorAPI.id("physics/grab"));
    public static final StreamCodec<ByteBuf, GrabPayload> STREAM_CODEC =
            ByteBufCodecs.BOOL.map(GrabPayload::new, GrabPayload::holding);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
