package com.pcsimulator.physics.network;

import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.physics.PlacementEvaluator;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: which block to outline and whether the held part would be accepted there. */
public record PreviewPayload(PlacementEvaluator.Status status, BlockPos pos) implements CustomPacketPayload {
    public static final Type<PreviewPayload> TYPE = new Type<>(PCSimulatorAPI.id("physics/preview"));
    private static final StreamCodec<ByteBuf, PlacementEvaluator.Status> STATUS_CODEC = ByteBufCodecs.VAR_INT.map(
            i -> PlacementEvaluator.Status.values()[Math.floorMod(i, PlacementEvaluator.Status.values().length)],
            PlacementEvaluator.Status::ordinal);
    public static final StreamCodec<ByteBuf, PreviewPayload> STREAM_CODEC = StreamCodec.composite(
            STATUS_CODEC, PreviewPayload::status,
            BlockPos.STREAM_CODEC, PreviewPayload::pos,
            PreviewPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
