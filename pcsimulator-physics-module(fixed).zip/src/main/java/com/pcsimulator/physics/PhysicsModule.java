package com.pcsimulator.physics;

import com.pcsimulator.core.module.PCModule;
import com.pcsimulator.core.network.PacketRegistrar;
import com.pcsimulator.physics.client.PhysicsClient;
import com.pcsimulator.physics.network.GrabPayload;
import com.pcsimulator.physics.network.PreviewPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.neoforge.common.NeoForge;

/**
 * Basic Physics &amp; Interaction (Claude 8). Claude 7 adds ONE line to ModuleList:
 * {@code new com.pcsimulator.physics.PhysicsModule()}.
 * Depends on no other module: it only uses the public api (IPCBuild via PCCapabilities.PC_BUILD, IHardwareItem).
 */
public final class PhysicsModule implements PCModule {
    public static final String ID = "physics";

    @Override
    public String id() {
        return ID;
    }

    @Override
    public void register(IEventBus modBus, ModContainer container, Dist dist) {
        NeoForge.EVENT_BUS.addListener(GrabManager::onPlayerTick);
        NeoForge.EVENT_BUS.addListener(GrabManager::onPlayerLoggedOut);
        NeoForge.EVENT_BUS.addListener(GrabManager::onServerStopping);
        NeoForge.EVENT_BUS.addListener(GrabManager::onEntityJoin);
    }

    @Override
    public void registerClient(IEventBus modBus, ModContainer container) {
        PhysicsClient.init(modBus);
    }

    @Override
    public void registerPackets(PacketRegistrar registrar) {
        registrar.toServer(GrabPayload.TYPE, GrabPayload.STREAM_CODEC, (payload, ctx) -> {
            if (ctx.player() instanceof ServerPlayer player) GrabManager.onGrabKey(player, payload.holding());
        });
        registrar.toClient(PreviewPayload.TYPE, PreviewPayload.STREAM_CODEC, (payload, ctx) ->
                PreviewState.set(payload.status(), payload.pos()));
    }
}
