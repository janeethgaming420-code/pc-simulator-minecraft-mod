package com.pcsimulator.physics.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.pcsimulator.core.network.PCNetwork;
import com.pcsimulator.physics.PreviewState;
import com.pcsimulator.physics.network.GrabPayload;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

/** Client-only wiring: the hold-to-grab key. Only referenced from {@code PhysicsModule#registerClient}. */
public final class PhysicsClient {
    private PhysicsClient() {}

    public static final KeyMapping GRAB_KEY = new KeyMapping("key.pcsimulator.grab",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.pcsimulator");

    private static boolean sentDown;

    public static void init(IEventBus modBus) {
        modBus.addListener(PhysicsClient::onRegisterKeys);
        NeoForge.EVENT_BUS.addListener(PhysicsClient::onClientTick);
        NeoForge.EVENT_BUS.addListener(PhysicsClient::onLogout);
        NeoForge.EVENT_BUS.addListener(PreviewRenderer::onRenderLevel);
    }

    private static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(GRAB_KEY);
    }

    /** Sends only state CHANGES. Opening a screen counts as releasing the key. */
    private static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        boolean down = mc.player != null && mc.screen == null && GRAB_KEY.isDown();
        if (down != sentDown) {
            sentDown = down;
            if (mc.getConnection() != null) PCNetwork.sendToServer(new GrabPayload(down));
        }
    }

    private static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        sentDown = false;
        PreviewState.clear();
    }
}
