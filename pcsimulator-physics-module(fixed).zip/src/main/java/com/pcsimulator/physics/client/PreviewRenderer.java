package com.pcsimulator.physics.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.pcsimulator.physics.PlacementEvaluator;
import com.pcsimulator.physics.PreviewState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/** Placement preview: a green (accepted) or red (rejected) outline around the PC block the held part is aimed at. */
public final class PreviewRenderer {
    private PreviewRenderer() {}

    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        PlacementEvaluator.Status status = PreviewState.status();
        Minecraft mc = Minecraft.getInstance();
        if (status == PlacementEvaluator.Status.NONE || mc.level == null) return;

        BlockPos pos = PreviewState.pos();
        VoxelShape shape = mc.level.getBlockState(pos).getShape(mc.level, pos);
        AABB box = (shape.isEmpty() ? new AABB(0, 0, 0, 1, 1, 1) : shape.bounds()).move(pos).inflate(0.005);

        boolean ok = status == PlacementEvaluator.Status.VALID;
        float r = ok ? 0.2F : 1.0F;
        float g = ok ? 1.0F : 0.2F;
        float b = 0.2F;

        PoseStack poseStack = event.getPoseStack();
        Vec3 cam = event.getCamera().getPosition();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer lines = buffers.getBuffer(RenderType.lines());
        poseStack.pushPose();
        poseStack.translate(-cam.x, -cam.y, -cam.z);
        LevelRenderer.renderLineBox(poseStack, lines, box, r, g, b, 1.0F);
        poseStack.popPose();
        buffers.endBatch(RenderType.lines());
    }
}
