package com.pcsimulator.physics;

import com.pcsimulator.api.build.ComponentSlot;
import com.pcsimulator.api.build.IPCBuild;
import com.pcsimulator.api.build.InstallResult;
import com.pcsimulator.api.build.PCCapabilities;
import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.api.hardware.IHardwareItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Server-side "where would this part go?" logic. It never decides compatibility itself: every verdict comes from
 * {@link IPCBuild#install(ComponentSlot, ItemStack, boolean)} with {@code simulate = true}.
 */
public final class PlacementEvaluator {
    private PlacementEvaluator() {}

    public static final double PLACE_REACH = 4.5;

    public enum Status { NONE, VALID, INVALID }

    /** NONE = crosshair is not on a PC host. VALID = {@code slot} accepts the part. INVALID = {@code message} says why. */
    public record Target(Status status, BlockPos pos, @Nullable IPCBuild build, @Nullable ComponentSlot slot,
                         @Nullable Component message) {
        public static final Target NONE = new Target(Status.NONE, BlockPos.ZERO, null, null, null);
    }

    /** The PC build (if any) hosted by the block the player is aiming at, plus that block's position. */
    public record Aim(BlockPos pos, IPCBuild build) {}

    @Nullable
    public static Aim aimedBuild(ServerPlayer player) {
        Level level = player.level();
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getViewVector(1.0F).scale(PLACE_REACH));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
        if (hit.getType() != HitResult.Type.BLOCK) return null;
        IPCBuild build = level.getCapability(PCCapabilities.PC_BUILD, hit.getBlockPos(), null);
        return build == null ? null : new Aim(hit.getBlockPos(), build);
    }

    public static Target evaluate(ServerPlayer player, ItemStack stack) {
        Aim aim = aimedBuild(player);
        if (aim == null) return Target.NONE;

        Optional<IHardwareComponent> component = IHardwareItem.componentOf(stack);
        if (component.isEmpty()) return invalid(aim.pos(), InstallResult.NOT_A_COMPONENT);

        // Only slots of the part's own category are candidates; wrong-category placement is rejected up front.
        List<ComponentSlot> candidates = aim.build().slots().stream()
                .filter(s -> s.type() == component.get().type())
                .sorted(Comparator.comparingInt(ComponentSlot::index))
                .toList();
        if (candidates.isEmpty()) return invalid(aim.pos(), InstallResult.NO_SUCH_SLOT);

        InstallResult worst = null;
        for (ComponentSlot slot : candidates) {
            InstallResult r = aim.build().install(slot, stack.copy(), true);
            if (r.isSuccess()) return new Target(Status.VALID, aim.pos(), aim.build(), slot, null);
            if (worst == null || rank(r) > rank(worst)) worst = r;
        }
        return invalid(aim.pos(), worst);
    }

    /** Which failure is the most useful to show when several slots reject the part. */
    private static int rank(InstallResult r) {
        return switch (r) {
            case SLOT_OCCUPIED -> 0;
            case PC_IS_ON -> 2;
            default -> 1;
        };
    }

    private static Target invalid(BlockPos pos, InstallResult reason) {
        return new Target(Status.INVALID, pos, null, null, messageFor(reason));
    }

    public static Component messageFor(InstallResult result) {
        return Component.translatable("message.pcsimulator.physics.install." + result.name().toLowerCase(java.util.Locale.ROOT));
    }
}
