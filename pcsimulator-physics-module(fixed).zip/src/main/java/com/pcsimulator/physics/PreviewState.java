package com.pcsimulator.physics;

import net.minecraft.core.BlockPos;

/** Client-side copy of the latest placement preview sent by the server. Plain data, safe to load on any side. */
public final class PreviewState {
    private PreviewState() {}

    private static volatile PlacementEvaluator.Status status = PlacementEvaluator.Status.NONE;
    private static volatile BlockPos pos = BlockPos.ZERO;

    public static void set(PlacementEvaluator.Status s, BlockPos p) {
        pos = p;
        status = s;
    }

    public static PlacementEvaluator.Status status() {
        return status;
    }

    public static BlockPos pos() {
        return pos;
    }

    public static void clear() {
        status = PlacementEvaluator.Status.NONE;
    }
}
