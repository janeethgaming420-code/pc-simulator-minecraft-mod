package com.pcsimulator.physics;

import com.mojang.logging.LogUtils;
import com.pcsimulator.api.build.ComponentSlot;
import com.pcsimulator.api.build.IPCBuild;
import com.pcsimulator.api.build.InstallResult;
import com.pcsimulator.api.hardware.IHardwareItem;
import com.pcsimulator.core.network.PCNetwork;
import com.pcsimulator.physics.network.PreviewPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Server-side grab / move / drop / install / remove.
 *
 * <p>A grabbed part is a real {@link ItemEntity} (so vanilla syncs and renders it) with gravity and pickup disabled,
 * which is teleported in front of the player every tick. Holding is tied to the key state sent by the client:
 * key down = grab, key up = release (install if aimed at a compatible slot, otherwise drop).
 *
 * <p>Everything here runs on the server thread only. State is in-memory; held entities carry {@link #TAG} so they are
 * released after a crash/restart instead of floating forever.
 */
public final class GrabManager {
    private GrabManager() {}

    private static final Logger LOGGER = LogUtils.getLogger();
    public static final String TAG = "pcsimulator_held";
    private static final double GRAB_REACH = 4.5;
    private static final double HOLD_DISTANCE = 2.0;
    /** Held entity is fresh (age 0) so it would despawn at 6000 ticks; release well before that. */
    private static final int MAX_HOLD_TICKS = 4000;

    private static final class Grab {
        final ItemEntity entity;
        final ServerLevel level;
        final ItemStack stack;
        int ticks;
        PlacementEvaluator.Status lastStatus = PlacementEvaluator.Status.NONE;
        BlockPos lastPos = BlockPos.ZERO;
        Component lastMessage;

        Grab(ItemEntity entity, ServerLevel level, ItemStack stack) {
            this.entity = entity;
            this.level = level;
            this.stack = stack;
        }
    }

    private static final Map<UUID, Grab> GRABS = new HashMap<>();
    private static final Set<UUID> HELD_ENTITIES = new HashSet<>();

    // ---------------------------------------------------------------- input

    public static void onGrabKey(ServerPlayer player, boolean down) {
        if (down) {
            if (!GRABS.containsKey(player.getUUID()) && player.isAlive() && !player.isSpectator()) tryGrab(player);
        } else if (GRABS.containsKey(player.getUUID())) {
            release(player);
        }
    }

    // ---------------------------------------------------------------- grab

    private static void tryGrab(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1.0F);
        Vec3 end = eye.add(look.scale(GRAB_REACH));

        BlockHitResult blockHit = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
        double blockDistSq = blockHit.getType() == HitResult.Type.MISS ? Double.MAX_VALUE : blockHit.getLocation().distanceToSqr(eye);

        // 1) a loose component the player is looking at (not hidden behind a block)
        ItemEntity best = null;
        double bestDistSq = Double.MAX_VALUE;
        AABB search = player.getBoundingBox().expandTowards(look.scale(GRAB_REACH)).inflate(1.0);
        for (ItemEntity e : level.getEntitiesOfClass(ItemEntity.class, search, GrabManager::isGrabbable)) {
            Optional<Vec3> hit = e.getBoundingBox().inflate(0.25).clip(eye, end);
            if (hit.isEmpty()) continue;
            double d = hit.get().distanceToSqr(eye);
            if (d < bestDistSq) {
                best = e;
                bestDistSq = d;
            }
        }
        if (best != null && bestDistSq <= blockDistSq) {
            ItemStack one = best.getItem().copyWithCount(1);
            // The held entity is spawned BEFORE the original is touched: if spawning fails, nothing was changed.
            if (!startHolding(player, level, one, best.position())) {
                LOGGER.warn("Could not spawn held entity for {} at {}; original item left untouched", one, best.position());
                player.displayClientMessage(Component.translatable("message.pcsimulator.physics.grab_failed"), true);
                return;
            }
            ItemStack rest = best.getItem().copy();
            rest.shrink(1);
            if (rest.isEmpty()) best.discard();
            else best.setItem(rest);
            player.displayClientMessage(Component.translatable("message.pcsimulator.physics.grabbed", one.getHoverName()), true);
            return;
        }

        // 2) an installed component of the PC the player is looking at
        PlacementEvaluator.Aim aim = PlacementEvaluator.aimedBuild(player);
        if (aim != null) {
            grabInstalled(player, level, aim);
            return;
        }
        player.displayClientMessage(Component.translatable("message.pcsimulator.physics.nothing"), true);
    }

    /**
     * Removal order: reverse {@code ComponentType} order (peripherals ... CPU, motherboard, case last), then slot index.
     * The api gives no slot geometry, so the player cannot pick one slot with the crosshair; repeated grabs take the
     * next removable part. Whether a removal is allowed (PC off, dependants) is entirely up to IPCBuild.remove.
     */
    private static void grabInstalled(ServerPlayer player, ServerLevel level, PlacementEvaluator.Aim aim) {
        IPCBuild build = aim.build();
        List<ComponentSlot> order = new ArrayList<>(build.slots());
        order.sort(Comparator.comparingInt((ComponentSlot s) -> s.type().ordinal()).reversed()
                .thenComparingInt(ComponentSlot::index));

        boolean anyInstalled = false;
        for (ComponentSlot slot : order) {
            if (build.getInstalled(slot).isEmpty()) continue;
            anyInstalled = true;
            if (build.remove(slot, true).isEmpty()) continue; // not removable right now
            ItemStack removed = build.remove(slot, false);
            if (removed.isEmpty()) continue;
            Vec3 at = player.getEyePosition().add(player.getViewVector(1.0F).scale(HOLD_DISTANCE));
            // IPCBuild may hand back a stack of any size; hold exactly one, give any surplus back to the world.
            ItemStack one = removed.copyWithCount(1);
            ItemStack surplus = removed.getCount() > 1 ? removed.copyWithCount(removed.getCount() - 1) : ItemStack.EMPTY;
            if (!startHolding(player, level, one, at)) {
                // The part is already out of the PC: put it back into its ORIGINAL slot; never lose it.
                LOGGER.warn("Could not spawn held entity for {}; reinstalling into {}", one, slot);
                InstallResult back = build.install(slot, one.copy(), false);
                if (!back.isSuccess()) {
                    LOGGER.error("Reinstall of {} into {} failed ({}); returning it to the player", one, slot, back);
                    rescue(player, one);
                }
                rescue(player, surplus);
                player.displayClientMessage(Component.translatable("message.pcsimulator.physics.grab_failed"), true);
                return;
            }
            if (!surplus.isEmpty()) {
                ItemEntity extra = new ItemEntity(level, at.x, at.y, at.z, surplus.copy());
                if (!level.addFreshEntity(extra)) {
                    LOGGER.warn("Could not spawn surplus {}; returning it to the player", surplus);
                    rescue(player, surplus);
                }
            }
            level.playSound(null, aim.pos(), SoundEvents.ITEM_FRAME_REMOVE_ITEM, SoundSource.PLAYERS, 1.0F, 1.0F);
            player.displayClientMessage(Component.translatable("message.pcsimulator.physics.removed", one.getHoverName()), true);
            return;
        }
        player.displayClientMessage(Component.translatable(anyInstalled
                ? "message.pcsimulator.physics.cannot_remove" : "message.pcsimulator.physics.empty_pc"), true);
    }

    private static boolean isGrabbable(ItemEntity e) {
        return !e.isRemoved() && !e.getItem().isEmpty() && !HELD_ENTITIES.contains(e.getUUID())
                && e.getItem().getItem() instanceof IHardwareItem
                && IHardwareItem.componentOf(e.getItem()).isPresent();
    }

    /**
     * Spawns the held entity. Returns false (and registers NOTHING) if the world refused it. The TAG is added only
     * after a successful spawn: adding an entity fires EntityJoinLevelEvent, and {@link #onEntityJoin} would otherwise
     * treat a tagged-but-not-yet-registered entity as a leftover and reset it.
     */
    private static boolean startHolding(ServerPlayer player, ServerLevel level, ItemStack one, Vec3 at) {
        ItemEntity held = new ItemEntity(level, at.x, at.y, at.z, one.copy());
        held.setDeltaMovement(Vec3.ZERO);
        held.setNoGravity(true);
        held.setInvulnerable(true);
        held.setPickUpDelay(32767); // never picked up / merged while held
        if (!level.addFreshEntity(held)) return false;
        held.addTag(TAG);
        HELD_ENTITIES.add(held.getUUID());
        GRABS.put(player.getUUID(), new Grab(held, level, one.copy()));
        return true;
    }

    /**
     * Last-resort recovery for a stack that must not be lost: player inventory first, then dropped at the player's
     * feet. Always logged. (Player#drop does not report a failed spawn, so the final step cannot be verified.)
     */
    private static void rescue(ServerPlayer player, ItemStack stack) {
        if (stack.isEmpty()) return;
        ItemStack rest = stack.copy();
        player.getInventory().add(rest);
        if (!rest.isEmpty()) player.drop(rest, false);
        LOGGER.warn("Recovered {} for {} (inventory or dropped at feet)", stack, player.getGameProfile().getName());
        player.displayClientMessage(Component.translatable("message.pcsimulator.physics.recovered", stack.getHoverName()), true);
    }

    // ---------------------------------------------------------------- tick / move

    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (GRABS.isEmpty() || !(event.getEntity() instanceof ServerPlayer player)) return;
        Grab g = GRABS.get(player.getUUID());
        if (g == null) return;

        if (!player.isAlive() || player.isSpectator() || player.level() != g.level || ++g.ticks > MAX_HOLD_TICKS) {
            release(player);
            return;
        }
        if (g.entity.isRemoved()) { // killed by a command / void etc.: put the part back into the world
            release(player);
            return;
        }

        // Move: in front of the player; a ray from the eyes stops the part at the first solid block (basic collision).
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1.0F);
        Vec3 want = eye.add(look.scale(HOLD_DISTANCE));
        BlockHitResult hit = g.level.clip(new ClipContext(eye, want, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 pos = hit.getType() == HitResult.Type.MISS ? want : hit.getLocation().subtract(look.scale(0.3));
        g.entity.setPos(pos.x, pos.y - g.entity.getBbHeight() / 2.0, pos.z);
        g.entity.setDeltaMovement(Vec3.ZERO);

        // Preview: tell the client what the crosshair block would do with this part.
        PlacementEvaluator.Target t = PlacementEvaluator.evaluate(player, g.stack);
        if (t.status() != g.lastStatus || !t.pos().equals(g.lastPos)) {
            g.lastStatus = t.status();
            g.lastPos = t.pos();
            PCNetwork.sendToPlayer(player, new PreviewPayload(t.status(), t.pos()));
        }
        Component msg = t.status() == PlacementEvaluator.Status.INVALID ? t.message()
                : t.status() == PlacementEvaluator.Status.VALID
                ? Component.translatable("message.pcsimulator.physics.can_install",
                g.stack.getHoverName(), Component.translatable("pcsimulator.hardware.type." + t.slot().type().getSerializedName()), t.slot().index() + 1)
                : null;
        if (msg != null && !msg.equals(g.lastMessage)) player.displayClientMessage(msg, true);
        g.lastMessage = msg;
    }

    // ---------------------------------------------------------------- release

    private static void release(ServerPlayer player) {
        Grab g = GRABS.remove(player.getUUID());
        if (g == null) return;
        HELD_ENTITIES.remove(g.entity.getUUID());
        PCNetwork.sendToPlayer(player, new PreviewPayload(PlacementEvaluator.Status.NONE, BlockPos.ZERO));

        boolean alive = player.isAlive() && !player.isSpectator() && player.level() == g.level && !g.entity.isRemoved();
        if (alive) {
            PlacementEvaluator.Target t = PlacementEvaluator.evaluate(player, g.stack);
            if (t.status() == PlacementEvaluator.Status.VALID) {
                InstallResult r = t.build().install(t.slot(), g.stack.copy(), false);
                if (r.isSuccess()) {
                    g.entity.discard();
                    g.level.playSound(null, t.pos(), SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.PLAYERS, 1.0F, 1.0F);
                    player.displayClientMessage(Component.translatable("message.pcsimulator.physics.installed", g.stack.getHoverName()), true);
                    return;
                }
                player.displayClientMessage(PlacementEvaluator.messageFor(r), true); // state changed since the preview
            } else if (t.status() == PlacementEvaluator.Status.INVALID) {
                player.displayClientMessage(t.message(), true); // rejected: the part is dropped, never force-installed
            }
        }
        dropFree(g, player);
    }

    /** Turns the held entity into an ordinary dropped item (or recreates it if it vanished). */
    private static void dropFree(Grab g, ServerPlayer player) {
        ItemEntity e = g.entity;
        if (e.isRemoved()) {
            e = new ItemEntity(g.level, g.entity.getX(), g.entity.getY(), g.entity.getZ(), g.stack.copy());
            if (!g.level.addFreshEntity(e)) {
                LOGGER.warn("Could not respawn dropped {}; returning it to the player", g.stack);
                rescue(player, g.stack);
                return;
            }
        }
        e.removeTag(TAG);
        e.setNoGravity(false);
        e.setInvulnerable(false);
        e.setPickUpDelay(20);
    }

    // ---------------------------------------------------------------- lifecycle

    public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) releaseWithoutInstall(player);
    }

    public static void onServerStopping(ServerStoppingEvent event) {
        for (ServerPlayer p : event.getServer().getPlayerList().getPlayers()) releaseWithoutInstall(p);
        GRABS.clear();
        HELD_ENTITIES.clear();
    }

    private static void releaseWithoutInstall(ServerPlayer player) {
        Grab g = GRABS.remove(player.getUUID());
        if (g == null) return;
        HELD_ENTITIES.remove(g.entity.getUUID());
        dropFree(g, player);
    }

    /** A held-tagged entity that is not tracked (crash, forced stop) would float forever: make it a normal item again. */
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof ItemEntity e)) return;
        if (e.getTags().contains(TAG) && !HELD_ENTITIES.contains(e.getUUID())) {
            e.removeTag(TAG);
            e.setNoGravity(false);
            e.setInvulnerable(false);
            e.setPickUpDelay(20);
        }
    }
}
