# Basic Physics & Interaction (`com.pcsimulator.physics`) - Claude 8

Status: **NOT compiled, NOT run.** The authoring sandbox had no javac, no Minecraft/NeoForge jars and no network.
Only a structural check was done (balanced braces, unused imports, valid lang JSON). Expect possible signature fixes on the
first `./gradlew compileJava`.

## Integration (for Claude 7)
* `ModuleList`: add `new com.pcsimulator.physics.PhysicsModule()` (module id `physics`, no dependencies; ModuleList NOT edited).
* Lang: merge `assets/pcsimulator/lang/en_us.physics.json` into `en_us.json` (keys are unique, prefixed `message.pcsimulator.physics.*`, `key.*`).
* Two new payloads (`pcsimulator:physics/grab` C2S, `pcsimulator:physics/preview` S2C): per ARCHITECTURE s8 bump `PCNetwork.PROTOCOL_VERSION` when merging (core not edited).
* **Hard dependency for install/remove: the pcbuild module** must expose `PCCapabilities.PC_BUILD` on the host block (cases have no block entity today).
* No other module's files were touched. Imports: `api.*` and `core.module/network` only.

## Controls
Hold **G** (rebindable: "Grab PC Component (hold)", category PC Simulator). Opening a screen counts as releasing.
* Key down while aiming at a loose hardware item (reach 4.5) -> grab ONE item of the stack.
* Key down while aiming at a PC host block -> take out one installed component.
* Held part floats 2 blocks in front of you and follows your look direction (real `ItemEntity`: no gravity, not pickable, invulnerable).
* Key up -> install if the aimed block is a PC with a compatible free slot; otherwise drop it as a normal item (with the reason on the action bar).

## What is implemented
1. **Grab** components by holding the key: loose `IHardwareItem` item entities (items that resolve to an `IHardwareComponent`).
2. **Move**: held part tracks the player's view every tick. Collision: a block-collider ray from the eyes stops the part at the first solid block; it cannot be pushed through walls. Auto-release after 4000 ticks, on death/spectator/dimension change/logout/server stop.
3. **Snap** into compatible slots: candidate slots = `IPCBuild.slots()` of the part's own `ComponentType`, lowest index first; first one where `install(slot, copy, simulate=true)` is `SUCCESS` is used, then `install(..., false)`.
4. **Invalid placements prevented**: all verdicts come from `IPCBuild.install(simulate)` (`NO_SUCH_SLOT`, `SLOT_OCCUPIED`, `INCOMPATIBLE`, `PC_IS_ON`, `NOT_A_COMPONENT`, plus our own category filter). Nothing is ever force-installed; non-components and out-of-reach targets are ignored.
5. **Remove installed**: `IPCBuild.remove(slot, simulate)` first, then for real. Allowed/blocked is entirely pcbuild's decision (e.g. PC on).
6. **Preview**: green/red outline around the aimed PC block (server decides, client draws) + action-bar text ("Release to install X into Y slot N" / the rejection reason).

Not done on purpose: wires, screws, fan spin, animations, physics simulation, any invented slot geometry.

## Failure recovery (no component is silently lost)
Every `Level#addFreshEntity` result is now checked (it returns false if the world or an `EntityJoinLevelEvent` listener refuses the entity).
`startHolding` returns a boolean and registers the player in `GRABS` and the entity in `HELD_ENTITIES` **only after a successful spawn**.

| Situation | Behaviour |
|---|---|
| Grab a loose item, held entity cannot spawn | The held entity is spawned **before** the original stack is changed, so on failure the original is untouched (nothing to restore). Warning logged, "Could not pick that up - nothing was lost". |
| Take an installed part out, held entity cannot spawn | The part is already out of the PC (the api only returns it from `remove`), so it is **reinstalled into its original slot** via `IPCBuild.install(slot, ..., false)`. |
| ...and that reinstall is also refused | Error logged; the part goes to the player's inventory, and what does not fit is dropped at the player's feet ("X was returned to you"). |
| `IPCBuild.remove` returned a stack with count > 1 | One is held; the surplus is spawned as a normal item. If that spawn fails (or the hold failed above) the surplus goes to the player's inventory / feet. |
| Release path: held entity vanished (`/kill`, void) and re-spawning the drop fails | Same inventory-then-feet recovery. |

Notes: `TAG` is added to the held entity only after spawning, because `addFreshEntity` fires `EntityJoinLevelEvent` and the crash-cleanup handler would otherwise reset a tagged-but-unregistered entity.
The last-resort feet drop uses `Player#drop`, which does not report failure, so that single step cannot be verified; every recovery is logged at WARN/ERROR. On logout/server-stop the recovery targets a player who is leaving; whether inventory changes at that point are still saved was not verified.
Not covered: a hard crash between `IPCBuild.remove` and the spawn (same tick, no persistence point) is not guarded.

## Removal order (verified)
Checked against `ComponentType.java` in the supplied project: ordinals are CASE 0, MOTHERBOARD 1, CPU 2, COOLER 3, RAM 4, GPU 5, STORAGE 6, PSU 7, NETWORK_CARD 8, PERIPHERAL 9.
Sorting by descending ordinal then ascending index gives PERIPHERAL, NETWORK_CARD, PSU, STORAGE, GPU, RAM, COOLER, CPU, MOTHERBOARD, CASE - exactly the order documented below. It depends on enum declaration order, so reordering `ComponentType` would change it.

## Limitations (honest)
* **Slot-level, not position-level snapping.** `ComponentSlot` is only (type, index); the API has no slot coordinates, so the part snaps to "the PC" and the first suitable slot, not to a visible socket. Adding e.g. `IPCHost`/`IPCBuild#slotBounds(ComponentSlot)` to the api would allow true 3D snapping (needs Claude 1).
* **Removal cannot be aimed per slot** for the same reason: each grab takes the next removable part in fixed order (peripherals, network, PSU, storage, GPU, RAM, cooler, CPU, motherboard, case; then index).
* **Without a pcbuild implementation** no block provides `PC_BUILD`, so install/remove cannot work; grabbing/moving/dropping loose parts does. A part released while aimed at a case block just drops.
* Compatibility is not re-implemented here (e.g. `WorkshopCompat` is not called); we trust `IPCBuild.install` as the single authority.
* In-memory grab state: after a hard crash a held item keeps tag `pcsimulator_held`; it is turned back into a normal item when its chunk next loads.
* Held-item preview is the vanilla item entity (no ghost model at the slot).

## Untested (everything - please check on first run)
1. Compiles: likely risk points are `RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS`, `LevelRenderer.renderLineBox`, `KeyMapping` 4-arg ctor, `ServerPlayer#serverLevel`, `Level#getCapability(cap, pos, null)`.
2. Held `ItemEntity` looks smooth on the client (entity tracking interval may make it slightly steppy).
3. Grab/release over the network, key hold/release, screen-open release.
4. Item stack of N>1 splits correctly; no duplication/loss on release, logout, death, `/kill` of the held entity.
5. Install/remove against a real `IPCBuild` (none supplied): result handling, surplus stack handling if `remove` returns count > 1.
5b. The new recovery paths: a failed spawn is hard to trigger (needs an `EntityJoinLevelEvent` cancel or similar); they were reviewed by reading only, never executed.
6. Preview outline colours and action-bar messages.
7. Multiplayer: two players cannot grab the same held part (held entities are excluded by UUID).

## Manual test (once pcbuild exists)
Drop/hold a provisional RAM item; press and hold G on it; move; aim at a PC (outline green) -> release -> installed.
Aim at PC with PC on -> red + "Turn the PC off first" -> part drops. Hold G on the PC (off) -> parts come out one per grab.
