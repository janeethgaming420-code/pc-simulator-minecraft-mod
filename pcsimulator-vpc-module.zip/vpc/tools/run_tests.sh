#!/usr/bin/env bash
# Compiles and runs the pure-Java simulation layer (com.pcsimulator.vpc.sim) with plain javac. No Minecraft, no Gradle.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
javac -Xlint:all -d "$OUT" $(find src/main/java/com/pcsimulator/vpc/sim tests/java -name '*.java')
java -cp "$OUT" com.pcsimulator.vpc.sim.SimTests
