package net.neoforged.neoforge.registries; public class DeferredHolder<R,T extends R> {}
