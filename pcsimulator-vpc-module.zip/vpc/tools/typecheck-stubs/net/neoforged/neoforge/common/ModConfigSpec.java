package net.neoforged.neoforge.common; import java.util.function.Function; import org.apache.commons.lang3.tuple.Pair;
public class ModConfigSpec {
 public static class ConfigValue<T>{ public T get(){return null;} }
 public static class IntValue extends ConfigValue<Integer>{ public Integer get(){return 0;} }
 public static class DoubleValue extends ConfigValue<Double>{ public Double get(){return 0.0;} }
 public static class BooleanValue extends ConfigValue<Boolean>{ public Boolean get(){return false;} }
 public static class EnumValue<E extends Enum<E>> extends ConfigValue<E>{}
 public static class Builder { public Builder comment(String s){return this;} public Builder push(String s){return this;} public Builder pop(){return this;} public Builder translation(String s){return this;}
  public <T> ConfigValue<T> define(String p,T d){return null;} public BooleanValue define(String p,boolean d){return null;}
  public IntValue defineInRange(String p,int d,int a,int b){return null;} public DoubleValue defineInRange(String p,double d,double a,double b){return null;}
  public <E extends Enum<E>> EnumValue<E> defineEnum(String p,E d){return null;} public ModConfigSpec build(){return null;}
  public <T> Pair<T,ModConfigSpec> configure(Function<Builder,T> f){return Pair.of(f.apply(this),null);} } }
