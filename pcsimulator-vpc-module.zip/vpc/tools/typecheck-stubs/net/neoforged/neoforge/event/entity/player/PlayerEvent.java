package net.neoforged.neoforge.event.entity.player; import net.minecraft.world.entity.player.Player;
public class PlayerEvent { public Player getEntity(){return null;} public static class PlayerLoggedOutEvent extends PlayerEvent{} public static class PlayerChangedDimensionEvent extends PlayerEvent{} }
