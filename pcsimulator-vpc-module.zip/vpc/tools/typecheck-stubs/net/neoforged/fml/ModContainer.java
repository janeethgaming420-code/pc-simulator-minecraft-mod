package net.neoforged.fml; public interface ModContainer {}
