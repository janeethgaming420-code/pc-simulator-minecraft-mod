package net.minecraft.core; public class Vec3i {}
