package net.minecraft.core; import io.netty.buffer.ByteBuf; import net.minecraft.network.codec.StreamCodec;
public class BlockPos extends Vec3i { public static final StreamCodec<ByteBuf, BlockPos> STREAM_CODEC = null; public BlockPos immutable(){return this;} }
