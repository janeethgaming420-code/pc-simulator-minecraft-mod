package net.minecraft.client.gui.screens; import net.minecraft.client.gui.*; import net.minecraft.network.chat.Component;
public abstract class Screen { protected int width, height; protected Font font; protected Screen(Component c){} protected void init(){} public void render(GuiGraphics g,int x,int y,float p){} public void renderBackground(GuiGraphics g,int x,int y,float p){}
 public boolean mouseClicked(double x,double y,int b){return false;} public void removed(){} public boolean isPauseScreen(){return true;} }
