package net.minecraft.client; import net.minecraft.client.gui.screens.Screen; import net.minecraft.world.level.Level;
public class Minecraft { public Level level; public Screen screen; public static Minecraft getInstance(){return null;} public void setScreen(Screen s){} }
