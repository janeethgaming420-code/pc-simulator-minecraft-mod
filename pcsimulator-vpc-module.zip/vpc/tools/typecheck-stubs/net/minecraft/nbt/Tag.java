package net.minecraft.nbt; public interface Tag { byte TAG_COMPOUND = 10; }
