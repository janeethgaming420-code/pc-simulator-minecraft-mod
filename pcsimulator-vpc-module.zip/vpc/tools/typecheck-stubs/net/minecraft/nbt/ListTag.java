package net.minecraft.nbt; public class ListTag extends java.util.ArrayList<Tag> implements Tag { public CompoundTag getCompound(int i){return null;} }
