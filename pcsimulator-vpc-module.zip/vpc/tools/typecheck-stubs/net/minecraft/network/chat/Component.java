package net.minecraft.network.chat; public interface Component { static Component translatable(String k,Object... a){return null;} String getString(); }
