package net.minecraft.network.codec; import io.netty.buffer.ByteBuf;
public class ByteBufCodecs { public static final StreamCodec<ByteBuf,Integer> VAR_INT = null; }
