package net.minecraft.network.codec; import java.util.function.*;
public interface StreamCodec<B,T> { T decode(B b); void encode(B b,T t);
 default <S> StreamCodec<B,S> map(Function<? super T,? extends S> to, Function<? super S,? extends T> from){return null;}
 static <B,C,T1,T2,T3> StreamCodec<B,C> composite(StreamCodec<? super B,T1> c1, Function<C,T1> g1, StreamCodec<? super B,T2> c2, Function<C,T2> g2, StreamCodec<? super B,T3> c3, Function<C,T3> g3, Function3<T1,T2,T3,C> f){return null;}
 interface Function3<A,B,C,R>{ R apply(A a,B b,C c);} }
