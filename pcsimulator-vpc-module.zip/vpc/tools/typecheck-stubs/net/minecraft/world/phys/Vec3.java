package net.minecraft.world.phys; import net.minecraft.core.Vec3i; public class Vec3 { public static Vec3 atCenterOf(Vec3i v){return new Vec3();} }
