package net.minecraft.world.level; import net.minecraft.core.BlockPos; import net.minecraft.resources.ResourceKey; import net.neoforged.neoforge.capabilities.BlockCapability;
public class Level { public boolean isClientSide; public long getGameTime(){return 0;} public long getDayTime(){return 0;} public ResourceKey<Level> dimension(){return null;}
 public <T> T getCapability(BlockCapability<T,Void> c, BlockPos p){return null;} }
