package net.minecraft.world.entity.player; import java.util.UUID; import net.minecraft.world.level.Level; import net.minecraft.world.phys.Vec3;
public class Player { public UUID getUUID(){return null;} public double distanceToSqr(Vec3 v){return 0;} public Level level(){return null;} }
