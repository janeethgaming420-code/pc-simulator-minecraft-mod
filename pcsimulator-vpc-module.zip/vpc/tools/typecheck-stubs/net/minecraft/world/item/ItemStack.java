package net.minecraft.world.item; public class ItemStack { public int getCount(){return 1;} public Item getItem(){return null;} } 
