package net.minecraft.server; import net.minecraft.server.level.ServerPlayer; import java.util.UUID; public class PlayerList { public ServerPlayer getPlayer(UUID u){return null;} }
