package net.minecraft.server.level; import net.minecraft.server.MinecraftServer; import net.minecraft.network.chat.Component; import net.minecraft.world.entity.player.Player;
public class ServerPlayer extends Player { public MinecraftServer server; public ServerLevel serverLevel(){return null;} public void displayClientMessage(Component c, boolean b){} }
