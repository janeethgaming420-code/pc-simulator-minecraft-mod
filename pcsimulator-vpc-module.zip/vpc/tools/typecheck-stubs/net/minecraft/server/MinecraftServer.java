package net.minecraft.server; import net.minecraft.server.level.*; import java.util.UUID;
public class MinecraftServer { public int getTickCount(){return 0;} public PlayerList getPlayerList(){return null;} public ServerLevel overworld(){return null;}
  }
