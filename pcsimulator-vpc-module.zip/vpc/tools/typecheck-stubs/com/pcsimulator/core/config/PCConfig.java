package com.pcsimulator.core.config; import net.neoforged.fml.ModContainer; import net.neoforged.fml.config.ModConfig; import net.neoforged.neoforge.common.ModConfigSpec;
public final class PCConfig { public static void registerModuleConfig(ModContainer c,String id,ModConfig.Type t,ModConfigSpec s){} }
