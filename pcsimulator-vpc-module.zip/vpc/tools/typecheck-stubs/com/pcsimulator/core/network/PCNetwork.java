package com.pcsimulator.core.network; import net.minecraft.network.protocol.common.custom.CustomPacketPayload; import net.minecraft.server.level.ServerPlayer;
public final class PCNetwork { public static void sendToPlayer(ServerPlayer p, CustomPacketPayload c){} public static void sendToServer(CustomPacketPayload c){} }
