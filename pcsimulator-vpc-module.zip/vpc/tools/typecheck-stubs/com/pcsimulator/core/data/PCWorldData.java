package com.pcsimulator.core.data; import net.minecraft.server.MinecraftServer; import net.minecraft.world.level.saveddata.SavedData;
public final class PCWorldData { public static <T extends SavedData> T get(MinecraftServer s,String m,String n,SavedData.Factory<T> f){return null;} }
