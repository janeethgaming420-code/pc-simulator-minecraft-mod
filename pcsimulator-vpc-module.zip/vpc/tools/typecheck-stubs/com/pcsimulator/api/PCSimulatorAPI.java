package com.pcsimulator.api; import net.minecraft.resources.ResourceLocation; public final class PCSimulatorAPI { public static ResourceLocation id(String p){return null;} }
