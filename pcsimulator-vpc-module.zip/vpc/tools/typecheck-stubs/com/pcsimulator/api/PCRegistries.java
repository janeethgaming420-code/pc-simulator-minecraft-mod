package com.pcsimulator.api; import com.pcsimulator.api.hardware.IHardwareComponent; import net.minecraft.resources.ResourceLocation;
public final class PCRegistries { public static ResourceLocation hardwareId(IHardwareComponent c){return null;} }
