package com.pcsimulator.api.hardware; public enum ComponentTier { ENTRY, MID, HIGH, ENTHUSIAST }
