package com.pcsimulator.api.hardware; import net.minecraft.world.item.ItemStack; import java.util.Optional;
public interface IHardwareItem { IHardwareComponent getComponent(ItemStack s); static Optional<IHardwareComponent> componentOf(ItemStack s){ if (s.getItem() instanceof IHardwareItem i) return Optional.ofNullable(i.getComponent(s)); return Optional.empty(); } }
