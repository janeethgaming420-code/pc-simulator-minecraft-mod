package com.pcsimulator.api.hardware; public enum ComponentType { CASE, MOTHERBOARD, CPU, COOLER, RAM, GPU, STORAGE, PSU, NETWORK_CARD, PERIPHERAL }
