#!/usr/bin/env bash
# Type-checks the WHOLE module against tiny hand-written stubs of the Minecraft/NeoForge/core APIs it touches.
# This catches typos and cross-class mistakes only. It is NOT a compile against real Minecraft/NeoForge:
# the stubs encode the author's belief about those APIs. The real check is `./gradlew compileJava`.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
javac -Xlint:all,-serial -d "$OUT" $(find tools/typecheck-stubs -name '*.java') $(find src/main/java -name '*.java')
echo "typecheck OK (stubs only)"
