#!/usr/bin/env python3
"""Verifies every literal lang key used in the Java sources exists in en_us.vpc.json and that dynamic prefixes are covered."""
import json, re, sys, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
lang = json.load(open(root / "src/main/resources/assets/pcsimulator/lang/en_us.vpc.json"))
src = "\n".join(p.read_text() for p in (root / "src/main/java").rglob("*.java"))
used = set(re.findall(r'"(pcsimulator\.vpc\.[a-z_0-9.]+)"', src))
missing = sorted(k for k in used if not k.endswith(".") and k not in lang)
from_enums = []
for os_ in ["windows_7","windows_10","windows_11","ubuntu","fedora","arch"]: from_enums.append("pcsimulator.vpc.os."+os_)
for a in ["chrome","btc_shop","settings","terminal"]: from_enums.append("pcsimulator.vpc.app."+a)
for b in ["no_cpu","no_ram","os_needs_more_ram","os_needs_faster_cpu"]: from_enums.append("pcsimulator.vpc.blocker."+b)
for p in ["low","mid","high","ultra"]: from_enums.append("pcsimulator.vpc.perf."+p)
missing += [k for k in from_enums if k not in lang]
unused = sorted(k for k in lang if k not in used and k not in from_enums)
print("keys used:", len(used), "| missing:", missing, "| unused:", unused)
sys.exit(1 if missing else 0)
