package com.pcsimulator.vpc.sim;

/**
 * Every gameplay-tuning constant of the module in one immutable record. Defaults are provisional because the
 * hardware module has not yet published a performance-score scale (all current catalogue parts score 0).
 * Built from config by the Minecraft layer; tests use {@link #DEFAULT}.
 */
public record Tuning(
        /** Upper end of the hardware performance-score scale; scores are normalised to 0..100 against this. */
        int scoreCeiling,
        /** Score assumed for a part whose catalogue score is 0 (unset), indexed by tier ordinal. */
        int[] tierFallbackScore,
        /** RAM per module in GB when the catalogue gives no capacity, indexed by tier ordinal. */
        int[] tierRamGb,
        /** Normalised GPU score used when no GPU is installed (integrated graphics). */
        int integratedGpuScore,
        /** Ethernet bandwidth in Mbit/s by tier ordinal. */
        int[] ethernetMbps,
        /** Wi-Fi bandwidth in Mbit/s by tier ordinal. */
        int[] wifiMbps,
        /** A NIC must be installed for a link type to work. */
        boolean requireNicForNetwork,
        int bootBaseTicks,
        int shutdownBaseTicks,
        /** Slowest allowed virtual speed relative to 1.0 baseline (avoids absurd waits). */
        double minSpeed,
        double maxSpeed,
        int maxWindowsCap
) {
    public static final Tuning DEFAULT = new Tuning(
            100,
            new int[]{20, 45, 70, 95},
            new int[]{4, 8, 16, 32},
            8,
            new int[]{100, 1000, 2500, 10000},
            new int[]{50, 150, 600, 1200},
            true,
            200, 60,
            0.25, 2.0,
            8);

    public int fallbackScore(int tierOrdinal) {
        return tierFallbackScore[Math.min(Math.max(tierOrdinal, 0), tierFallbackScore.length - 1)];
    }

    public int ramGbForTier(int tierOrdinal) {
        return tierRamGb[Math.min(Math.max(tierOrdinal, 0), tierRamGb.length - 1)];
    }

    public int mbps(NicKind kind, int tierOrdinal) {
        int[] t = kind == NicKind.WIFI ? wifiMbps : ethernetMbps;
        return t[Math.min(Math.max(tierOrdinal, 0), t.length - 1)];
    }
}
