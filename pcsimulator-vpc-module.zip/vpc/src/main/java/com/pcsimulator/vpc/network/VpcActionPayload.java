package com.pcsimulator.vpc.network;

import com.pcsimulator.api.PCSimulatorAPI;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: one player action on a virtual PC. The server validates range, capability and state. */
public record VpcActionPayload(BlockPos pos, Action action, int arg) implements CustomPacketPayload {
    public enum Action {
        POWER_ON, POWER_OFF, SELECT_OS, OPEN_APP, CLOSE_WINDOW, FOCUS_WINDOW,
        SET_WIFI, SET_ETHERNET, OPEN_SHOP, REQUEST_SYNC, CLOSE_SCREEN
    }

    public static final Type<VpcActionPayload> TYPE = new Type<>(PCSimulatorAPI.id("vpc/action"));
    private static final StreamCodec<ByteBuf, Action> ACTION_CODEC = ByteBufCodecs.VAR_INT.map(
            i -> Action.values()[Math.floorMod(i, Action.values().length)], Action::ordinal);
    public static final StreamCodec<ByteBuf, VpcActionPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, VpcActionPayload::pos,
            ACTION_CODEC, VpcActionPayload::action,
            ByteBufCodecs.VAR_INT, VpcActionPayload::arg,
            VpcActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
