package com.pcsimulator.vpc.api;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/**
 * Optional hook: what network infrastructure exists around a PC (routers, wall sockets...). The default
 * offers Wi-Fi and Ethernet everywhere with no bandwidth cap, so connectivity is decided by the PC's installed
 * network cards and the player's Wi-Fi/Ethernet switches. Another module (e.g. world / router blocks) may
 * replace it with {@code VpcApi.setNetworkEnvironment}. Server thread only.
 */
@FunctionalInterface
public interface INetworkEnvironment {
    /** @param capMbps uplink cap, {@link Integer#MAX_VALUE} = unlimited */
    record Environment(boolean wifiAvailable, boolean ethernetAvailable, int capMbps) {
        public static final Environment OPEN = new Environment(true, true, Integer.MAX_VALUE);
    }

    Environment resolve(Level level, BlockPos pos);

    INetworkEnvironment DEFAULT = (level, pos) -> Environment.OPEN;
}
