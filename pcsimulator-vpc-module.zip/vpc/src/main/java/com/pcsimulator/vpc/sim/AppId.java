package com.pcsimulator.vpc.sim;

/** Virtual applications. Chrome needs internet; the BTC shop launcher never does. */
public enum AppId {
    // id, needs internet, base launch ticks (at speed factor 1.0), RAM in MB
    CHROME("chrome", true, 40, 700),
    BTC_SHOP("btc_shop", false, 20, 250),
    SETTINGS("settings", false, 15, 150),
    TERMINAL("terminal", false, 10, 80);

    public final String id;
    public final boolean requiresInternet;
    public final int baseLaunchTicks;
    public final int ramMb;

    AppId(String id, boolean requiresInternet, int baseLaunchTicks, int ramMb) {
        this.id = id;
        this.requiresInternet = requiresInternet;
        this.baseLaunchTicks = baseLaunchTicks;
        this.ramMb = ramMb;
    }

    public String langKey() {
        return "pcsimulator.vpc.app." + id;
    }

    public static AppId byOrdinal(int i) {
        AppId[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
