package com.pcsimulator.vpc.server;

import com.pcsimulator.api.PCRegistries;
import com.pcsimulator.api.build.ComponentSlot;
import com.pcsimulator.api.build.IPCBuild;
import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.api.hardware.IHardwareItem;
import com.pcsimulator.vpc.VpcApi;
import com.pcsimulator.vpc.sim.HardwareProfile;
import com.pcsimulator.vpc.sim.Tuning;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Turns an {@link IPCBuild} into a {@link HardwareProfile} using ONLY public API accessors
 * ({@code IPCBuild#installed}, {@code IHardwareComponent#type/tier/performanceScore}).
 *
 * <p>Known gap: the API has no RAM capacity or NIC kind accessor, so RAM GB comes from the tier table in
 * {@link Tuning} and NIC kind from {@link VpcApi#nicKind}.
 */
final class BuildProfiler {
    private BuildProfiler() {}

    record Profiled(HardwareProfile profile, String cpuLabel, String gpuLabel) {}

    static Profiled profile(IPCBuild build, Tuning t) {
        int cpuScore = -1, cpuTier = 0, gpuScore = -1, gpuTier = 0, ramGb = 0;
        String cpuLabel = "-", gpuLabel = "-";
        List<HardwareProfile.Nic> nics = new ArrayList<>();

        for (Map.Entry<ComponentSlot, ItemStack> e : build.installed().entrySet()) {
            IHardwareComponent c = IHardwareItem.componentOf(e.getValue()).orElse(null);
            if (c == null) continue;
            int tier = c.tier().ordinal();
            switch (c.type()) {
                case CPU -> {
                    if (cpuScore < 0 || effective(c, t) > effective(cpuScore, cpuTier, t)) {
                        cpuScore = c.performanceScore();
                        cpuTier = tier;
                        cpuLabel = label(c);
                    }
                }
                case GPU -> {
                    if (gpuScore < 0 || effective(c, t) > effective(gpuScore, gpuTier, t)) {
                        gpuScore = c.performanceScore();
                        gpuTier = tier;
                        gpuLabel = label(c);
                    }
                }
                case RAM -> ramGb += t.ramGbForTier(tier) * Math.max(1, e.getValue().getCount());
                case NETWORK_CARD -> nics.add(new HardwareProfile.Nic(VpcApi.nicKind(c), tier));
                default -> { }
            }
        }
        return new Profiled(new HardwareProfile(cpuScore, cpuTier, gpuScore, gpuTier, ramGb, nics), cpuLabel, gpuLabel);
    }

    private static int effective(IHardwareComponent c, Tuning t) {
        return effective(c.performanceScore(), c.tier().ordinal(), t);
    }

    private static int effective(int raw, int tier, Tuning t) {
        return raw > 0 ? raw : t.fallbackScore(tier);
    }

    private static String label(IHardwareComponent c) {
        try {
            return PCRegistries.hardwareId(c).getPath();
        } catch (IllegalArgumentException e) {
            return "?";
        }
    }
}
