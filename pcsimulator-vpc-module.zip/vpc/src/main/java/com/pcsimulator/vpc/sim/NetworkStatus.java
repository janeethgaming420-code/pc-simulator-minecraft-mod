package com.pcsimulator.vpc.sim;

/**
 * Simulated network state of one virtual PC.
 *
 * @param link  which link carries traffic (ETHERNET is preferred when both are up), null if offline
 * @param mbps  bandwidth of that link, 0 offline
 */
public record NetworkStatus(boolean online, NicKind link, int mbps, String reasonKey) {
    public static final NetworkStatus OFFLINE_NO_LINK = new NetworkStatus(false, null, 0, "pcsimulator.vpc.net.disconnected");

    public static NetworkStatus up(NicKind link, int mbps) {
        return new NetworkStatus(true, link, mbps, "pcsimulator.vpc.net.connected");
    }

    public static NetworkStatus down(String reasonKey) {
        return new NetworkStatus(false, null, 0, reasonKey);
    }

    /** Extra ticks a page load takes at this bandwidth (0 offline-safe: returns 0 when offline, caller must gate). */
    public int pageLoadTicks() {
        if (!online) return 0;
        return (int) Math.max(5, Math.min(200, Math.round(400.0 / Math.max(1, mbps) * 20)));
    }
}
