package com.pcsimulator.vpc.sim;

/**
 * Animation time of the SIMULATED desktop. Quantised to the virtual PC's own frame rate and driven by game
 * ticks, so a slow virtual PC animates choppily and a fast one smoothly, regardless of the viewer's real FPS.
 */
public final class VirtualClock {
    private VirtualClock() {}

    public static double seconds(long gameTime, float partialTick) {
        return (gameTime + partialTick) / 20.0;
    }

    public static double quantize(double seconds, int virtualFps) {
        int fps = Math.max(1, virtualFps);
        return Math.floor(seconds * fps) / fps;
    }

    /** Progress 0..1 between two absolute ticks, quantised to the virtual frame rate. */
    public static double progress(long start, long end, long gameTime, float partialTick, int virtualFps) {
        if (end <= start) return 1.0;
        double s = quantize(seconds(gameTime, partialTick), virtualFps);
        double a = start / 20.0;
        double b = end / 20.0;
        return Math.max(0.0, Math.min(1.0, (s - a) / (b - a)));
    }
}
