package com.pcsimulator.vpc.server;

import com.pcsimulator.api.interaction.IPCInteraction;
import com.pcsimulator.api.interaction.InteractionContext;
import com.pcsimulator.core.registry.CoreRegistries;
import com.pcsimulator.vpc.VpcApi;
import com.pcsimulator.vpc.sim.PowerState;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.neoforged.neoforge.registries.DeferredHolder;

/** The two interactions this module adds to {@code pcsimulator:interaction}. pcbuild / Claude 7 trigger them. */
public final class VpcInteractions {
    private VpcInteractions() {}

    public static final DeferredHolder<IPCInteraction, IPCInteraction> OPEN =
            CoreRegistries.INTERACTIONS.register(VpcApi.OPEN_DESKTOP.getPath(), () -> new Open());
    public static final DeferredHolder<IPCInteraction, IPCInteraction> TOGGLE_POWER =
            CoreRegistries.INTERACTIONS.register(VpcApi.TOGGLE_POWER.getPath(), () -> new TogglePower());

    /** Call from {@code PCModule#register} so the static fields above run before RegisterEvent. */
    public static void init() {}

    private static final class Open implements IPCInteraction {
        @Override
        public boolean canPerform(InteractionContext c) {
            return c.build() != null;
        }

        @Override
        public InteractionResult perform(InteractionContext c) {
            if (c.level().isClientSide) return InteractionResult.SUCCESS;
            if (c.player() instanceof ServerPlayer sp) VpcManager.open(sp, c.level(), c.pos(), c.build());
            return InteractionResult.CONSUME;
        }
    }

    private static final class TogglePower implements IPCInteraction {
        @Override
        public boolean canPerform(InteractionContext c) {
            return c.build() != null;
        }

        @Override
        public InteractionResult perform(InteractionContext c) {
            if (c.level().isClientSide) return InteractionResult.SUCCESS;
            if (!(c.player() instanceof ServerPlayer sp)) return InteractionResult.PASS;
            boolean on = VpcManager.powerState(sp.server, c.build().buildId()) != PowerState.OFF;
            // Route through the same validated path as the on-screen power button.
            VpcManager.handleAction(sp, new com.pcsimulator.vpc.network.VpcActionPayload(c.pos(),
                    on ? com.pcsimulator.vpc.network.VpcActionPayload.Action.POWER_OFF
                       : com.pcsimulator.vpc.network.VpcActionPayload.Action.POWER_ON, 0));
            sp.displayClientMessage(Component.translatable(on ? "pcsimulator.vpc.msg.shutting_down" : "pcsimulator.vpc.msg.starting"), true);
            return InteractionResult.CONSUME;
        }
    }
}
