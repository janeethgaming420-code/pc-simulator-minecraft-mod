package com.pcsimulator.vpc.api;

import net.minecraft.server.level.ServerPlayer;

import java.util.UUID;

/**
 * Bridge to the BTC shop, which is NOT part of this module (Claude 6). The virtual desktop shows a "BTC Shop"
 * app that works with or without internet; clicking its button calls this launcher. Return false if the shop is
 * not installed - the player then sees a "shop unavailable" message. Server thread only.
 */
@FunctionalInterface
public interface IShopLauncher {
    boolean open(ServerPlayer player, UUID buildId);
}
