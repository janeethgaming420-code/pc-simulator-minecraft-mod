package com.pcsimulator.vpc;

import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.api.build.IPCBuild;
import com.pcsimulator.api.hardware.IHardwareComponent;
import com.pcsimulator.vpc.api.INetworkEnvironment;
import com.pcsimulator.vpc.api.IShopLauncher;
import com.pcsimulator.vpc.server.VpcManager;
import com.pcsimulator.vpc.sim.NicKind;
import com.pcsimulator.vpc.sim.PowerState;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

import java.util.Locale;
import java.util.UUID;
import java.util.function.Function;

/**
 * Public surface of the Virtual PC module for other modules (pcbuild, economy, world, ui). Everything is
 * optional: with no calls at all the module works on its own through its two registered interactions.
 */
public final class VpcApi {
    private VpcApi() {}

    /** Interaction id: opens the virtual desktop for the targeted PC. Run via {@code PCInteractions.perform}. */
    public static final ResourceLocation OPEN_DESKTOP = PCSimulatorAPI.id("vpc_open");
    /** Interaction id: toggles virtual power (boot / shut down) of the targeted PC. */
    public static final ResourceLocation TOGGLE_POWER = PCSimulatorAPI.id("vpc_power_toggle");

    private static volatile INetworkEnvironment networkEnvironment = INetworkEnvironment.DEFAULT;
    private static volatile IShopLauncher shopLauncher = (player, buildId) -> false;
    private static volatile Function<IHardwareComponent, NicKind> nicKindResolver = VpcApi::guessNicKind;

    public static void setNetworkEnvironment(INetworkEnvironment env) {
        networkEnvironment = env == null ? INetworkEnvironment.DEFAULT : env;
    }

    /** The economy/shop module calls this once to make the BTC shop app functional. */
    public static void setShopLauncher(IShopLauncher launcher) {
        shopLauncher = launcher == null ? (p, b) -> false : launcher;
    }

    /**
     * Replaces how a NETWORK_CARD component is classified as Wi-Fi or Ethernet. The default inspects the
     * registry id for "wifi / wi_fi / wlan / wireless" because the core API exposes no network-kind accessor.
     */
    public static void setNicKindResolver(Function<IHardwareComponent, NicKind> resolver) {
        nicKindResolver = resolver == null ? VpcApi::guessNicKind : resolver;
    }

    public static INetworkEnvironment networkEnvironment() { return networkEnvironment; }

    public static IShopLauncher shopLauncher() { return shopLauncher; }

    public static NicKind nicKind(IHardwareComponent c) { return nicKindResolver.apply(c); }

    /** Opens the desktop screen for {@code player}. Server side. */
    public static void openDesktop(ServerPlayer player, Level level, BlockPos pos, IPCBuild build) {
        VpcManager.open(player, level, pos, build);
    }

    /** Current virtual power state; OFF for PCs that never ran. Server thread. */
    public static PowerState powerState(MinecraftServer server, UUID buildId) {
        return VpcManager.powerState(server, buildId);
    }

    /**
     * Tell the module that a build's contents or physical state changed (part removed, PSU changed...). If the
     * build can no longer boot, a running virtual PC is cut off immediately.
     */
    public static void notifyBuildChanged(MinecraftServer server, IPCBuild build) {
        VpcManager.revalidate(server, build);
    }

    private static NicKind guessNicKind(IHardwareComponent c) {
        try {
            String id = com.pcsimulator.api.PCRegistries.hardwareId(c).getPath().toLowerCase(Locale.ROOT);
            if (id.contains("wifi") || id.contains("wi_fi") || id.contains("wlan") || id.contains("wireless")) return NicKind.WIFI;
        } catch (IllegalArgumentException ignored) {
            // unregistered component: treat as wired
        }
        return NicKind.ETHERNET;
    }
}
