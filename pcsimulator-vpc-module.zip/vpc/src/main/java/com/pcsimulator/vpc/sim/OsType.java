package com.pcsimulator.vpc.sim;

import java.util.Locale;

/** Visual OS simulations. These are skins plus resource requirements, NOT real operating systems. */
public enum OsType {
    // id, family, resource weight (higher = heavier = slower on weak hardware), min RAM GB, min CPU score
    WINDOWS_7("windows_7", Family.WINDOWS, 0.85, 1, 5),
    WINDOWS_10("windows_10", Family.WINDOWS, 1.15, 2, 10),
    WINDOWS_11("windows_11", Family.WINDOWS, 1.40, 4, 15),
    UBUNTU("ubuntu", Family.LINUX, 1.00, 4, 10),
    FEDORA("fedora", Family.LINUX, 0.95, 2, 10),
    ARCH("arch", Family.LINUX, 0.60, 1, 5);

    public enum Family { WINDOWS, LINUX }

    public final String id;
    public final Family family;
    /** Multiplier on all virtual durations; also scales idle RAM use. */
    public final double weight;
    public final int minRamGb;
    public final int minCpuScore;

    OsType(String id, Family family, double weight, int minRamGb, int minCpuScore) {
        this.id = id;
        this.family = family;
        this.weight = weight;
        this.minRamGb = minRamGb;
        this.minCpuScore = minCpuScore;
    }

    /** Idle RAM use in MB (kernel, shell, services). */
    public int idleRamMb() {
        return (int) Math.round(500 * weight + 300);
    }

    public String langKey() {
        return "pcsimulator.vpc.os." + id;
    }

    public static OsType byOrdinal(int i) {
        OsType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }

    public static OsType byId(String id, OsType fallback) {
        String s = id == null ? "" : id.toLowerCase(Locale.ROOT);
        for (OsType o : values()) if (o.id.equals(s)) return o;
        return fallback;
    }
}
