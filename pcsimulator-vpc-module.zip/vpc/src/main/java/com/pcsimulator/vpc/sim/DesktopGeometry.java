package com.pcsimulator.vpc.sim;

import com.pcsimulator.vpc.sim.OsTheme.ButtonStyle;
import com.pcsimulator.vpc.sim.OsTheme.Layout;
import com.pcsimulator.vpc.sim.WindowLayout.Rect;

import java.util.ArrayList;
import java.util.List;

/**
 * Pixel layout of a virtual desktop inside a monitor rectangle. Pure integer maths: the renderer draws from
 * these rectangles and the click handler hit-tests against the SAME rectangles, so they can never disagree.
 */
public final class DesktopGeometry {
    private DesktopGeometry() {}

    public record AppButton(AppId app, Rect rect) {}

    /** @param id window id; {@code frame} whole window; {@code content} below the title bar */
    public record WinGeo(int id, AppId app, Rect frame, Rect title, Rect close, Rect content) {}

    public record Geo(Rect monitor, Rect bar, Rect dock, Rect work, Rect start, List<AppButton> apps,
                      Rect wifiTray, Rect ethTray, Rect clock, Rect menu, List<Rect> menuItems,
                      List<WinGeo> windows) {}

    /** Menu entries: one per app, then shut-down. */
    public static final int MENU_ENTRIES = AppId.values().length + 1;
    private static final int ITEM_H = 12;
    private static final int EMPTY = 0;

    public record WinRef(int id, AppId app) {}

    public static Geo compute(OsTheme th, Rect m, List<WinRef> wins, boolean menuOpen) {
        int bh = th.barHeight();
        Rect bar, dock = null, work, start, wifi, eth, clock;
        List<AppButton> apps = new ArrayList<>();
        AppId[] all = AppId.values();

        switch (th.layout()) {
            case BOTTOM_LEFT, BOTTOM_CENTERED -> {
                bar = new Rect(m.x(), m.bottom() - bh, m.w(), bh);
                work = new Rect(m.x(), m.y(), m.w(), m.h() - bh);
                int btn = bh - 2;
                int total = (all.length + 1) * (btn + 2);
                int x = th.layout() == Layout.BOTTOM_CENTERED ? m.x() + (m.w() - total) / 2 : m.x() + 2;
                start = new Rect(x, bar.y() + 1, btn + (th.start() == OsTheme.StartStyle.AERO_ORB ? 2 : 0), btn);
                int ax = start.right() + 2;
                for (AppId a : all) {
                    apps.add(new AppButton(a, new Rect(ax, bar.y() + 1, btn, btn)));
                    ax += btn + 2;
                }
                clock = new Rect(m.right() - 36, bar.y(), 34, bh);
                wifi = new Rect(clock.x() - 16, bar.y() + 2, 14, bh - 4);
                eth = new Rect(wifi.x() - 16, bar.y() + 2, 14, bh - 4);
            }
            case TOP_PANEL_WITH_DOCK -> {
                bar = new Rect(m.x(), m.y(), m.w(), bh);
                dock = new Rect(m.x(), m.y() + bh, th.dockWidth(), m.h() - bh);
                work = new Rect(m.x() + th.dockWidth(), m.y() + bh, m.w() - th.dockWidth(), m.h() - bh);
                start = new Rect(m.x() + 2, bar.y(), 46, bh);
                int ay = dock.y() + 4;
                int btn = th.dockWidth() - 6;
                for (AppId a : all) {
                    apps.add(new AppButton(a, new Rect(dock.x() + 3, ay, btn, btn)));
                    ay += btn + 4;
                }
                clock = new Rect(m.x() + (m.w() - 40) / 2, bar.y(), 40, bh);
                wifi = new Rect(m.right() - 16, bar.y() + 1, 14, bh - 2);
                eth = new Rect(wifi.x() - 16, bar.y() + 1, 14, bh - 2);
            }
            case TOP_PANEL_ONLY -> {
                bar = new Rect(m.x(), m.y(), m.w(), bh);
                work = new Rect(m.x(), m.y() + bh, m.w(), m.h() - bh);
                start = new Rect(m.x() + 2, bar.y(), 46, bh);
                clock = new Rect(m.x() + (m.w() - 40) / 2, bar.y(), 40, bh);
                wifi = new Rect(m.right() - 16, bar.y() + 1, 14, bh - 2);
                eth = new Rect(wifi.x() - 16, bar.y() + 1, 14, bh - 2);
            }
            default -> { // TOP_BAR_TILING
                bar = new Rect(m.x(), m.y(), m.w(), bh);
                work = new Rect(m.x(), m.y() + bh, m.w(), m.h() - bh);
                start = new Rect(m.x() + 2, bar.y(), 56, bh);
                clock = new Rect(m.right() - 40, bar.y(), 38, bh);
                wifi = new Rect(clock.x() - 24, bar.y(), 22, bh);
                eth = new Rect(wifi.x() - 24, bar.y(), 22, bh);
            }
        }

        Rect menu = new Rect(EMPTY, EMPTY, EMPTY, EMPTY);
        List<Rect> items = new ArrayList<>();
        if (menuOpen) {
            int mw = 96;
            int mh = MENU_ENTRIES * ITEM_H + 4;
            int mx = Math.max(m.x(), Math.min(start.x(), m.right() - mw));
            int my = th.topBar() ? bar.bottom() : bar.y() - mh;
            menu = new Rect(mx, my, mw, mh);
            for (int i = 0; i < MENU_ENTRIES; i++) items.add(new Rect(mx + 2, my + 2 + i * ITEM_H, mw - 4, ITEM_H));
        }

        List<WinGeo> ws = new ArrayList<>(wins.size());
        for (int i = 0; i < wins.size(); i++) {
            WinRef w = wins.get(i);
            Rect f = WindowLayout.place(th, i, wins.size(), work);
            int th_ = th.titleHeight();
            Rect title = new Rect(f.x(), f.y(), f.w(), th_);
            Rect close;
            if (th.buttons() == ButtonStyle.AERO) close = new Rect(f.right() - 24, f.y() + 1, 22, th_ - 3);
            else if (th.buttons() == ButtonStyle.FLAT) close = new Rect(f.right() - 16, f.y(), 16, th_);
            else if (th.buttons() == ButtonStyle.ROUND_CLOSE) close = new Rect(f.right() - th_ + 2, f.y() + 2, th_ - 4, th_ - 4);
            else close = new Rect(f.right() - 10, f.y(), 10, th_);
            Rect content = new Rect(f.x() + 1, f.y() + th_, f.w() - 2, f.h() - th_ - 1);
            ws.add(new WinGeo(w.id(), w.app(), f, title, close, content));
        }
        return new Geo(m, bar, dock, work, start, apps, wifi, eth, clock, menu, items, ws);
    }

    // ---- window-content hit areas shared by renderer and click handling ---------------------------------
    public static Rect settingsWifiToggle(Rect c) { return new Rect(c.x() + 6, c.bottom() - 18, 56, 12); }

    public static Rect settingsEthToggle(Rect c) { return new Rect(c.x() + 68, c.bottom() - 18, 56, 12); }

    public static Rect shopButton(Rect c) { return new Rect(c.x() + 6, c.y() + 28, 70, 14); }

    // ---- power-off screen -------------------------------------------------------------------------------
    public static Rect powerButton(Rect m) { return new Rect(m.x() + m.w() / 2 + 10, m.y() + m.h() / 2 - 12, 24, 24); }

    public static Rect osButton(Rect m, int index) { return new Rect(m.x() + 8, m.y() + 22 + index * 15, 84, 13); }

    /** Topmost window under the point, or null. Windows are in z-order, last = top. */
    public static WinGeo windowAt(Geo g, double x, double y) {
        for (int i = g.windows().size() - 1; i >= 0; i--) {
            if (g.windows().get(i).frame().contains(x, y)) return g.windows().get(i);
        }
        return null;
    }
}
