package com.pcsimulator.vpc;

import com.pcsimulator.vpc.sim.RenderQuality;
import com.pcsimulator.vpc.sim.Tuning;
import net.neoforged.neoforge.common.ModConfigSpec;

/** Module-owned configuration: {@code config/pcsimulator/vpc-common.toml} and {@code vpc-client.toml}. */
public final class VpcConfig {
    private VpcConfig() {}

    public static final class Common {
        public final ModConfigSpec spec;
        final ModConfigSpec.IntValue scoreCeiling, integratedGpuScore, bootBaseTicks, shutdownBaseTicks, maxWindows;
        final ModConfigSpec.ConfigValue<String> fallbackScores, ramGbByTier, ethernetMbps, wifiMbps;
        final ModConfigSpec.BooleanValue requireNic;
        final ModConfigSpec.DoubleValue minSpeed, maxSpeed, range;
        public final ModConfigSpec.BooleanValue followPhysicalState;

        private Common(ModConfigSpec.Builder b) {
            b.push("performance");
            scoreCeiling = b.comment("Top of the hardware performance-score scale. Part scores are normalised against it.")
                    .defineInRange("scoreCeiling", 100, 1, 100000);
            fallbackScores = b.comment("Score assumed for a part whose catalogue score is 0 (unset): entry,mid,high,enthusiast.")
                    .define("fallbackScores", "20,45,70,95");
            ramGbByTier = b.comment("GB per RAM module when the catalogue has no capacity: entry,mid,high,enthusiast.")
                    .define("ramGbByTier", "4,8,16,32");
            integratedGpuScore = b.comment("Normalised GPU score used when no GPU is installed.")
                    .defineInRange("integratedGpuScore", 8, 1, 100);
            minSpeed = b.defineInRange("minSpeed", 0.25, 0.05, 1.0);
            maxSpeed = b.defineInRange("maxSpeed", 2.0, 1.0, 10.0);
            bootBaseTicks = b.comment("Boot duration in ticks at speed 1.0.").defineInRange("bootBaseTicks", 200, 20, 12000);
            shutdownBaseTicks = b.defineInRange("shutdownBaseTicks", 60, 10, 6000);
            maxWindows = b.comment("Absolute cap on simultaneously open virtual windows.").defineInRange("maxWindows", 8, 1, 32);
            b.pop();
            b.push("network");
            ethernetMbps = b.comment("Ethernet Mbit/s by NIC tier.").define("ethernetMbps", "100,1000,2500,10000");
            wifiMbps = b.comment("Wi-Fi Mbit/s by NIC tier.").define("wifiMbps", "50,150,600,1200");
            requireNic = b.comment("A matching network card must be installed for a link to work.")
                    .define("requireNetworkCard", true);
            b.pop();
            b.push("integration");
            followPhysicalState = b.comment("If true the virtual PC can only start while the pcbuild module reports PCState.RUNNING. Leave false unless pcbuild drives PCState.")
                    .define("followPhysicalState", false);
            range = b.comment("Max distance (blocks) between a player and the PC they operate.").defineInRange("interactionRange", 8.0, 2.0, 32.0);
            b.pop();
            spec = b.build();
        }

        public double range() {
            try { return range.get(); } catch (IllegalStateException e) { return 8.0; }
        }

        public boolean followPhysical() {
            try { return followPhysicalState.get(); } catch (IllegalStateException e) { return false; }
        }
    }

    public static final class Client {
        public final ModConfigSpec spec;
        public final ModConfigSpec.EnumValue<RenderQuality> maxQuality;
        public final ModConfigSpec.BooleanValue adaptive;
        public final ModConfigSpec.IntValue targetFps;

        private Client(ModConfigSpec.Builder b) {
            b.push("rendering");
            maxQuality = b.comment("Highest detail YOUR client ever draws for a virtual desktop, whatever the virtual PC supports.")
                    .defineEnum("maxQuality", RenderQuality.HIGH);
            adaptive = b.comment("Automatically lower detail when your real frame rate drops below the target.")
                    .define("adaptiveQuality", true);
            targetFps = b.defineInRange("targetFps", 30, 10, 240);
            b.pop();
            spec = b.build();
        }

        public RenderQuality maxQualityOr() {
            try { return maxQuality.get(); } catch (IllegalStateException e) { return RenderQuality.MEDIUM; }
        }

        public boolean adaptiveOr() {
            try { return adaptive.get(); } catch (IllegalStateException e) { return true; }
        }

        public int targetFpsOr() {
            try { return targetFps.get(); } catch (IllegalStateException e) { return 30; }
        }
    }

    public static final Common COMMON = new Common(new ModConfigSpec.Builder());
    public static final ModConfigSpec COMMON_SPEC = COMMON.spec;
    public static final Client CLIENT = new Client(new ModConfigSpec.Builder());
    public static final ModConfigSpec CLIENT_SPEC = CLIENT.spec;

    /** Current tuning; falls back to defaults if the config is not loaded yet. Cheap enough to call per action. */
    public static Tuning tuning() {
        Common c = COMMON;
        try {
            Tuning d = Tuning.DEFAULT;
            return new Tuning(c.scoreCeiling.get(), parse(c.fallbackScores.get(), d.tierFallbackScore()),
                    parse(c.ramGbByTier.get(), d.tierRamGb()), c.integratedGpuScore.get(),
                    parse(c.ethernetMbps.get(), d.ethernetMbps()), parse(c.wifiMbps.get(), d.wifiMbps()),
                    c.requireNic.get(), c.bootBaseTicks.get(), c.shutdownBaseTicks.get(),
                    c.minSpeed.get(), Math.max(c.minSpeed.get(), c.maxSpeed.get()), c.maxWindows.get());
        } catch (IllegalStateException notLoaded) {
            return Tuning.DEFAULT;
        }
    }

    /** "a,b,c,d" -> int[4]; any malformed or short list returns the fallback instead of throwing. */
    static int[] parse(String s, int[] fallback) {
        try {
            String[] p = s.split(",");
            if (p.length != fallback.length) return fallback;
            int[] out = new int[p.length];
            for (int i = 0; i < p.length; i++) {
                out[i] = Integer.parseInt(p[i].trim());
                if (out[i] <= 0) return fallback;
            }
            return out;
        } catch (RuntimeException e) {
            return fallback;
        }
    }
}
