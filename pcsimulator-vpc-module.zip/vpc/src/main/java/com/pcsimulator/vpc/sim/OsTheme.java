package com.pcsimulator.vpc.sim;

/**
 * Pure-data description of how an OS skin looks and is laid out. The client renderer interprets this; there is
 * no Minecraft code here so themes can be unit-tested. Colours are 0xAARRGGBB.
 */
public record OsTheme(
        OsType os, Layout layout, StartStyle start, ButtonStyle buttons,
        int wallpaperTop, int wallpaperBottom,
        int barTop, int barBottom, int barText, int accent,
        int titleActive, int titleInactive, int titleText, int windowBody, int windowText, int windowBorder,
        int barHeight, int dockWidth, int titleHeight, int cornerCut, int windowGap,
        boolean glass, boolean tiled, boolean clockCentered) {

    /** Where the system bar lives and how app launching is presented. */
    public enum Layout {
        /** Windows 7/10: bar along the bottom, start button at the left. */
        BOTTOM_LEFT,
        /** Windows 11: bar along the bottom with centred icons. */
        BOTTOM_CENTERED,
        /** Ubuntu: top panel plus a dock on the left. */
        TOP_PANEL_WITH_DOCK,
        /** Fedora (GNOME): top panel only, apps launched from an Activities menu. */
        TOP_PANEL_ONLY,
        /** Arch (tiling WM): thin top bar with workspace numbers, windows auto-tiled. */
        TOP_BAR_TILING
    }

    public enum StartStyle { AERO_ORB, WIN10_LOGO, WIN11_LOGO, ACTIVITIES, WORKSPACES }

    public enum ButtonStyle {
        /** Min / max as glass buttons and a red close button (Windows 7). */
        AERO,
        /** Flat minimise / maximise / close glyphs at the right edge. */
        FLAT,
        /** Single round close button at the right (Yaru / Adwaita). */
        ROUND_CLOSE,
        /** No decoration buttons, title text only (tiling WM). */
        NONE
    }

    public boolean topBar() {
        return layout == Layout.TOP_PANEL_WITH_DOCK || layout == Layout.TOP_PANEL_ONLY || layout == Layout.TOP_BAR_TILING;
    }

    public boolean hasDock() {
        return layout == Layout.TOP_PANEL_WITH_DOCK;
    }
}
