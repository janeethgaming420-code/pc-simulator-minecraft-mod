package com.pcsimulator.vpc.sim;

import com.pcsimulator.vpc.sim.OsTheme.ButtonStyle;
import com.pcsimulator.vpc.sim.OsTheme.Layout;
import com.pcsimulator.vpc.sim.OsTheme.StartStyle;

import java.util.EnumMap;
import java.util.Map;

/** The six built-in skins. Visual simulations only - none of this is real OS artwork or code. */
public final class OsThemes {
    private OsThemes() {}

    private static final Map<OsType, OsTheme> THEMES = new EnumMap<>(OsType.class);

    static {
        // Windows 7: Aero glass, blue taskbar with a round orb, red close button.
        THEMES.put(OsType.WINDOWS_7, new OsTheme(OsType.WINDOWS_7, Layout.BOTTOM_LEFT, StartStyle.AERO_ORB, ButtonStyle.AERO,
                0xFF1E6FB8, 0xFF0B3A6E,
                0xFF4B7EB5, 0xFF1B3D63, 0xFFFFFFFF, 0xFF3C9BE8,
                0xFF6FA3D6, 0xFF9DB9D6, 0xFF0A1F33, 0xFFF0F4FA, 0xFF101820, 0xFF2B4D73,
                20, 0, 14, 2, 0, true, false, false));
        // Windows 10: flat dark taskbar, 4-pane logo, light flat windows.
        THEMES.put(OsType.WINDOWS_10, new OsTheme(OsType.WINDOWS_10, Layout.BOTTOM_LEFT, StartStyle.WIN10_LOGO, ButtonStyle.FLAT,
                0xFF0F5FA8, 0xFF08254A,
                0xFF101216, 0xFF101216, 0xFFFFFFFF, 0xFF0078D7,
                0xFFFFFFFF, 0xFFE6E6E6, 0xFF000000, 0xFFFFFFFF, 0xFF1A1A1A, 0xFF0078D7,
                18, 0, 14, 0, 0, false, false, false));
        // Windows 11: centred rounded taskbar icons, rounded windows, soft light/dark mix.
        THEMES.put(OsType.WINDOWS_11, new OsTheme(OsType.WINDOWS_11, Layout.BOTTOM_CENTERED, StartStyle.WIN11_LOGO, ButtonStyle.FLAT,
                0xFF3A7BD5, 0xFF7C4DFF,
                0xFFEDEFF5, 0xFFE3E6EE, 0xFF1B1B1B, 0xFF005FB8,
                0xFFF3F3F6, 0xFFEAEAEE, 0xFF1B1B1B, 0xFFFAFAFC, 0xFF1B1B1B, 0xFFC8CCD6,
                20, 0, 14, 3, 0, false, false, true));
        // Ubuntu: aubergine/orange, top panel + left dock, dark Yaru titlebars.
        THEMES.put(OsType.UBUNTU, new OsTheme(OsType.UBUNTU, Layout.TOP_PANEL_WITH_DOCK, StartStyle.ACTIVITIES, ButtonStyle.ROUND_CLOSE,
                0xFF5E2750, 0xFF2C001E,
                0xFF1C1C1C, 0xFF1C1C1C, 0xFFEEEEEE, 0xFFE95420,
                0xFF3D3D3D, 0xFF2C2C2C, 0xFFEEEEEE, 0xFF2F2F2F, 0xFFEEEEEE, 0xFF1C1C1C,
                12, 24, 13, 2, 0, false, false, true));
        // Fedora (GNOME/Adwaita): blue, top panel only, light Adwaita titlebars.
        THEMES.put(OsType.FEDORA, new OsTheme(OsType.FEDORA, Layout.TOP_PANEL_ONLY, StartStyle.ACTIVITIES, ButtonStyle.ROUND_CLOSE,
                0xFF294172, 0xFF0B1E3F,
                0xFF000000, 0xFF000000, 0xFFFFFFFF, 0xFF3584E4,
                0xFFEBEBEB, 0xFFFAFAFA, 0xFF2E3436, 0xFFFAFAFA, 0xFF2E3436, 0xFFCDCDCD,
                12, 0, 14, 3, 0, false, false, true));
        // Arch (tiling WM): near-black, cyan borders, thin bar with workspace numbers, auto-tiled windows.
        THEMES.put(OsType.ARCH, new OsTheme(OsType.ARCH, Layout.TOP_BAR_TILING, StartStyle.WORKSPACES, ButtonStyle.NONE,
                0xFF14161B, 0xFF0B0C0F,
                0xFF0F1115, 0xFF0F1115, 0xFFC5C8C6, 0xFF1793D1,
                0xFF1793D1, 0xFF30343B, 0xFF0B0C0F, 0xFF16181D, 0xFFC5C8C6, 0xFF1793D1,
                11, 0, 9, 0, 3, false, true, false));
    }

    public static OsTheme of(OsType os) {
        return THEMES.get(os);
    }
}
