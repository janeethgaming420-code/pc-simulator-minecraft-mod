package com.pcsimulator.vpc.client;

import com.pcsimulator.vpc.sim.AppId;
import com.pcsimulator.vpc.sim.DesktopGeometry;
import com.pcsimulator.vpc.sim.DesktopGeometry.Geo;
import com.pcsimulator.vpc.sim.DesktopGeometry.WinGeo;
import com.pcsimulator.vpc.sim.NicKind;
import com.pcsimulator.vpc.sim.OsTheme;
import com.pcsimulator.vpc.sim.OsTheme.ButtonStyle;
import com.pcsimulator.vpc.sim.OsType;
import com.pcsimulator.vpc.sim.RenderQuality;
import com.pcsimulator.vpc.sim.VirtualClock;
import com.pcsimulator.vpc.sim.VpcSnapshot;
import com.pcsimulator.vpc.sim.WindowLayout.Rect;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Draws a virtual desktop with flat fills and text only (no textures, no extra GL state), driven by an
 * {@link OsTheme}. Detail levels: LOW = flat fills; MEDIUM = + gradients and chrome detail; HIGH = + shadows,
 * hover highlights and the open-window fade. Animation timing uses {@link VirtualClock} (game ticks quantised to
 * the virtual PC's own frame rate), so it does not follow the viewer's real FPS.
 *
 * <p>Icons are plain generic shapes; no official OS logos, wallpapers or fonts are reproduced.
 */
final class DesktopRenderer {
    private static final int[] APP_COLORS = {0xFF4C8BF5, 0xFFF7931A, 0xFF8E8E93, 0xFF2D2D2D}; // chrome, btc, settings, terminal
    private static final String[] APP_LETTER = {"C", "B", "S", ">"};
    private final Map<String, String> cache = new HashMap<>();
    private Font font;
    private GuiGraphics g;
    private RenderQuality q;

    private String tr(String key) {
        return cache.computeIfAbsent(key, k -> Component.translatable(k).getString());
    }

    private String tr(String key, Object... args) {
        return Component.translatable(key, args).getString();
    }

    void render(GuiGraphics g, Font font, OsTheme th, VpcSnapshot s, Geo geo, RenderQuality q,
                long gameTime, float pt, int mx, int my, boolean menuOpen, String clock) {
        this.g = g;
        this.font = font;
        this.q = q;
        Rect m = geo.monitor();
        g.fill(m.x() - 3, m.y() - 3, m.right() + 3, m.bottom() + 3, 0xFF1A1A1E); // bezel
        switch (s.power()) {
            case OFF -> drawOff(m, s, mx, my);
            case BOOTING -> drawBoot(m, th, s, gameTime, pt, true);
            case SHUTTING_DOWN -> drawBoot(m, th, s, gameTime, pt, false);
            case RUNNING -> drawDesktop(th, s, geo, gameTime, pt, mx, my, menuOpen, clock);
        }
    }

    // ---- helpers ----------------------------------------------------------------------------------------
    private void fill(Rect r, int c) {
        g.fill(r.x(), r.y(), r.right(), r.bottom(), c);
    }

    private void vfill(Rect r, int top, int bottom) {
        if (q == RenderQuality.LOW || top == bottom) g.fill(r.x(), r.y(), r.right(), r.bottom(), top);
        else g.fillGradient(r.x(), r.y(), r.right(), r.bottom(), top, bottom);
    }

    private void rounded(Rect r, int cut, int c) {
        if (cut <= 0 || q == RenderQuality.LOW) { fill(r, c); return; }
        g.fill(r.x() + cut, r.y(), r.right() - cut, r.bottom(), c);
        g.fill(r.x(), r.y() + cut, r.right(), r.bottom() - cut, c);
    }

    private void text(String s, int x, int y, int color) {
        g.drawString(font, s, x, y, color, false);
    }

    private void clipped(String s, Rect box, int x, int y, int color) {
        g.drawString(font, font.plainSubstrByWidth(s, Math.max(0, box.right() - x - 2)), x, y, color, false);
    }

    private void centered(String s, Rect r, int y, int color) {
        g.drawString(font, s, r.x() + (r.w() - font.width(s)) / 2, y, color, false);
    }

    private boolean hover(Rect r, int mx, int my) {
        return q == RenderQuality.HIGH && r.contains(mx, my);
    }

    private void glow(Rect r) {
        fill(r, 0x33FFFFFF);
    }

    // ---- power-off / boot -------------------------------------------------------------------------------
    private void drawOff(Rect m, VpcSnapshot s, int mx, int my) {
        fill(m, 0xFF050506);
        text(tr("pcsimulator.vpc.off.title"), m.x() + 8, m.y() + 8, 0xFF9AA0A6);
        OsType[] oss = OsType.values();
        for (int i = 0; i < oss.length; i++) {
            Rect r = DesktopGeometry.osButton(m, i);
            boolean sel = oss[i] == s.os();
            fill(r, sel ? 0xFF2D5BA8 : 0xFF1E2026);
            if (hover(r, mx, my) && !sel) glow(r);
            clipped(tr(oss[i].langKey()), r, r.x() + 4, r.y() + 3, sel ? 0xFFFFFFFF : 0xFFB8BCC4);
        }
        Rect p = DesktopGeometry.powerButton(m);
        rounded(p, 3, 0xFF1F8F4E);
        if (hover(p, mx, my)) glow(p);
        centered("I/O", p, p.y() + 8, 0xFFFFFFFF);
        centered(tr("pcsimulator.vpc.off.power"), new Rect(p.x() - 20, p.y(), p.w() + 40, p.h()), p.bottom() + 4, 0xFFB8BCC4);

        int x = m.x() + 104, y = m.y() + 22;
        text(tr("pcsimulator.vpc.info.cpu", s.cpuLabel(), s.cpu()), x, y, 0xFF8A8F98);
        text(tr("pcsimulator.vpc.info.gpu", s.integratedGpu() ? tr("pcsimulator.vpc.info.integrated") : s.gpuLabel(), s.gpu()), x, y + 11, 0xFF8A8F98);
        text(tr("pcsimulator.vpc.info.ram", s.ramGb()), x, y + 22, 0xFF8A8F98);
        text(tr("pcsimulator.vpc.info.perf", s.overall(), tr(perfKey(s.overall()))), x, y + 33, 0xFF8A8F98);
        if (s.blocker() != null) {
            text(tr(s.blocker().langKey(), tr(s.os().langKey())), m.x() + 8, m.bottom() - 14, 0xFFE5484D);
        }
    }

    private static String perfKey(int overall) {
        return "pcsimulator.vpc.perf." + (overall >= 80 ? "ultra" : overall >= 55 ? "high" : overall >= 30 ? "mid" : "low");
    }

    private void drawBoot(Rect m, OsTheme th, VpcSnapshot s, long gameTime, float pt, boolean booting) {
        fill(m, th.os().family == OsType.Family.WINDOWS ? 0xFF000000 : 0xFF0B0B0D);
        double p = VirtualClock.progress(s.phaseStart(), s.phaseEnd(), gameTime, pt, s.virtualFps());
        if (!booting) p = 1.0 - p;
        int cy = m.y() + m.h() / 2;
        if (th.os().family == OsType.Family.WINDOWS) {
            centered(tr(th.os().langKey()), m, cy - 20, 0xFFFFFFFF);
            int dots = (int) ((VirtualClock.quantize(VirtualClock.seconds(gameTime, pt), s.virtualFps()) * 2) % 4);
            centered(tr(booting ? "pcsimulator.vpc.boot.starting" : "pcsimulator.vpc.boot.stopping") + ".".repeat(dots), m, cy - 6, 0xFFB8BCC4);
        } else {
            String[] lines = {"Starting kernel", "Mounting filesystems", "Starting network", "Starting display manager", "Reached target graphical"};
            int shown = Math.max(1, (int) Math.ceil(p * lines.length));
            for (int i = 0; i < shown && i < lines.length; i++) {
                text("[  OK  ] " + lines[i], m.x() + 8, m.y() + 8 + i * 10, 0xFF6EE7A0);
            }
            centered(tr(th.os().langKey()), m, m.bottom() - 40, 0xFFFFFFFF);
        }
        Rect bar = new Rect(m.x() + m.w() / 2 - 50, cy + 12, 100, 5);
        fill(bar, 0xFF2A2C31);
        fill(new Rect(bar.x(), bar.y(), (int) Math.round(bar.w() * p), bar.h()), th.accent());
    }

    // ---- desktop ----------------------------------------------------------------------------------------
    private void drawDesktop(OsTheme th, VpcSnapshot s, Geo geo, long gameTime, float pt, int mx, int my,
                             boolean menuOpen, String clock) {
        Rect m = geo.monitor();
        vfill(m, th.wallpaperTop(), th.wallpaperBottom());
        drawWallpaperDetail(th, m);
        int n = geo.windows().size();
        for (int i = 0; i < n; i++) {
            drawWindow(th, s, geo.windows().get(i), i == n - 1, gameTime, pt, mx, my);
        }
        drawBar(th, s, geo, mx, my, clock);
        if (menuOpen) drawMenu(th, geo, mx, my);
    }

    private void drawWallpaperDetail(OsTheme th, Rect m) {
        if (q == RenderQuality.LOW) return;
        int cx = m.x() + m.w() * 3 / 4, cy = m.y() + m.h() / 2;
        switch (th.os()) {
            case WINDOWS_7 -> { // soft light sweeps
                g.fill(cx - 90, cy - 30, cx + 50, cy - 24, 0x22FFFFFF);
                g.fill(cx - 70, cy - 10, cx + 70, cy - 2, 0x18FFFFFF);
            }
            case WINDOWS_10 -> { // four light panes (generic shapes)
                for (int dx = 0; dx < 2; dx++) for (int dy = 0; dy < 2; dy++)
                    g.fill(cx - 22 + dx * 23, cy - 22 + dy * 23, cx + dx * 23, cy + dy * 23 - 1, 0x2AFFFFFF);
            }
            case WINDOWS_11 -> { // layered bloom
                g.fill(cx - 40, cy - 28, cx + 40, cy + 28, 0x14FFFFFF);
                g.fill(cx - 24, cy - 16, cx + 24, cy + 16, 0x18FFFFFF);
            }
            case UBUNTU -> g.fill(m.x() + m.w() / 2, m.y() + m.h() - 50, m.right() - 20, m.bottom() - 20, 0x15E95420);
            case FEDORA -> g.fill(cx - 36, cy - 20, cx + 36, cy + 20, 0x1A3584E4);
            case ARCH -> g.fill(m.x() + m.w() / 2 - 1, m.y() + 20, m.x() + m.w() / 2 + 1, m.bottom() - 20, 0x201793D1);
        }
    }

    private void drawBar(OsTheme th, VpcSnapshot s, Geo geo, int mx, int my, String clock) {
        Rect bar = geo.bar();
        vfill(bar, th.barTop(), th.barBottom());
        if (q != RenderQuality.LOW && th.glass()) g.fill(bar.x(), bar.y(), bar.right(), bar.y() + 1, 0x66FFFFFF);
        if (geo.dock() != null) {
            fill(geo.dock(), 0xE61C1C1C);
        }
        // start / activities / workspaces
        Rect st = geo.start();
        switch (th.start()) {
            case AERO_ORB -> {
                rounded(st, 3, 0xFF2E7BC4);
                g.fill(st.x() + 5, st.y() + 5, st.x() + 9, st.y() + 9, 0xFFE5484D);
                g.fill(st.x() + 10, st.y() + 5, st.x() + 14, st.y() + 9, 0xFF3DDC84);
                g.fill(st.x() + 5, st.y() + 10, st.x() + 9, st.y() + 14, 0xFF4C8BF5);
                g.fill(st.x() + 10, st.y() + 10, st.x() + 14, st.y() + 14, 0xFFFFD84A);
            }
            case WIN10_LOGO, WIN11_LOGO -> {
                int c = th.start() == OsTheme.StartStyle.WIN10_LOGO ? 0xFFFFFFFF : th.accent();
                int x = st.x() + 4, y = st.y() + 4, a = Math.max(3, (st.w() - 10) / 2);
                g.fill(x, y, x + a, y + a, c);
                g.fill(x + a + 1, y, x + 2 * a + 1, y + a, c);
                g.fill(x, y + a + 1, x + a, y + 2 * a + 1, c);
                g.fill(x + a + 1, y + a + 1, x + 2 * a + 1, y + 2 * a + 1, c);
            }
            case ACTIVITIES -> text(tr("pcsimulator.vpc.ui.activities"), st.x() + 3, st.y() + 2, th.barText());
            case WORKSPACES -> {
                for (int i = 0; i < 5; i++) {
                    Rect w = new Rect(st.x() + i * 11, st.y(), 11, st.h());
                    if (i == 0) fill(w, th.accent());
                    text(String.valueOf(i + 1), w.x() + 3, w.y() + 1, i == 0 ? 0xFF0B0C0F : th.barText());
                }
            }
        }
        if (hover(st, mx, my)) glow(st);

        // pinned apps (taskbar or dock)
        for (DesktopGeometry.AppButton b : geo.apps()) {
            Rect r = b.rect();
            boolean open = false;
            for (VpcSnapshot.WindowView w : s.windows()) open |= w.app() == b.app();
            int idx = b.app().ordinal();
            rounded(r, th.cornerCut() > 0 ? 2 : 0, APP_COLORS[idx]);
            text(APP_LETTER[idx], r.x() + (r.w() - font.width(APP_LETTER[idx])) / 2, r.y() + (r.h() - 8) / 2 + 1, 0xFFFFFFFF);
            if (open) {
                if (geo.dock() != null) g.fill(r.x() - 3, r.y() + r.h() / 2 - 1, r.x() - 1, r.y() + r.h() / 2 + 1, th.accent());
                else g.fill(r.x() + 1, r.bottom(), r.right() - 1, r.bottom() + 1, th.accent());
            }
            if (hover(r, mx, my)) glow(r);
        }

        // tray: E = Ethernet, W = Wi-Fi.  green = carrying traffic, amber = switched on but no link, grey = off
        drawTray(geo.ethTray(), "E", s.ethernetPlugged(), s.online() && s.link() == NicKind.ETHERNET, th, mx, my);
        drawTray(geo.wifiTray(), "W", s.wifiJoined(), s.online() && s.link() == NicKind.WIFI, th, mx, my);
        Rect ck = geo.clock();
        text(clock, ck.x() + (ck.w() - font.width(clock)) / 2, ck.y() + (ck.h() - 8) / 2 + 1, th.barText());
    }

    private void drawTray(Rect r, String letter, boolean enabled, boolean active, OsTheme th, int mx, int my) {
        int c = active ? 0xFF3DDC84 : enabled ? 0xFFFFB020 : 0xFF6B7078;
        text(letter, r.x() + (r.w() - font.width(letter)) / 2, r.y() + (r.h() - 8) / 2 + 1, c);
        if (hover(r, mx, my)) glow(r);
    }

    private void drawMenu(OsTheme th, Geo geo, int mx, int my) {
        Rect menu = geo.menu();
        if (q == RenderQuality.HIGH) g.fill(menu.x() + 2, menu.y() + 2, menu.right() + 2, menu.bottom() + 2, 0x55000000);
        boolean dark = brightness(th.windowBody()) < 128;
        fill(menu, dark ? 0xF0202226 : 0xF0F4F5F8);
        int fg = dark ? 0xFFEDEDED : 0xFF1A1A1A;
        AppId[] apps = AppId.values();
        for (int i = 0; i < geo.menuItems().size(); i++) {
            Rect r = geo.menuItems().get(i);
            if (r.contains(mx, my)) fill(r, (th.accent() & 0x00FFFFFF) | 0x55000000);
            String label = i < apps.length ? tr(apps[i].langKey()) : tr("pcsimulator.vpc.ui.shutdown");
            text(label, r.x() + 4, r.y() + 2, i < apps.length ? fg : 0xFFE5484D);
        }
    }

    private static int brightness(int argb) {
        return (((argb >> 16) & 255) * 3 + ((argb >> 8) & 255) * 6 + (argb & 255)) / 10;
    }

    // ---- windows ----------------------------------------------------------------------------------------
    private void drawWindow(OsTheme th, VpcSnapshot s, WinGeo w, boolean focused, long gameTime, float pt, int mx, int my) {
        Rect f = w.frame();
        if (q == RenderQuality.HIGH) g.fill(f.x() + 2, f.y() + 3, f.right() + 3, f.bottom() + 3, focused ? 0x66000000 : 0x33000000);
        int bw = th.os() == OsType.WINDOWS_7 && q != RenderQuality.LOW ? 2 : 1;
        g.fill(f.x() - bw, f.y() - bw, f.right() + bw, f.bottom() + bw, focused ? th.windowBorder() : th.titleInactive());
        rounded(new Rect(f.x(), f.y(), f.w(), f.h()), th.cornerCut(), th.windowBody());
        int tc = focused ? th.titleActive() : th.titleInactive();
        Rect t = w.title();
        if (th.glass()) vfill(t, tc, tc & 0xFFE0E8F4); else fill(t, tc);
        String title = tr(w.app().langKey());
        if (th.buttons() == ButtonStyle.NONE) title = "[" + (s.windows().size()) + "] " + title.toLowerCase();
        int tx = th.buttons() == ButtonStyle.ROUND_CLOSE && th.os() == OsType.FEDORA ? t.x() + (t.w() - font.width(title)) / 2 : t.x() + 4;
        clipped(title, t, tx, t.y() + (t.h() - 8) / 2 + 1, th.titleText());
        drawButtons(th, w, mx, my);

        VpcSnapshot.WindowView v = null;
        for (VpcSnapshot.WindowView x : s.windows()) if (x.id() == w.id()) v = x;
        if (v != null && gameTime < v.readyAt()) {
            double p = VirtualClock.progress(v.openedAt(), v.readyAt(), gameTime, pt, s.virtualFps());
            Rect c = w.content();
            centered(tr("pcsimulator.vpc.ui.loading"), c, c.y() + c.h() / 2 - 12, th.windowText());
            Rect bar = new Rect(c.x() + c.w() / 2 - 30, c.y() + c.h() / 2, 60, 4);
            fill(bar, 0x33808080);
            fill(new Rect(bar.x(), bar.y(), (int) Math.round(bar.w() * p), bar.h()), th.accent());
        } else {
            drawApp(th, s, w);
        }
    }

    private void drawButtons(OsTheme th, WinGeo w, int mx, int my) {
        Rect c = w.close();
        switch (th.buttons()) {
            case AERO -> {
                fill(c, 0xFFC74B3A);
                text("x", c.x() + 8, c.y() + 2, 0xFFFFFFFF);
                fill(new Rect(c.x() - 24, c.y(), 11, c.h()), 0x99FFFFFF);
                fill(new Rect(c.x() - 12, c.y(), 11, c.h()), 0x99FFFFFF);
            }
            case FLAT -> {
                text("-", c.x() - 22, c.y() + 3, th.titleText());
                text("o", c.x() - 11, c.y() + 3, th.titleText());
                if (hover(c, mx, my)) fill(c, 0xFFE81123);
                text("x", c.x() + 5, c.y() + 3, hover(c, mx, my) ? 0xFFFFFFFF : th.titleText());
            }
            case ROUND_CLOSE -> {
                rounded(c, 2, th.os() == OsType.UBUNTU ? 0xFFE95420 : 0xFFD0D0D0);
                text("x", c.x() + (c.w() - 5) / 2, c.y() + (c.h() - 8) / 2 + 1, th.os() == OsType.UBUNTU ? 0xFFFFFFFF : 0xFF2E3436);
            }
            case NONE -> text("x", c.x() + 2, c.y() + 1, 0xFF0B0C0F);
        }
    }

    private void drawApp(OsTheme th, VpcSnapshot s, WinGeo w) {
        Rect c = w.content();
        int fg = th.windowText();
        switch (w.app()) {
            case CHROME -> {
                fill(new Rect(c.x(), c.y(), c.w(), 13), 0xFFE8EAED);
                Rect url = new Rect(c.x() + 18, c.y() + 2, c.w() - 24, 9);
                fill(url, 0xFFFFFFFF);
                clipped("https://search.example", url, url.x() + 3, url.y() + 1, 0xFF3C4043);
                text("<", c.x() + 4, c.y() + 3, 0xFF5F6368);
                fill(new Rect(c.x(), c.y() + 13, c.w(), c.h() - 13), 0xFFFFFFFF);
                centered(tr("pcsimulator.vpc.chrome.search"), c, c.y() + 28, 0xFF202124);
                Rect box = new Rect(c.x() + c.w() / 2 - 40, c.y() + 42, 80, 10);
                fill(box, 0xFFF1F3F4);
                String link = s.link() == NicKind.WIFI ? "Wi-Fi" : "Ethernet";
                clipped(tr("pcsimulator.vpc.chrome.online", link, s.mbps()), c, c.x() + 4, c.bottom() - 11, 0xFF5F6368);
            }
            case BTC_SHOP -> {
                text(tr("pcsimulator.vpc.shop.title"), c.x() + 6, c.y() + 6, fg);
                text(tr("pcsimulator.vpc.shop.offline_ok"), c.x() + 6, c.y() + 16, th.accent());
                Rect b = DesktopGeometry.shopButton(c);
                rounded(b, 2, th.accent());
                centered(tr("pcsimulator.vpc.shop.open"), b, b.y() + 3, 0xFFFFFFFF);
            }
            case SETTINGS -> {
                int y = c.y() + 4;
                String[] lines = {
                        tr(s.os().langKey()),
                        tr("pcsimulator.vpc.info.cpu", s.cpuLabel(), s.cpu()),
                        tr("pcsimulator.vpc.info.gpu", s.integratedGpu() ? tr("pcsimulator.vpc.info.integrated") : s.gpuLabel(), s.gpu()),
                        tr("pcsimulator.vpc.info.ram", s.ramGb()),
                        tr("pcsimulator.vpc.info.perf", s.overall(), tr(perfKey(s.overall()))),
                        tr("pcsimulator.vpc.info.net", s.online() ? tr("pcsimulator.vpc.net.connected") + " " + s.mbps() + " Mbps"
                                : tr(s.netReasonKey()))};
                for (String l : lines) { clipped(l, c, c.x() + 6, y, fg); y += 10; }
                toggle(DesktopGeometry.settingsWifiToggle(c), "Wi-Fi", s.wifiJoined(), s.hasWifiNic(), th);
                toggle(DesktopGeometry.settingsEthToggle(c), "LAN", s.ethernetPlugged(), s.hasEthernetNic(), th);
            }
            case TERMINAL -> {
                fill(c, 0xFF0C0C0C);
                boolean win = s.os().family == OsType.Family.WINDOWS;
                String prompt = win ? "C:\\Users\\player>" : "player@pc:~$";
                int y = c.y() + 3;
                text(prompt + (win ? " systeminfo" : " neofetch"), c.x() + 4, y, 0xFFCCCCCC);
                clipped("OS: " + tr(s.os().langKey()), c, c.x() + 4, y + 10, 0xFF6EE7A0);
                clipped("CPU: " + s.cpuLabel(), c, c.x() + 4, y + 20, 0xFF6EE7A0);
                clipped("GPU: " + (s.integratedGpu() ? "integrated" : s.gpuLabel()), c, c.x() + 4, y + 30, 0xFF6EE7A0);
                clipped("RAM: " + s.ramGb() + " GB", c, c.x() + 4, y + 40, 0xFF6EE7A0);
                text(prompt + " _", c.x() + 4, y + 52, 0xFFCCCCCC);
            }
        }
    }

    private void toggle(Rect r, String name, boolean on, boolean hasNic, OsTheme th) {
        int bg = !hasNic ? 0xFF8A8F98 : on ? th.accent() : 0xFF5F6368;
        rounded(r, 2, bg);
        String label = name + ": " + (!hasNic ? tr("pcsimulator.vpc.ui.no_adapter") : on ? "ON" : "OFF");
        g.drawString(font, font.plainSubstrByWidth(label, r.w() - 2), r.x() + 3, r.y() + 2, 0xFFFFFFFF, false);
    }
}
