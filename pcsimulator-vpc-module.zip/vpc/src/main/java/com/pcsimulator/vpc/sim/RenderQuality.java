package com.pcsimulator.vpc.sim;

/** How much visual detail the CLIENT draws for a virtual desktop. Never affects virtual speed. */
public enum RenderQuality {
    /** Flat fills only, no gradients, no shadows, no animation. Cheapest possible. */
    LOW,
    /** Gradients and window chrome details, no shadows or animation. */
    MEDIUM,
    /** Gradients, shadows, hover/open animations. */
    HIGH;

    public RenderQuality min(RenderQuality o) {
        return ordinal() <= o.ordinal() ? this : o;
    }

    public RenderQuality lower() {
        return this == HIGH ? MEDIUM : LOW;
    }

    public RenderQuality higher() {
        return this == LOW ? MEDIUM : HIGH;
    }

    public static RenderQuality byOrdinal(int i) {
        RenderQuality[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
