package com.pcsimulator.vpc.sim;

/**
 * CLIENT-side render budget. The viewer's own machine decides how much detail it draws:
 * {@code effective = min(viewer's configured maximum, what the virtual PC supports, adaptive level)}.
 * A weak client watching a high-end virtual PC therefore degrades gracefully instead of being forced to render
 * at the virtual PC's quality, and the virtual PC's simulated speed is unaffected (that is server tick based).
 *
 * <p>Feed it the real frame delta of the screen while it is open. Hysteresis avoids flip-flopping.
 */
public final class AdaptiveQuality {
    private static final double ALPHA = 0.1;
    private static final long MAX_SAMPLE_NANOS = 250_000_000L; // ignore stalls (alt-tab, chunk loads)
    private final double targetMs;
    private final int slowFramesToDrop;
    private final int fastFramesToRaise;

    private double emaMs;
    private int slow;
    private int fast;
    private RenderQuality adaptive = RenderQuality.HIGH;

    public AdaptiveQuality(int targetFps) {
        this(targetFps, 30, 180);
    }

    public AdaptiveQuality(int targetFps, int slowFramesToDrop, int fastFramesToRaise) {
        this.targetMs = 1000.0 / Math.max(10, targetFps);
        this.slowFramesToDrop = slowFramesToDrop;
        this.fastFramesToRaise = fastFramesToRaise;
        this.emaMs = targetMs;
    }

    public void onFrame(long frameNanos) {
        if (frameNanos <= 0) return;
        double ms = Math.min(frameNanos, MAX_SAMPLE_NANOS) / 1_000_000.0;
        emaMs += (ms - emaMs) * ALPHA;
        if (emaMs > targetMs * 1.25) {
            slow++;
            fast = 0;
            if (slow >= slowFramesToDrop && adaptive != RenderQuality.LOW) {
                adaptive = adaptive.lower();
                slow = 0;
                emaMs = targetMs; // re-measure at the new level
            }
        } else if (emaMs < targetMs * 0.8) {
            fast++;
            slow = 0;
            if (fast >= fastFramesToRaise && adaptive != RenderQuality.HIGH) {
                adaptive = adaptive.higher();
                fast = 0;
            }
        } else {
            slow = 0;
            fast = 0;
        }
    }

    public RenderQuality adaptiveLevel() {
        return adaptive;
    }

    /** @param userMax viewer's configured ceiling; @param pcCap what the virtual PC supports */
    public RenderQuality effective(RenderQuality userMax, RenderQuality pcCap) {
        return userMax.min(pcCap).min(adaptive);
    }
}
