package com.pcsimulator.vpc.sim;

public enum PowerState {
    OFF, BOOTING, RUNNING, SHUTTING_DOWN;

    public static PowerState byOrdinal(int i) {
        PowerState[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
