package com.pcsimulator.vpc.sim;

/** Window placement inside the virtual desktop area. Pure geometry, tested without Minecraft. */
public final class WindowLayout {
    private WindowLayout() {}

    /** x, y, w, h (inclusive of title bar) in the same coordinate space as the work area. */
    public record Rect(int x, int y, int w, int h) {
        public boolean contains(double px, double py) {
            return px >= x && px < x + w && py >= y && py < y + h;
        }

        public int right() { return x + w; }

        public int bottom() { return y + h; }
    }

    /**
     * @param index 0-based z-order index among {@code count} windows
     * @param area  work area (desktop minus bars)
     */
    public static Rect place(OsTheme theme, int index, int count, Rect area) {
        if (theme.tiled()) return tile(index, count, area, theme.windowGap());
        // Cascade: each window offset by 12 px, 62% x 70% of the area.
        int w = area.w() * 62 / 100;
        int h = area.h() * 70 / 100;
        int off = (index % 6) * 12;
        int x = area.x() + 10 + off;
        int y = area.y() + 8 + off;
        x = Math.min(x, area.x() + area.w() - w);
        y = Math.min(y, area.y() + area.h() - h);
        return new Rect(x, y, w, h);
    }

    /** Classic master/stack tiling: first window left half, the rest stacked on the right. */
    static Rect tile(int index, int count, Rect a, int gap) {
        if (count <= 1) return new Rect(a.x() + gap, a.y() + gap, a.w() - 2 * gap, a.h() - 2 * gap);
        int half = a.w() / 2;
        if (index == 0) return new Rect(a.x() + gap, a.y() + gap, half - gap - gap / 2, a.h() - 2 * gap);
        int stack = count - 1;
        int each = (a.h() - gap) / stack;
        int i = index - 1;
        return new Rect(a.x() + half + gap / 2, a.y() + gap + i * each, a.w() - half - gap - gap / 2, each - gap);
    }
}
