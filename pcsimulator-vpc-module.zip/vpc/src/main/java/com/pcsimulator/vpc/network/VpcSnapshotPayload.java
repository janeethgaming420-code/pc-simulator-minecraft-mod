package com.pcsimulator.vpc.network;

import com.pcsimulator.api.PCSimulatorAPI;
import com.pcsimulator.vpc.sim.AppId;
import com.pcsimulator.vpc.sim.OsType;
import com.pcsimulator.vpc.sim.PowerState;
import com.pcsimulator.vpc.sim.RenderQuality;
import com.pcsimulator.vpc.sim.VpcSnapshot;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.ArrayList;
import java.util.List;

/**
 * Server -> client: full state of one virtual PC (a few hundred bytes). Sent only when the state changed or a
 * screen is opened; progress animations run on the client from absolute tick timestamps.
 */
public record VpcSnapshotPayload(BlockPos pos, boolean openScreen, VpcSnapshot snapshot) implements CustomPacketPayload {
    public static final Type<VpcSnapshotPayload> TYPE = new Type<>(PCSimulatorAPI.id("vpc/snapshot"));
    private static final int MAX_WINDOWS = 64;
    private static final int MAX_STR = 64;

    public static final StreamCodec<FriendlyByteBuf, VpcSnapshotPayload> STREAM_CODEC = new StreamCodec<>() {
        @Override
        public VpcSnapshotPayload decode(FriendlyByteBuf b) {
            BlockPos pos = b.readBlockPos();
            boolean open = b.readBoolean();
            long gameTime = b.readVarLong();
            OsType os = OsType.byOrdinal(b.readVarInt());
            PowerState power = PowerState.byOrdinal(b.readVarInt());
            long ps = b.readVarLong();
            long pe = b.readVarLong();
            boolean wifi = b.readBoolean(), eth = b.readBoolean(), online = b.readBoolean();
            int link = b.readVarInt() - 1;
            int mbps = b.readVarInt();
            String reason = b.readUtf(MAX_STR);
            boolean hasWifi = b.readBoolean(), hasEth = b.readBoolean();
            int cpu = b.readVarInt(), gpu = b.readVarInt(), ram = b.readVarInt(), overall = b.readVarInt();
            int speed = b.readVarInt(), maxWin = b.readVarInt();
            RenderQuality cap = RenderQuality.byOrdinal(b.readVarInt());
            int vfps = b.readVarInt();
            boolean integ = b.readBoolean();
            int blocker = b.readVarInt() - 1;
            String cpuL = b.readUtf(MAX_STR), gpuL = b.readUtf(MAX_STR);
            int n = Math.min(b.readVarInt(), MAX_WINDOWS);
            List<VpcSnapshot.WindowView> ws = new ArrayList<>(n);
            for (int i = 0; i < n; i++) {
                ws.add(new VpcSnapshot.WindowView(b.readVarInt(), b.readVarInt(), b.readVarLong(), b.readVarLong()));
            }
            String notice = b.readUtf(MAX_STR);
            int seq = b.readVarInt();
            return new VpcSnapshotPayload(pos, open, new VpcSnapshot(gameTime, os, power, ps, pe, wifi, eth, online,
                    link, mbps, reason, hasWifi, hasEth, cpu, gpu, ram, overall, speed, maxWin, cap, vfps, integ,
                    blocker, cpuL, gpuL, ws, notice, seq));
        }

        @Override
        public void encode(FriendlyByteBuf b, VpcSnapshotPayload p) {
            VpcSnapshot s = p.snapshot();
            b.writeBlockPos(p.pos());
            b.writeBoolean(p.openScreen());
            b.writeVarLong(s.gameTime());
            b.writeVarInt(s.os().ordinal());
            b.writeVarInt(s.power().ordinal());
            b.writeVarLong(s.phaseStart());
            b.writeVarLong(s.phaseEnd());
            b.writeBoolean(s.wifiJoined());
            b.writeBoolean(s.ethernetPlugged());
            b.writeBoolean(s.online());
            b.writeVarInt(s.linkOrdinal() + 1);
            b.writeVarInt(s.mbps());
            b.writeUtf(s.netReasonKey(), MAX_STR);
            b.writeBoolean(s.hasWifiNic());
            b.writeBoolean(s.hasEthernetNic());
            b.writeVarInt(s.cpu());
            b.writeVarInt(s.gpu());
            b.writeVarInt(s.ramGb());
            b.writeVarInt(s.overall());
            b.writeVarInt(s.speedPercent());
            b.writeVarInt(s.maxWindows());
            b.writeVarInt(s.qualityCap().ordinal());
            b.writeVarInt(s.virtualFps());
            b.writeBoolean(s.integratedGpu());
            b.writeVarInt(s.blockerOrdinal() + 1);
            b.writeUtf(trim(s.cpuLabel()), MAX_STR);
            b.writeUtf(trim(s.gpuLabel()), MAX_STR);
            b.writeVarInt(Math.min(s.windows().size(), MAX_WINDOWS));
            int i = 0;
            for (VpcSnapshot.WindowView w : s.windows()) {
                if (i++ >= MAX_WINDOWS) break;
                b.writeVarInt(w.id());
                b.writeVarInt(w.appOrdinal());
                b.writeVarLong(w.openedAt());
                b.writeVarLong(w.readyAt());
            }
            b.writeUtf(s.noticeKey(), MAX_STR);
            b.writeVarInt(s.noticeSeq());
        }
    };

    private static String trim(String s) {
        return s.length() > MAX_STR ? s.substring(0, MAX_STR) : s;
    }

    /** Keeps {@link AppId} referenced so a future enum change is a compile error here, not a silent wire break. */
    static int appCount() {
        return AppId.values().length;
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
