package com.pcsimulator.vpc.sim;

import java.util.List;

/**
 * Minecraft-free summary of what a build contains. The Minecraft layer fills it from {@code IPCBuild}.
 * Scores are RAW catalogue scores (0 = unset); {@link PerformanceModel} normalises them.
 *
 * @param cpuScore  raw CPU score, or -1 if no CPU installed
 * @param cpuTier   tier ordinal of the CPU
 * @param gpuScore  raw GPU score, or -1 if no discrete GPU installed
 * @param gpuTier   tier ordinal of the GPU
 * @param ramGb     total installed RAM in GB (sum over modules)
 */
public record HardwareProfile(int cpuScore, int cpuTier, int gpuScore, int gpuTier, int ramGb, List<Nic> nics) {
    /** One installed network card. */
    public record Nic(NicKind kind, int tier) {}

    public HardwareProfile {
        nics = List.copyOf(nics);
    }

    public boolean hasCpu() {
        return cpuScore >= 0;
    }

    public boolean hasGpu() {
        return gpuScore >= 0;
    }

    public boolean hasNic(NicKind kind) {
        for (Nic n : nics) if (n.kind() == kind) return true;
        return false;
    }

    public static final HardwareProfile EMPTY = new HardwareProfile(-1, 0, -1, 0, 0, List.of());
}
