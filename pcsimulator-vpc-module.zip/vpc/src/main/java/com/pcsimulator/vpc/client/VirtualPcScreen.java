package com.pcsimulator.vpc.client;

import com.pcsimulator.core.network.PCNetwork;
import com.pcsimulator.vpc.VpcConfig;
import com.pcsimulator.vpc.network.VpcActionPayload;
import com.pcsimulator.vpc.network.VpcActionPayload.Action;
import com.pcsimulator.vpc.sim.AdaptiveQuality;
import com.pcsimulator.vpc.sim.AppId;
import com.pcsimulator.vpc.sim.DesktopGeometry;
import com.pcsimulator.vpc.sim.DesktopGeometry.Geo;
import com.pcsimulator.vpc.sim.DesktopGeometry.WinGeo;
import com.pcsimulator.vpc.sim.OsTheme;
import com.pcsimulator.vpc.sim.OsThemes;
import com.pcsimulator.vpc.sim.OsType;
import com.pcsimulator.vpc.sim.PowerState;
import com.pcsimulator.vpc.sim.RenderQuality;
import com.pcsimulator.vpc.sim.VpcSnapshot;
import com.pcsimulator.vpc.sim.WindowLayout.Rect;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The monitor. Purely a view + input forwarder: all state lives on the server and arrives as snapshots.
 * Rendering cost is chosen HERE from the viewer's own settings and real frame rate (see AdaptiveQuality), never
 * from the virtual PC's strength.
 */
public final class VirtualPcScreen extends Screen {
    private final BlockPos pos;
    private VpcSnapshot snap;
    private final AdaptiveQuality adaptive = new AdaptiveQuality(VpcConfig.CLIENT.targetFpsOr());
    private final DesktopRenderer renderer = new DesktopRenderer();
    private long lastFrameNanos;
    private boolean menuOpen;
    private Rect monitor = new Rect(0, 0, 320, 180);
    private int shownNoticeSeq;
    private String toast = "";
    private long toastUntilMs;

    public VirtualPcScreen(BlockPos pos, VpcSnapshot snap) {
        super(Component.translatable("pcsimulator.vpc.screen"));
        this.pos = pos;
        this.snap = snap;
        this.shownNoticeSeq = snap.noticeSeq();
    }

    public BlockPos pos() {
        return pos;
    }

    public void update(VpcSnapshot s) {
        if (s.noticeSeq() != shownNoticeSeq && !s.noticeKey().isEmpty()) {
            toast = Component.translatable(s.noticeKey()).getString();
            toastUntilMs = System.currentTimeMillis() + 4000;
        }
        shownNoticeSeq = s.noticeSeq();
        if (s.power() != PowerState.RUNNING) menuOpen = false;
        this.snap = s;
    }

    @Override
    protected void init() {
        int mw = Math.min(width - 16, (height - 28) * 16 / 9);
        int mh = mw * 9 / 16;
        monitor = new Rect((width - mw) / 2, (height - mh) / 2 - 4, mw, mh);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0xFF0A0A0C); // own, flat background: no blur, no vanilla panorama cost
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        long now = System.nanoTime();
        if (lastFrameNanos != 0) adaptive.onFrame(now - lastFrameNanos);
        lastFrameNanos = now;

        RenderQuality user = VpcConfig.CLIENT.maxQualityOr();
        RenderQuality q = VpcConfig.CLIENT.adaptiveOr()
                ? adaptive.effective(user, snap.qualityCap()) : user.min(snap.qualityCap());

        renderBackground(g, mouseX, mouseY, partialTick);
        OsTheme theme = OsThemes.of(snap.os());
        Geo geo = geometry(theme);
        long gameTime = Minecraft.getInstance().level == null ? snap.gameTime() : Minecraft.getInstance().level.getGameTime();
        renderer.render(g, font, theme, snap, geo, q, gameTime, partialTick, mouseX, mouseY, menuOpen, clockText());

        String footer = Component.translatable("pcsimulator.vpc.footer", snap.speedPercent(), q.name()).getString();
        g.drawString(font, footer, monitor.x(), monitor.bottom() + 6, 0xFF8A8F98, false);
        if (!toast.isEmpty() && System.currentTimeMillis() < toastUntilMs) {
            int tw = font.width(toast);
            g.fill(width / 2 - tw / 2 - 4, 4, width / 2 + tw / 2 + 4, 16, 0xE0000000);
            g.drawString(font, toast, width / 2 - tw / 2, 6, 0xFFFFD84A, false);
        }
    }

    private Geo geometry(OsTheme theme) {
        List<DesktopGeometry.WinRef> refs = new ArrayList<>(snap.windows().size());
        for (VpcSnapshot.WindowView w : snap.windows()) refs.add(new DesktopGeometry.WinRef(w.id(), w.app()));
        return DesktopGeometry.compute(theme, monitor, refs, menuOpen && snap.power() == PowerState.RUNNING);
    }

    private String clockText() {
        var level = Minecraft.getInstance().level;
        long t = level == null ? 0 : level.getDayTime();
        long hours = (t / 1000 + 6) % 24;
        long mins = (t % 1000) * 60 / 1000;
        return String.format("%02d:%02d", hours, mins);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        if (snap.power() == PowerState.OFF) return clickOff(mx, my);
        if (snap.power() != PowerState.RUNNING) return true;

        OsTheme theme = OsThemes.of(snap.os());
        Geo geo = geometry(theme);
        AppId[] apps = AppId.values();

        if (menuOpen) {
            for (int i = 0; i < geo.menuItems().size(); i++) {
                if (geo.menuItems().get(i).contains(mx, my)) {
                    if (i < apps.length) send(Action.OPEN_APP, apps[i].ordinal());
                    else send(Action.POWER_OFF, 0);
                    menuOpen = false;
                    return true;
                }
            }
            boolean onStart = geo.start().contains(mx, my);
            menuOpen = false;
            if (onStart) return true;
        } else if (geo.start().contains(mx, my)) {
            menuOpen = true;
            return true;
        }
        for (DesktopGeometry.AppButton b : geo.apps()) {
            if (b.rect().contains(mx, my)) {
                send(Action.OPEN_APP, b.app().ordinal());
                return true;
            }
        }
        if (geo.wifiTray().contains(mx, my)) { send(Action.SET_WIFI, snap.wifiJoined() ? 0 : 1); return true; }
        if (geo.ethTray().contains(mx, my)) { send(Action.SET_ETHERNET, snap.ethernetPlugged() ? 0 : 1); return true; }

        WinGeo w = DesktopGeometry.windowAt(geo, mx, my);
        if (w != null) {
            if (w.close().contains(mx, my)) { send(Action.CLOSE_WINDOW, w.id()); return true; }
            boolean isTop = geo.windows().get(geo.windows().size() - 1).id() == w.id();
            if (!isTop) send(Action.FOCUS_WINDOW, w.id());
            if (isReady(w.id())) contentClick(w, mx, my);
            return true;
        }
        return true;
    }

    private void contentClick(WinGeo w, double mx, double my) {
        if (w.app() == AppId.BTC_SHOP && DesktopGeometry.shopButton(w.content()).contains(mx, my)) {
            send(Action.OPEN_SHOP, 0); // never gated by connectivity
        } else if (w.app() == AppId.SETTINGS) {
            if (DesktopGeometry.settingsWifiToggle(w.content()).contains(mx, my)) send(Action.SET_WIFI, snap.wifiJoined() ? 0 : 1);
            else if (DesktopGeometry.settingsEthToggle(w.content()).contains(mx, my)) send(Action.SET_ETHERNET, snap.ethernetPlugged() ? 0 : 1);
        }
    }

    private boolean isReady(int windowId) {
        var level = Minecraft.getInstance().level;
        long now = level == null ? snap.gameTime() : level.getGameTime();
        for (VpcSnapshot.WindowView v : snap.windows()) if (v.id() == windowId) return now >= v.readyAt();
        return false;
    }

    private boolean clickOff(double mx, double my) {
        if (DesktopGeometry.powerButton(monitor).contains(mx, my)) {
            send(Action.POWER_ON, 0);
            return true;
        }
        for (int i = 0; i < OsType.values().length; i++) {
            if (DesktopGeometry.osButton(monitor, i).contains(mx, my)) {
                send(Action.SELECT_OS, i);
                return true;
            }
        }
        return true;
    }

    private void send(Action a, int arg) {
        PCNetwork.sendToServer(new VpcActionPayload(pos, a, arg));
    }

    @Override
    public void removed() {
        send(Action.CLOSE_SCREEN, 0);
        super.removed();
    }
}
