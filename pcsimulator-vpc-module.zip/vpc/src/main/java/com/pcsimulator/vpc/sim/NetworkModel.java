package com.pcsimulator.vpc.sim;

/** Decides whether a virtual PC is online. Pure. */
public final class NetworkModel {
    private NetworkModel() {}

    /**
     * @param wifiJoined     player has Wi-Fi switched on / joined in the virtual OS
     * @param ethernetPlugged player has the Ethernet link enabled in the virtual OS
     * @param envWifi        the environment (router / area) offers Wi-Fi
     * @param envEthernet    the environment offers a wired uplink
     * @param envCapMbps     uplink cap of the environment, {@code Integer.MAX_VALUE} = unlimited
     */
    public static NetworkStatus evaluate(HardwareProfile hw, boolean wifiJoined, boolean ethernetPlugged,
                                         boolean envWifi, boolean envEthernet, int envCapMbps, Tuning t) {
        NetworkStatus eth = link(hw, NicKind.ETHERNET, ethernetPlugged && envEthernet, t, envCapMbps);
        if (eth.online()) return eth;
        NetworkStatus wifi = link(hw, NicKind.WIFI, wifiJoined && envWifi, t, envCapMbps);
        if (wifi.online()) return wifi;
        boolean anyNic = hw.hasNic(NicKind.ETHERNET) || hw.hasNic(NicKind.WIFI);
        if (t.requireNicForNetwork() && !anyNic) return NetworkStatus.down("pcsimulator.vpc.net.no_adapter");
        return NetworkStatus.OFFLINE_NO_LINK;
    }

    private static NetworkStatus link(HardwareProfile hw, NicKind kind, boolean enabled, Tuning t, int cap) {
        if (!enabled) return NetworkStatus.OFFLINE_NO_LINK;
        int best = -1;
        for (HardwareProfile.Nic n : hw.nics()) if (n.kind() == kind) best = Math.max(best, t.mbps(kind, n.tier()));
        if (best < 0) {
            if (t.requireNicForNetwork()) return NetworkStatus.down("pcsimulator.vpc.net.no_adapter");
            best = t.mbps(kind, 0);
        }
        return NetworkStatus.up(kind, Math.max(1, Math.min(best, cap)));
    }
}
