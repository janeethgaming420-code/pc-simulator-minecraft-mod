package com.pcsimulator.vpc.sim;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Server-authoritative state of ONE virtual PC: power state machine, chosen OS, network switches and open
 * windows. Pure Java, no Minecraft types, no threads, no real-time clock.
 *
 * <p>Time is the game tick passed in by the caller. Nothing needs ticking: {@link #advance} is "catch-up"
 * logic, so an unobserved PC costs exactly zero CPU and a PC that was booting while nobody looked simply
 * finishes the next time somebody touches it.
 */
public final class VirtualPcSession {
    public record Window(int id, AppId app, long openedAt, long readyAt) {}

    public enum Result { OK, WRONG_STATE, BLOCKED, NOT_RUNNING, NO_INTERNET, TOO_MANY_WINDOWS, NOT_FOUND }

    /** Persistable part. Windows are intentionally NOT persisted (a reloaded PC shows an empty desktop). */
    public record Persisted(OsType os, PowerState power, long phaseStart, long phaseEnd,
                            boolean wifiJoined, boolean ethernetPlugged) {}

    private OsType os = OsType.WINDOWS_10;
    private PowerState power = PowerState.OFF;
    private long phaseStart;
    private long phaseEnd;
    private boolean wifiJoined = true;
    private boolean ethernetPlugged = true;
    private final List<Window> windows = new ArrayList<>(); // index 0 = bottom, last = focused
    private int nextWindowId = 1;
    private String notice = "";
    private int noticeSeq;
    private int version;

    public VirtualPcSession() {}

    public static VirtualPcSession restore(Persisted p) {
        VirtualPcSession s = new VirtualPcSession();
        s.os = p.os();
        s.power = p.power();
        s.phaseStart = p.phaseStart();
        s.phaseEnd = p.phaseEnd();
        s.wifiJoined = p.wifiJoined();
        s.ethernetPlugged = p.ethernetPlugged();
        return s;
    }

    public Persisted persisted() {
        return new Persisted(os, power, phaseStart, phaseEnd, wifiJoined, ethernetPlugged);
    }

    // ---- accessors ---------------------------------------------------------------------------------------
    public OsType os() { return os; }
    public PowerState power() { return power; }
    public long phaseStart() { return phaseStart; }
    public long phaseEnd() { return phaseEnd; }
    public boolean wifiJoined() { return wifiJoined; }
    public boolean ethernetPlugged() { return ethernetPlugged; }
    public List<Window> windows() { return Collections.unmodifiableList(windows); }
    public String notice() { return notice; }
    public int noticeSeq() { return noticeSeq; }
    /** Incremented on every visible change; the sync layer sends a snapshot only when this moved. */
    public int version() { return version; }
    public boolean isActive() { return power != PowerState.OFF; }

    public int openAppRamMb() {
        int sum = 0;
        for (Window w : windows) sum += w.app().ramMb;
        return sum;
    }

    // ---- power -------------------------------------------------------------------------------------------
    public Result powerOn(long now, VirtualPerformance perf, Tuning t) {
        if (power != PowerState.OFF) return Result.WRONG_STATE;
        if (!perf.canBoot()) return Result.BLOCKED;
        long dur = PerformanceModel.duration(t.bootBaseTicks(), perf.speed());
        setPower(PowerState.BOOTING, now, now + dur);
        windows.clear();
        return Result.OK;
    }

    public Result shutdown(long now, VirtualPerformance perf, Tuning t) {
        if (power != PowerState.RUNNING && power != PowerState.BOOTING) return Result.WRONG_STATE;
        long dur = PerformanceModel.duration(t.shutdownBaseTicks(), perf.speed());
        setPower(PowerState.SHUTTING_DOWN, now, now + dur);
        windows.clear();
        return Result.OK;
    }

    /** Hard power cut (parts removed, physical fault, PSU overload...). Immediate. */
    public void forceOff(String noticeKey) {
        if (power == PowerState.OFF && windows.isEmpty()) return;
        windows.clear();
        power = PowerState.OFF;
        phaseStart = phaseEnd = 0;
        setNotice(noticeKey);
        version++;
    }

    public Result selectOs(OsType newOs) {
        if (power != PowerState.OFF) return Result.WRONG_STATE;
        if (newOs != os) { os = newOs; version++; }
        return Result.OK;
    }

    // ---- network switches --------------------------------------------------------------------------------
    public void setWifiJoined(boolean on) {
        if (wifiJoined != on) { wifiJoined = on; version++; }
    }

    public void setEthernetPlugged(boolean on) {
        if (ethernetPlugged != on) { ethernetPlugged = on; version++; }
    }

    // ---- time --------------------------------------------------------------------------------------------
    /**
     * Brings the session up to {@code now}: finishes boot/shutdown, and drops windows whose app needs internet
     * when the connection is gone (Chrome becomes inaccessible).
     *
     * @return true if anything visible changed
     */
    public boolean advance(long now, NetworkStatus net) {
        int before = version;
        if (power == PowerState.BOOTING && now >= phaseEnd) {
            setPower(PowerState.RUNNING, phaseEnd, phaseEnd);
        } else if (power == PowerState.SHUTTING_DOWN && now >= phaseEnd) {
            setPower(PowerState.OFF, 0, 0);
        }
        if (power == PowerState.RUNNING && !net.online()) {
            boolean removed = windows.removeIf(w -> w.app().requiresInternet);
            if (removed) { setNotice("pcsimulator.vpc.notice.connection_lost"); version++; }
        }
        return version != before;
    }

    // ---- windows -----------------------------------------------------------------------------------------
    public Result openApp(AppId app, long now, VirtualPerformance perf, NetworkStatus net) {
        if (power != PowerState.RUNNING) return Result.NOT_RUNNING;
        if (app.requiresInternet && !net.online()) return Result.NO_INTERNET;
        if (windows.size() >= perf.maxWindows()) return Result.TOO_MANY_WINDOWS;
        double speed = PerformanceModel.effectiveSpeed(perf, os, openAppRamMb() + app.ramMb);
        long ready = now + PerformanceModel.duration(app.baseLaunchTicks, speed / 1.0)
                + (app.requiresInternet ? net.pageLoadTicks() : 0);
        windows.add(new Window(nextWindowId++, app, now, ready));
        version++;
        return Result.OK;
    }

    public Result closeWindow(int id) {
        if (power != PowerState.RUNNING) return Result.NOT_RUNNING;
        boolean removed = windows.removeIf(w -> w.id() == id);
        if (removed) version++;
        return removed ? Result.OK : Result.NOT_FOUND;
    }

    public Result focusWindow(int id) {
        if (power != PowerState.RUNNING) return Result.NOT_RUNNING;
        for (int i = 0; i < windows.size(); i++) {
            if (windows.get(i).id() == id) {
                if (i != windows.size() - 1) { windows.add(windows.remove(i)); version++; }
                return Result.OK;
            }
        }
        return Result.NOT_FOUND;
    }

    // ---- internals ---------------------------------------------------------------------------------------
    private void setPower(PowerState p, long start, long end) {
        power = p;
        phaseStart = start;
        phaseEnd = end;
        version++;
    }

    private void setNotice(String key) {
        notice = key == null ? "" : key;
        noticeSeq++;
    }
}
