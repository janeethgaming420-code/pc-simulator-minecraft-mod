package com.pcsimulator.vpc.client;

import com.pcsimulator.vpc.network.VpcSnapshotPayload;
import net.minecraft.client.Minecraft;

/** Client-only entry for incoming snapshots. Loaded lazily from the packet handler lambda, so it is safe on servers. */
public final class VpcClientHooks {
    private VpcClientHooks() {}

    public static void onSnapshot(VpcSnapshotPayload p) {
        Minecraft mc = Minecraft.getInstance();
        if (p.openScreen()) {
            mc.setScreen(new VirtualPcScreen(p.pos(), p.snapshot()));
        } else if (mc.screen instanceof VirtualPcScreen s && s.pos().equals(p.pos())) {
            s.update(p.snapshot());
        }
    }
}
