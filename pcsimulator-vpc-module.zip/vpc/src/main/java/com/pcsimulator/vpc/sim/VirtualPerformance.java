package com.pcsimulator.vpc.sim;

/**
 * Result of {@link PerformanceModel#evaluate}. All durations are GAME TICKS, so virtual speed never depends on
 * the real frame rate of any player.
 *
 * @param cpu          normalised 0..100
 * @param gpu          normalised 0..100 (integrated fallback if no GPU)
 * @param ramMb        installed RAM in MB
 * @param overall      0..100 weighted-harmonic index (weakest part drags it down)
 * @param speed        relative speed, 1.0 = baseline; larger = faster
 * @param maxWindows   open application windows allowed by RAM
 * @param qualityCap   highest visual quality the virtual PC "supports" (a client may always go lower)
 * @param virtualFps   frame rate of the SIMULATED desktop animations (used only for quantised animation)
 * @param blocker      null if the PC meets the OS minimum, otherwise why it cannot boot
 */
public record VirtualPerformance(double cpu, double gpu, int ramMb, double overall, double speed, int maxWindows,
                                 RenderQuality qualityCap, int virtualFps, Blocker blocker, boolean integratedGpu) {
    public enum Blocker {
        NO_CPU, NO_RAM, OS_NEEDS_MORE_RAM, OS_NEEDS_FASTER_CPU;

        public String langKey() {
            return "pcsimulator.vpc.blocker." + name().toLowerCase(java.util.Locale.ROOT);
        }
    }

    public boolean canBoot() {
        return blocker == null;
    }

    public String tierLangKey() {
        String t = overall >= 80 ? "ultra" : overall >= 55 ? "high" : overall >= 30 ? "mid" : "low";
        return "pcsimulator.vpc.perf." + t;
    }
}
