package com.pcsimulator.vpc.sim;

import java.util.ArrayList;
import java.util.List;

/**
 * Immutable client view of a virtual PC. Contains ABSOLUTE game-tick timestamps, so the client can animate boot
 * and loading bars locally and the server only sends a new snapshot when something actually changes.
 */
public record VpcSnapshot(
        long gameTime, OsType os, PowerState power, long phaseStart, long phaseEnd,
        boolean wifiJoined, boolean ethernetPlugged, boolean online, int linkOrdinal, int mbps, String netReasonKey,
        boolean hasWifiNic, boolean hasEthernetNic,
        int cpu, int gpu, int ramGb, int overall, int speedPercent, int maxWindows,
        RenderQuality qualityCap, int virtualFps, boolean integratedGpu, int blockerOrdinal,
        String cpuLabel, String gpuLabel,
        List<WindowView> windows, String noticeKey, int noticeSeq) {

    public record WindowView(int id, int appOrdinal, long openedAt, long readyAt) {
        public AppId app() { return AppId.byOrdinal(appOrdinal); }
    }

    public VpcSnapshot {
        windows = List.copyOf(windows);
    }

    public NicKind link() {
        return linkOrdinal < 0 ? null : NicKind.values()[linkOrdinal];
    }

    public VirtualPerformance.Blocker blocker() {
        return blockerOrdinal < 0 ? null : VirtualPerformance.Blocker.values()[blockerOrdinal];
    }

    public static VpcSnapshot of(long now, VirtualPcSession s, VirtualPerformance p, NetworkStatus net,
                                 HardwareProfile hw, String cpuLabel, String gpuLabel) {
        List<WindowView> ws = new ArrayList<>(s.windows().size());
        for (VirtualPcSession.Window w : s.windows()) {
            ws.add(new WindowView(w.id(), w.app().ordinal(), w.openedAt(), w.readyAt()));
        }
        return new VpcSnapshot(now, s.os(), s.power(), s.phaseStart(), s.phaseEnd(),
                s.wifiJoined(), s.ethernetPlugged(), net.online(), net.link() == null ? -1 : net.link().ordinal(),
                net.mbps(), net.reasonKey(),
                hw.hasNic(NicKind.WIFI), hw.hasNic(NicKind.ETHERNET),
                (int) Math.round(p.cpu()), (int) Math.round(p.gpu()), p.ramMb() / 1024, (int) Math.round(p.overall()),
                (int) Math.round(p.speed() * 100), p.maxWindows(), p.qualityCap(), p.virtualFps(),
                p.integratedGpu(), p.blocker() == null ? -1 : p.blocker().ordinal(),
                cpuLabel, gpuLabel, ws, s.notice(), s.noticeSeq());
    }
}
