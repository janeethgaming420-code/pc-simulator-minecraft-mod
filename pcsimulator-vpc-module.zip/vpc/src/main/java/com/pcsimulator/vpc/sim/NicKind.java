package com.pcsimulator.vpc.sim;

public enum NicKind { ETHERNET, WIFI }
