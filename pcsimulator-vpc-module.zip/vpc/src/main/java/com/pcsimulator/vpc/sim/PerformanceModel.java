package com.pcsimulator.vpc.sim;

/**
 * Pure performance maths. Deterministic, allocation-light, no Minecraft or timing dependency.
 *
 * <p>Overall = weighted HARMONIC mean of CPU (45%), GPU (30%) and RAM (25%). Harmonic means punish the weakest
 * link, so a 90-score CPU with 2 GB of RAM is still slow - hardware limitations matter.
 */
public final class PerformanceModel {
    private PerformanceModel() {}

    static double norm(int rawScore, int tier, Tuning t) {
        int s = rawScore > 0 ? rawScore : t.fallbackScore(tier);
        return Math.max(1.0, Math.min(100.0, s * 100.0 / t.scoreCeiling()));
    }

    public static VirtualPerformance evaluate(HardwareProfile hw, OsType os, Tuning t) {
        int ramMb = Math.max(0, hw.ramGb()) * 1024;
        double cpu = hw.hasCpu() ? norm(hw.cpuScore(), hw.cpuTier(), t) : 0;
        boolean integrated = !hw.hasGpu();
        double gpu = integrated ? t.integratedGpuScore() : norm(hw.gpuScore(), hw.gpuTier(), t);
        double ramScore = Math.max(1.0, Math.min(100.0, hw.ramGb() / 32.0 * 100.0));

        VirtualPerformance.Blocker blocker = null;
        if (!hw.hasCpu()) blocker = VirtualPerformance.Blocker.NO_CPU;
        else if (hw.ramGb() <= 0) blocker = VirtualPerformance.Blocker.NO_RAM;
        else if (hw.ramGb() < os.minRamGb) blocker = VirtualPerformance.Blocker.OS_NEEDS_MORE_RAM;
        else if (cpu < os.minCpuScore) blocker = VirtualPerformance.Blocker.OS_NEEDS_FASTER_CPU;

        double overall = 0;
        if (hw.hasCpu() && hw.ramGb() > 0) {
            overall = 1.0 / (0.45 / cpu + 0.30 / Math.max(1.0, gpu) + 0.25 / ramScore);
        }
        double speed = 0.25 + 1.75 * (overall / 100.0);
        speed = Math.max(t.minSpeed(), Math.min(t.maxSpeed(), speed / os.weight));

        int usableMb = Math.max(0, ramMb - os.idleRamMb());
        int maxWindows = Math.max(1, Math.min(t.maxWindowsCap(), usableMb / 400));

        // Visual cap: needs both GPU and overall strength. Integrated graphics can never claim HIGH.
        RenderQuality cap = RenderQuality.LOW;
        if (overall >= 28 && gpu >= 12) cap = RenderQuality.MEDIUM;
        if (overall >= 55 && gpu >= 45 && !integrated) cap = RenderQuality.HIGH;

        int fps = (int) Math.max(10, Math.min(60, Math.round(10 + overall * 0.5)));
        return new VirtualPerformance(cpu, gpu, ramMb, overall, speed, maxWindows, cap, fps, blocker, integrated);
    }

    /** Ticks needed for a job with the given baseline duration at the given speed, never less than 1. */
    public static long duration(int baseTicks, double effectiveSpeed) {
        return Math.max(1L, Math.round(baseTicks / Math.max(0.05, effectiveSpeed)));
    }

    /**
     * Speed after memory pressure: when open apps exceed installed RAM the machine "swaps" and slows down
     * quadratically, floor 10%.
     */
    public static double effectiveSpeed(VirtualPerformance p, OsType os, int openAppRamMb) {
        int used = os.idleRamMb() + openAppRamMb;
        if (p.ramMb() <= 0 || used <= p.ramMb()) return p.speed();
        double r = (double) p.ramMb() / used;
        return p.speed() * Math.max(0.10, r * r);
    }
}
