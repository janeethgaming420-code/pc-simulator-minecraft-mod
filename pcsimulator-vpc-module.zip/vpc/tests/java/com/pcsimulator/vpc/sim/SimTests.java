package com.pcsimulator.vpc.sim;

import java.util.List;

/** Dependency-free test runner (no JUnit needed): {@code java -cp out com.pcsimulator.vpc.sim.SimTests}. */
public final class SimTests {
    static int passed, failed;

    static void check(String name, boolean ok) {
        if (ok) passed++; else { failed++; System.out.println("FAIL: " + name); }
    }

    static HardwareProfile hw(int cpu, int cpuTier, int gpu, int gpuTier, int ram, HardwareProfile.Nic... nics) {
        return new HardwareProfile(cpu, cpuTier, gpu, gpuTier, ram, List.of(nics));
    }

    static final Tuning T = Tuning.DEFAULT;
    static final HardwareProfile.Nic ETH = new HardwareProfile.Nic(NicKind.ETHERNET, 0);
    static final HardwareProfile.Nic WIFI = new HardwareProfile.Nic(NicKind.WIFI, 0);

    public static void main(String[] a) {
        performance();
        power();
        network();
        windows();
        adaptive();
        themes();
        geometry();
        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) System.exit(1);
    }

    static void performance() {
        VirtualPerformance low = PerformanceModel.evaluate(hw(20, 0, -1, 0, 4), OsType.WINDOWS_10, T);
        VirtualPerformance mid = PerformanceModel.evaluate(hw(60, 1, 60, 1, 16), OsType.WINDOWS_10, T);
        VirtualPerformance high = PerformanceModel.evaluate(hw(95, 3, 95, 3, 32), OsType.WINDOWS_10, T);
        check("better hardware -> higher overall", low.overall() < mid.overall() && mid.overall() < high.overall());
        check("better hardware -> higher speed", low.speed() < mid.speed() && mid.speed() < high.speed());
        check("better hardware -> more windows", low.maxWindows() <= mid.maxWindows() && mid.maxWindows() <= high.maxWindows());
        check("integrated gpu never HIGH", low.qualityCap() != RenderQuality.HIGH);
        check("high-end supports HIGH", high.qualityCap() == RenderQuality.HIGH);
        check("low-end capped LOW", low.qualityCap() == RenderQuality.LOW);
        // bottleneck: strong CPU/GPU but 2 GB RAM must be clearly slower than same with 32 GB
        VirtualPerformance starved = PerformanceModel.evaluate(hw(95, 3, 95, 3, 2), OsType.WINDOWS_10, T);
        check("RAM bottleneck matters", starved.overall() < high.overall() * 0.6);
        // same hardware: weaker GPU lowers result
        VirtualPerformance weakGpu = PerformanceModel.evaluate(hw(95, 3, 10, 0, 32), OsType.WINDOWS_10, T);
        check("GPU limitation matters", weakGpu.overall() < high.overall());
        // OS requirements
        check("Win11 blocked on 2 GB", !PerformanceModel.evaluate(hw(60, 1, 60, 1, 2), OsType.WINDOWS_11, T).canBoot());
        check("Arch boots on 2 GB", PerformanceModel.evaluate(hw(60, 1, 60, 1, 2), OsType.ARCH, T).canBoot());
        check("no CPU blocked", PerformanceModel.evaluate(hw(-1, 0, 60, 1, 8), OsType.ARCH, T).blocker() == VirtualPerformance.Blocker.NO_CPU);
        check("no RAM blocked", PerformanceModel.evaluate(hw(60, 1, 60, 1, 0), OsType.ARCH, T).blocker() == VirtualPerformance.Blocker.NO_RAM);
        // unset score (0) falls back to tier default instead of 0
        VirtualPerformance unset = PerformanceModel.evaluate(hw(0, 1, -1, 0, 8), OsType.UBUNTU, T);
        check("unset score uses tier fallback", Math.abs(unset.cpu() - 45) < 0.01);
        // lighter OS is faster on same hardware
        HardwareProfile h = hw(40, 1, 40, 1, 8);
        check("Arch faster than Win11 on same PC", PerformanceModel.evaluate(h, OsType.ARCH, T).speed()
                > PerformanceModel.evaluate(h, OsType.WINDOWS_11, T).speed());
        // memory pressure
        VirtualPerformance p4 = PerformanceModel.evaluate(hw(60, 1, 60, 1, 4), OsType.WINDOWS_10, T);
        check("memory pressure slows", PerformanceModel.effectiveSpeed(p4, OsType.WINDOWS_10, 6000) < p4.speed() * 0.5);
        check("no pressure unchanged", PerformanceModel.effectiveSpeed(p4, OsType.WINDOWS_10, 100) == p4.speed());
        check("speed within clamp", high.speed() <= T.maxSpeed() && low.speed() >= T.minSpeed());
        check("overall 0..100", high.overall() <= 100 && low.overall() > 0);
        check("empty profile safe", PerformanceModel.evaluate(HardwareProfile.EMPTY, OsType.UBUNTU, T).overall() == 0);
    }

    static VirtualPcSession booted(VirtualPerformance p, NetworkStatus net) {
        VirtualPcSession s = new VirtualPcSession();
        s.powerOn(0, p, T);
        s.advance(s.phaseEnd() + 1, net);
        return s;
    }

    static void power() {
        VirtualPerformance p = PerformanceModel.evaluate(hw(60, 1, 60, 1, 16), OsType.WINDOWS_10, T);
        NetworkStatus up = NetworkStatus.up(NicKind.ETHERNET, 100);
        VirtualPcSession s = new VirtualPcSession();
        check("starts OFF", s.power() == PowerState.OFF);
        check("power on ok", s.powerOn(100, p, T) == VirtualPcSession.Result.OK && s.power() == PowerState.BOOTING);
        check("double power on refused", s.powerOn(100, p, T) == VirtualPcSession.Result.WRONG_STATE);
        check("OS locked while on", s.selectOs(OsType.ARCH) == VirtualPcSession.Result.WRONG_STATE);
        check("not running before boot ends", s.advance(s.phaseEnd() - 1, up) == false && s.power() == PowerState.BOOTING);
        check("boots after phaseEnd", s.advance(s.phaseEnd(), up) && s.power() == PowerState.RUNNING);
        check("shutdown starts", s.shutdown(1000, p, T) == VirtualPcSession.Result.OK && s.power() == PowerState.SHUTTING_DOWN);
        s.advance(s.phaseEnd(), up);
        check("off after shutdown", s.power() == PowerState.OFF);
        check("OS selectable when off", s.selectOs(OsType.ARCH) == VirtualPcSession.Result.OK && s.os() == OsType.ARCH);
        // catch-up without ticking: long gap still lands in the right state
        VirtualPcSession c = new VirtualPcSession();
        c.powerOn(0, p, T);
        c.advance(1_000_000, up);
        check("catch-up finishes boot lazily", c.power() == PowerState.RUNNING);
        // boot time depends on hardware
        VirtualPerformance weak = PerformanceModel.evaluate(hw(20, 0, -1, 0, 4), OsType.WINDOWS_10, T);
        VirtualPerformance strong = PerformanceModel.evaluate(hw(95, 3, 95, 3, 32), OsType.WINDOWS_10, T);
        VirtualPcSession w = new VirtualPcSession(), g = new VirtualPcSession();
        w.powerOn(0, weak, T); g.powerOn(0, strong, T);
        check("weak PC boots slower", w.phaseEnd() > g.phaseEnd());
        VirtualPerformance blocked = PerformanceModel.evaluate(hw(60, 1, 60, 1, 2), OsType.WINDOWS_11, T);
        check("blocked PC refuses boot", new VirtualPcSession().powerOn(0, blocked, T) == VirtualPcSession.Result.BLOCKED);
        s.forceOff("x");
        check("forceOff idempotent on OFF", s.power() == PowerState.OFF);
        // persistence round trip
        VirtualPcSession r = VirtualPcSession.restore(booted(p, up).persisted());
        check("restore keeps power+os", r.power() == PowerState.RUNNING && r.os() == OsType.WINDOWS_10);
    }

    static void network() {
        HardwareProfile both = hw(60, 1, 60, 1, 8, ETH, WIFI);
        int inf = Integer.MAX_VALUE;
        check("eth up -> online", NetworkModel.evaluate(both, true, true, true, true, inf, T).online());
        check("wifi only -> online via wifi", NetworkModel.evaluate(both, true, false, true, true, inf, T).link() == NicKind.WIFI);
        check("both disconnected -> OFFLINE", !NetworkModel.evaluate(both, false, false, true, true, inf, T).online());
        check("no NIC -> offline", !NetworkModel.evaluate(hw(60, 1, 60, 1, 8), true, true, true, true, inf, T).online());
        check("wifi switch on but only ethernet NIC -> offline", !NetworkModel.evaluate(hw(60, 1, 60, 1, 8, ETH), true, false, true, true, inf, T).online());
        check("environment without wifi -> offline", !NetworkModel.evaluate(hw(60, 1, 60, 1, 8, WIFI), true, true, false, false, inf, T).online());
        check("ethernet preferred", NetworkModel.evaluate(both, true, true, true, true, inf, T).link() == NicKind.ETHERNET);
        check("uplink cap applied", NetworkModel.evaluate(both, false, true, true, true, 10, T).mbps() == 10);
        HardwareProfile fast = hw(60, 1, 60, 1, 8, new HardwareProfile.Nic(NicKind.ETHERNET, 2));
        check("better NIC faster", NetworkModel.evaluate(fast, true, true, true, true, inf, T).mbps()
                > NetworkModel.evaluate(hw(60, 1, 60, 1, 8, ETH), true, true, true, true, inf, T).mbps());
        check("faster link loads pages quicker", NetworkStatus.up(NicKind.ETHERNET, 1000).pageLoadTicks()
                < NetworkStatus.up(NicKind.WIFI, 50).pageLoadTicks());
        check("noNicRequirement option", NetworkModel.evaluate(hw(60, 1, 60, 1, 8), true, true, true, true, inf,
                new Tuning(100, T.tierFallbackScore(), T.tierRamGb(), 8, T.ethernetMbps(), T.wifiMbps(), false, 200, 60, .25, 2, 8)).online());
    }

    static void windows() {
        VirtualPerformance p = PerformanceModel.evaluate(hw(60, 1, 60, 1, 16), OsType.WINDOWS_10, T);
        NetworkStatus up = NetworkStatus.up(NicKind.ETHERNET, 100);
        NetworkStatus down = NetworkStatus.OFFLINE_NO_LINK;
        VirtualPcSession off = new VirtualPcSession();
        check("cannot open app when OFF", off.openApp(AppId.SETTINGS, 0, p, up) == VirtualPcSession.Result.NOT_RUNNING);
        VirtualPcSession s = booted(p, up);
        check("chrome opens online", s.openApp(AppId.CHROME, 5000, p, up) == VirtualPcSession.Result.OK);
        check("chrome window not ready instantly", s.windows().get(0).readyAt() > 5000);
        // go offline: Chrome inaccessible
        check("chrome removed when offline", s.advance(5001, down) && s.windows().isEmpty());
        check("notice raised", !s.notice().isEmpty() && s.noticeSeq() > 0);
        check("chrome refused offline", s.openApp(AppId.CHROME, 5002, p, down) == VirtualPcSession.Result.NO_INTERNET);
        check("BTC shop works offline", s.openApp(AppId.BTC_SHOP, 5002, p, down) == VirtualPcSession.Result.OK);
        check("shop survives going offline", !s.advance(5003, down) && s.windows().size() == 1);
        check("settings works offline", s.openApp(AppId.SETTINGS, 5004, p, down) == VirtualPcSession.Result.OK);
        // focus + close
        int first = s.windows().get(0).id();
        s.focusWindow(first);
        check("focus moves to top", s.windows().get(s.windows().size() - 1).id() == first);
        check("close ok", s.closeWindow(first) == VirtualPcSession.Result.OK && s.windows().size() == 1);
        check("close unknown", s.closeWindow(999) == VirtualPcSession.Result.NOT_FOUND);
        // window cap from RAM
        VirtualPerformance tiny = PerformanceModel.evaluate(hw(60, 1, 60, 1, 2), OsType.ARCH, T);
        VirtualPcSession t = new VirtualPcSession();
        t.selectOs(OsType.ARCH);
        t.powerOn(0, tiny, T);
        t.advance(t.phaseEnd(), up);
        int opened = 0;
        while (t.openApp(AppId.TERMINAL, 9, tiny, up) == VirtualPcSession.Result.OK && opened < 50) opened++;
        check("window cap enforced", opened == tiny.maxWindows());
        // slower app launch on weak hardware
        VirtualPerformance weak = PerformanceModel.evaluate(hw(20, 0, -1, 0, 4), OsType.WINDOWS_10, T);
        VirtualPcSession ws = booted(weak, up), gs = booted(PerformanceModel.evaluate(hw(95, 3, 95, 3, 32), OsType.WINDOWS_10, T), up);
        ws.openApp(AppId.SETTINGS, 0, weak, up);
        gs.openApp(AppId.SETTINGS, 0, PerformanceModel.evaluate(hw(95, 3, 95, 3, 32), OsType.WINDOWS_10, T), up);
        check("apps launch slower on weak PC", ws.windows().get(0).readyAt() > gs.windows().get(0).readyAt());
        // snapshot
        VpcSnapshot snap = VpcSnapshot.of(7, s, p, down, hw(60, 1, 60, 1, 16, ETH), "cpu", "gpu");
        check("snapshot reflects offline", !snap.online() && snap.link() == null && snap.ramGb() == 16);
    }

    static void adaptive() {
        AdaptiveQuality q = new AdaptiveQuality(30);
        for (int i = 0; i < 400; i++) q.onFrame(60_000_000L); // 16 FPS
        check("slow client downgraded to LOW", q.adaptiveLevel() == RenderQuality.LOW);
        check("viewer low-end never forced to HIGH by strong PC",
                q.effective(RenderQuality.HIGH, RenderQuality.HIGH) == RenderQuality.LOW);
        AdaptiveQuality f = new AdaptiveQuality(30);
        for (int i = 0; i < 500; i++) f.onFrame(8_000_000L);
        check("fast client stays HIGH", f.effective(RenderQuality.HIGH, RenderQuality.HIGH) == RenderQuality.HIGH);
        check("weak virtual PC caps even a fast client", f.effective(RenderQuality.HIGH, RenderQuality.LOW) == RenderQuality.LOW);
        check("user ceiling respected", f.effective(RenderQuality.MEDIUM, RenderQuality.HIGH) == RenderQuality.MEDIUM);
        for (int i = 0; i < 2000; i++) q.onFrame(8_000_000L);
        check("recovers after load drops", q.adaptiveLevel() == RenderQuality.HIGH);
        AdaptiveQuality st = new AdaptiveQuality(30);
        st.onFrame(5_000_000_000L); // a 5 s stall is clamped
        check("single stall does not drop quality", st.adaptiveLevel() == RenderQuality.HIGH);
        // virtual clock independent of real fps
        check("quantised to virtual fps", VirtualClock.quantize(1.07, 10) == 1.0);
        check("progress clamps", VirtualClock.progress(0, 100, 500, 0f, 30) == 1.0 && VirtualClock.progress(10, 100, 0, 0f, 30) == 0.0);
    }

    static void geometry() {
        WindowLayout.Rect mon = new WindowLayout.Rect(10, 10, 384, 216);
        List<DesktopGeometry.WinRef> refs = List.of(new DesktopGeometry.WinRef(1, AppId.CHROME), new DesktopGeometry.WinRef(2, AppId.SETTINGS));
        for (OsType os : OsType.values()) {
            OsTheme th = OsThemes.of(os);
            DesktopGeometry.Geo g = DesktopGeometry.compute(th, mon, refs, true);
            boolean inside = true;
            for (DesktopGeometry.WinGeo w : g.windows()) {
                inside &= w.frame().x() >= g.work().x() && w.frame().right() <= g.work().right()
                        && w.frame().y() >= g.work().y() && w.frame().bottom() <= g.work().bottom();
                inside &= w.close().x() >= w.frame().x() && w.close().right() <= w.frame().right();
            }
            check("windows inside work area " + os, inside);
            check("bar/work disjoint " + os, g.bar().bottom() <= g.work().y() || g.work().bottom() <= g.bar().y());
            check("menu has all entries " + os, g.menuItems().size() == DesktopGeometry.MENU_ENTRIES);
            check("menu inside monitor " + os, g.menu().x() >= mon.x() && g.menu().right() <= mon.right()
                    && g.menu().y() >= mon.y() && g.menu().bottom() <= mon.bottom());
            check("start inside bar " + os, g.start().y() >= g.bar().y() - 1 && g.start().bottom() <= g.bar().bottom() + 1);
            boolean trayOk = g.ethTray().right() <= g.wifiTray().x() + 1 && g.wifiTray().right() <= g.clock().right() + 16;
            check("tray icons laid out " + os, trayOk || th.clockCentered());
            check("top window wins hit test " + os, DesktopGeometry.windowAt(g, g.windows().get(1).content().x() + 2,
                    g.windows().get(1).content().y() + 2) != null);
            check("no menu when closed " + os, DesktopGeometry.compute(th, mon, refs, false).menuItems().isEmpty());
        }
        check("ubuntu has dock apps, fedora none", !DesktopGeometry.compute(OsThemes.of(OsType.UBUNTU), mon, refs, false).apps().isEmpty()
                && DesktopGeometry.compute(OsThemes.of(OsType.FEDORA), mon, refs, false).apps().isEmpty());
        check("win11 icons centred", Math.abs((DesktopGeometry.compute(OsThemes.of(OsType.WINDOWS_11), mon, refs, false).start().x() - mon.x())
                - (mon.right() - DesktopGeometry.compute(OsThemes.of(OsType.WINDOWS_11), mon, refs, false).apps().get(3).rect().right())) < 8);
        check("OS buttons fit monitor", DesktopGeometry.osButton(mon, 5).bottom() < mon.bottom());
    }

    static void themes() {
        for (OsType os : OsType.values()) check("theme exists " + os, OsThemes.of(os) != null && OsThemes.of(os).os() == os);
        check("all layouts used distinctly",
                java.util.Arrays.stream(OsType.values()).map(o -> OsThemes.of(o).layout()).distinct().count() == 5);
        check("win7 glass, win10 flat", OsThemes.of(OsType.WINDOWS_7).glass() && !OsThemes.of(OsType.WINDOWS_10).glass());
        check("arch tiled", OsThemes.of(OsType.ARCH).tiled());
        WindowLayout.Rect area = new WindowLayout.Rect(0, 11, 320, 169);
        WindowLayout.Rect r0 = WindowLayout.place(OsThemes.of(OsType.ARCH), 0, 3, area);
        WindowLayout.Rect r1 = WindowLayout.place(OsThemes.of(OsType.ARCH), 1, 3, area);
        WindowLayout.Rect r2 = WindowLayout.place(OsThemes.of(OsType.ARCH), 2, 3, area);
        check("tiles do not overlap", r0.x() + r0.w() <= r1.x() && r1.y() + r1.h() <= r2.y());
        WindowLayout.Rect c = WindowLayout.place(OsThemes.of(OsType.UBUNTU), 5, 6, area);
        check("cascade inside area", c.x() >= 0 && c.x() + c.w() <= 320 && c.y() + c.h() <= 180);
    }
}
