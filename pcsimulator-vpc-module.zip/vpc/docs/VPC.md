# Virtual PC Systems module (`com.pcsimulator.vpc`) - Claude 5

Module id `vpc`, no `dependsOn`. Uses only the public `api` package and the core registries/network/config/data helpers.
No other module is modified and none is imported.

## Integration for Claude 7 (3 steps)

1. `core/module/ModuleList.java` - add ONE line: `new com.pcsimulator.vpc.VpcModule()`
2. Merge `assets/pcsimulator/lang/en_us.vpc.json` into `en_us.json` (all keys are prefixed `pcsimulator.vpc.`).
3. From the PC block's right-click handler (pcbuild), call the existing interaction mechanism:
   ```java
   PCInteractions.perform(VpcApi.OPEN_DESKTOP, new InteractionContext(player, level, pos, hand, stack, build));
   PCInteractions.perform(VpcApi.TOGGLE_POWER, ctx);   // optional: boot / shut down without opening the screen
   ```
   (`VpcApi.OPEN_DESKTOP` = `pcsimulator:vpc_open`, `VpcApi.TOGGLE_POWER` = `pcsimulator:vpc_power_toggle`; both are registered in `pcsimulator:interaction`.)
   Or call `VpcApi.openDesktop(serverPlayer, level, pos, build)` directly.

The PC must expose `PCCapabilities.PC_BUILD` at `pos` (the server re-reads it on every action and every 20 ticks while viewed).

### Optional hooks (all have working defaults)
| Hook | Who | Purpose |
|---|---|---|
| `VpcApi.setShopLauncher(IShopLauncher)` | Claude 6 / economy | Makes the "BTC Shop" app open the real shop. Default: "shop not installed" message. Never gated by internet. |
| `VpcApi.setNetworkEnvironment(INetworkEnvironment)` | world / router blocks | Per-position Wi-Fi/Ethernet availability + uplink cap. Default: everything available, unlimited. |
| `VpcApi.setNicKindResolver(fn)` | hardware | Classify a NETWORK_CARD as WIFI/ETHERNET. Default: registry id contains `wifi`/`wi_fi`/`wlan`/`wireless` => Wi-Fi, else Ethernet. |
| `VpcApi.notifyBuildChanged(server, build)` | pcbuild | Call after parts are removed/changed: a running virtual PC that can no longer boot loses power immediately. |
| `VpcApi.powerState(server, buildId)` | anyone | Read virtual power (OFF/BOOTING/RUNNING/SHUTTING_DOWN). |

### Files / config / data written
* Config: `config/pcsimulator/vpc-common.toml` (tuning, range, `followPhysicalState`), `config/pcsimulator/vpc-client.toml` (`maxQuality`, `adaptiveQuality`, `targetFps`).
* World data: `data/pcsimulator_vpc_sessions.dat` (OS, power state, Wi-Fi/Ethernet switches per `buildId`; windows are not persisted).
* Packets (protocol version unchanged, uses the shared one): `pcsimulator:vpc/action` (C2S), `pcsimulator:vpc/snapshot` (S2C). **Adding payloads changes the wire protocol; if the core's `PROTOCOL_VERSION` is bumped per module, bump it once for this module.**

## How it works

### Power
`OFF -> BOOTING -> RUNNING -> SHUTTING_DOWN -> OFF`, owned by `VirtualPcSession`. Start requires `IPCBuild.checkBoot().success()`, `state() != FAULT`, and the chosen OS's minimum (RAM, CPU). The virtual power state is independent of `PCState` because the API gives this module no way to change `PCState`. If `followPhysicalState=true`, starting additionally needs `PCState.RUNNING`. A running virtual PC whose build stops being bootable (or goes FAULT) is cut off.

### Performance (hardware matters, FPS does not)
`HardwareProfile` (from `IPCBuild.installed()`: best CPU, best GPU, total RAM, NICs) -> `PerformanceModel`:
* Overall = weighted **harmonic** mean (CPU 45%, GPU 30%, RAM 25%) so the weakest part drags the result down.
* `speed = clamp(0.25 + 1.75*overall/100) / osWeight`; boot, shutdown and app-launch durations are **game ticks** = base / speed. Open apps beyond installed RAM slow the PC quadratically (swap).
* RAM also caps open windows; each OS has a minimum RAM/CPU and a weight (Arch lightest, Win 11 heaviest).
* GPU decides the **visual cap** a virtual PC supports: no GPU (integrated) => never HIGH.

### Rendering budget (low-end viewers are never forced up)
Server sends state, never pixels. The client draws with flat `GuiGraphics` fills and text only (no textures, no extra render state) at `effective = min(viewer's maxQuality, virtual PC's cap, adaptive level)`. `AdaptiveQuality` lowers detail after ~30 slow frames (below `targetFps`) and raises it again after ~180 fast frames; frame spikes are clamped. LOW = flat fills only; MEDIUM = gradients; HIGH = shadows, hover highlights. Simulated animations (boot bar, dots, loading bars) are driven by game ticks quantised to the virtual PC's own frame rate (`VirtualClock`).

### Server cost
No viewers => the module does nothing per tick (`VIEWERS.isEmpty()` early-out). Sessions are caught up lazily from absolute tick timestamps when touched. With viewers: one pass every 10 ticks per viewer, physical re-validation every 20 ticks, a snapshot only when the session version changed.

### Networking
`NetworkModel`: Ethernet is preferred, else Wi-Fi. A link is up only if (a) the matching NIC is installed (`requireNetworkCard`), (b) the player's virtual switch for it is on (tray icons E/W or Settings app), (c) the `INetworkEnvironment` offers it. Speed comes from NIC tier and sets page-load time. **Both links down => `online=false` => Chrome cannot be opened and any open Chrome window is closed with a notice.** The BTC Shop app and its `OPEN_SHOP` action never check connectivity.

### OS skins (`OsThemes`, pure data + `DesktopRenderer`)
| OS | Layout | Distinguishing look |
|---|---|---|
| Windows 7 | bottom bar, start orb | glass gradient, Aero titlebars, red close button, thicker frames |
| Windows 10 | bottom bar, logo | flat dark taskbar, flat white windows, `- o x` buttons |
| Windows 11 | bottom bar, centred icons | light bar, small rounded corners, centred clock |
| Ubuntu | top panel + left dock | aubergine wallpaper, dark windows, orange round close |
| Fedora | top panel only, Activities menu | blue wallpaper, light Adwaita-like windows, centred titles |
| Arch Linux | thin top bar with workspaces, **auto-tiled** windows | near-black, cyan borders, text-only titlebars |

All icons are generic shapes; no official logos, wallpapers or fonts are reproduced. Apps: Chrome (mock page), BTC Shop (launcher), Settings (hardware, performance, network switches), Terminal (spec dump).

## Security / validation
Every client action is range-checked (`interactionRange`), re-resolved through `PC_BUILD` at that position, applied to the server-side session, and answered with a snapshot. Enum/arg values are bounds-wrapped; unknown window ids are ignored. The client cannot set power, OS (while running), network state or performance directly.
