# Claude 5 report - Virtual PC Systems module

## Implemented (source in `src/`)
- Virtual power: OFF -> BOOTING -> RUNNING -> SHUTTING_DOWN -> OFF, gated by `IPCBuild.checkBoot()`, `PCState`, OS minimums; persisted per buildId.
- Performance from installed CPU/GPU/RAM (`HardwareProfile` -> `PerformanceModel`): weighted harmonic mean, RAM caps windows, swap slowdown, OS weight; all timings in game ticks, independent of real FPS.
- Render budget: flat GuiGraphics only; quality = min(viewer max, PC's GPU cap, adaptive level). Low-end viewers are never forced higher.
- Six OS skins (Win 7/10/11, Ubuntu, Fedora, Arch) with distinct wallpaper, panel/taskbar, window chrome, tiling (Arch). Generic shapes, no official logos.
- Apps: Chrome (mock), BTC Shop launcher, Settings, Terminal.
- Networking: Ethernet/Wi-Fi from installed NIC + player switches + optional `INetworkEnvironment`. Both down => Chrome blocked and closed. BTC Shop never checks connectivity.
- Server cost: nothing runs without viewers; actions are range-checked and re-validated through `PC_BUILD`.
- Config (`vpc-common.toml`, `vpc-client.toml`), lang file `en_us.vpc.json` (38 keys), integration docs `docs/VPC.md`.

## Dependencies
Only the public `com.pcsimulator.api` package plus core `PCModule`, `PCConfig`, `PCNetwork`, `PacketRegistrar`, `CoreRegistries`, `PCWorldData`. No other module touched. Core change needed by Claude 7: one line in `ModuleList` + merge lang file.

## Testing - what was and was NOT done
- DONE: `tools/run_tests.sh` - 130 checks on the pure-Java sim layer (performance, power, network, windows, adaptive quality, geometry, themes): **130 passed, 0 failed**.
- DONE: `tools/check_lang.py` - 38 keys used, none missing/unused.
- DONE (weak): `tools/typecheck.sh` - whole module type-checks against hand-written stubs of Minecraft/NeoForge/core. The stubbed `com.pcsimulator.api` signatures were compared against the real core sources and match. This is NOT a real compile.
- NOT DONE: `./gradlew compileJava` / `build` (no network here, so NeoForge/Minecraft could not be downloaded). Real Minecraft/NeoForge API usage (GuiGraphics, payload/codec registration, SavedData factory, ModConfigSpec, event names) is unverified.
- NOT DONE: no in-game run; rendering, screens, packets and persistence have never been seen working. Skin appearance is untested visually.

## Limitations
- Virtual power state is separate from `PCState` (API offers no way to set it).
- Default NIC classification is by registry id substring; hardware module has no Wi-Fi/Ethernet flag.
- Chrome is a mock page; Shop app needs Claude 6 to call `VpcApi.setShopLauncher`.
- Adding payloads changes the wire protocol; bump `PROTOCOL_VERSION` if the core requires it.
- Windows are not persisted; English only.
